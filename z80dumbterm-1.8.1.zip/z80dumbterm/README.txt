What's new:
Emulator now supports sending Ctrl + Key into console input.

Added new text editor program TEXED!
 Uses 16KB Gap Buffer
 Controls:
 Ctrl + WASD = Cursor navigation
 Ctrl + E    = Save
 Ctrl + C    = Exit

CCP Version 1.0.0

CCP supported commands:

internal commands:
DIR
TYPE <filename>
EXIT
CREATE <filename>
DEL <filename>
REN <old filename> <new filename>

transient commands:
DISKSPACE [drive letter]
COPYTO [src drive letter, dest drive letter] [src filename] [dest filename]
