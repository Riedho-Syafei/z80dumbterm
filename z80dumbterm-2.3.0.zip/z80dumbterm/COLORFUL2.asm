; Z80 Smooth HSV Color Cycle (Max Saturation/Value)
; Target: CP/M (.COM file, ORG 0x0100)
; Mode 1: 120x90, 24-bit color (RGB)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
VDP_STAT_PORT   EQU 44H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; Switch to Video Mode 1
        LD A, 1
        OUT (VDP_MODE_PORT), A

FRAME_LOOP:
        ; Check for keypress to exit early
        IN A, (CON_STAT_PORT)
        OR A            
        JP NZ, EXIT_PROG 

        ; Wait for VBlank so the screen updates cleanly
        CALL WAIT_VBLANK

        ; Reset VRAM Pointer for the new frame
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; Set up the pixel counter (120 * 90 = 10,800 pixels)
        LD BC, 10800    
        
        ; Load the current RGB values into our fast registers
        LD A, (RED)
        LD D, A
        LD A, (GREEN)
        LD E, A
        LD A, (BLUE)
        LD H, A

PIXEL_LOOP:
        ; Output the solid color to every pixel on the screen
        LD A, D
        OUT (VDP_DATA), A   ; Write Red
        LD A, E
        OUT (VDP_DATA), A   ; Write Green
        LD A, H
        OUT (VDP_DATA), A   ; Write Blue

        ; Decrement 16-bit pixel counter
        DEC BC
        LD A, B
        OR C
        JR NZ, PIXEL_LOOP   

        ; ---------------------------------------------------------
        ; HSV STATE MACHINE LOGIC
        ; We check which of the 6 phases we are in and adjust 
        ; the corresponding color channel up or down.
        ; ---------------------------------------------------------
        LD A, (PHASE)
        
        OR A            ; Is it Phase 0?
        JR Z, P0_G_UP
        
        CP 1            ; Is it Phase 1?
        JR Z, P1_R_DN
        
        CP 2            ; Is it Phase 2?
        JR Z, P2_B_UP
        
        CP 3            ; Is it Phase 3?
        JR Z, P3_G_DN
        
        CP 4            ; Is it Phase 4?
        JR Z, P4_R_UP
        
        ; If not 0-4, it must be Phase 5
        JR P5_B_DN

P0_G_UP: 
        LD A, (GREEN)
		INC A
		LD (GREEN), A
		JR DONE_PHASE
P1_R_DN: 
        LD A, (RED)
		DEC A
		LD (RED), A
		JR DONE_PHASE
P2_B_UP: 
        LD A, (BLUE)
		INC A
		LD (BLUE), A
		JR DONE_PHASE
P3_G_DN: 
        LD A, (GREEN)
		DEC A
		LD (GREEN), A 
		JR DONE_PHASE
P4_R_UP: 
        LD A, (RED)
		INC A 
		LD (RED), A 
		JR DONE_PHASE
P5_B_DN: 
        LD A, (BLUE) 
		DEC A 
		LD (BLUE), A 
		JR DONE_PHASE

DONE_PHASE:
        ; We take exactly 255 steps per phase.
        LD A, (COUNTER)
        DEC A
        LD (COUNTER), A
        JR NZ, NEXT_FRAME   ; If counter isn't 0, keep doing current phase
        
        ; Counter hit 0! Reset it to 255 and move to the next phase
        LD A, 255
        LD (COUNTER), A
        
        LD A, (PHASE)
        INC A
        CP 6                ; Did we pass phase 5?
        JR NZ, SAVE_PHASE
        XOR A               ; Wrap back around to Phase 0
SAVE_PHASE:
        LD (PHASE), A

NEXT_FRAME:
        JP FRAME_LOOP

EXIT_PROG:
        ; Consume the keypress from the console data port
        IN A, (CON_DATA_PORT) 
        ; Restore Text Mode (Mode 0)
        XOR A
        OUT (VDP_MODE_PORT), A
        ; Exit back to CP/M
        JP  $003B

; ---------------------------------------------------------
; WAIT_VBLANK Subroutine
; ---------------------------------------------------------
WAIT_VBLANK:
WAIT_VBLANK_OUT:
        IN A, (VDP_STAT_PORT)
        BIT 0, A                
        JR NZ, WAIT_VBLANK_OUT  
WAIT_VBLANK_IN:
        IN A, (VDP_STAT_PORT)
        BIT 0, A                
        JR Z, WAIT_VBLANK_IN    
        RET

; ---------------------------------------------------------
; STATE VARIABLES (Stored in memory at the end of the COM)
; ---------------------------------------------------------
RED:     DB 255     ; Starts pure red
GREEN:   DB 0
BLUE:    DB 0
PHASE:   DB 0       ; Starts at Phase 0
COUNTER: DB 255     ; 255 steps per phase