; ====================================================================
; BASIC INTERPRETER WITH STRING VARIABLE SUPPORT
; Features: Dynamic string allocation, reference counting, garbage collection
; Run as: BASIC SCRIPT.BAS
; ====================================================================

        ORG $0100

        ; OS Syscall Constants
SC_EXIT         EQU 0
SC_PUTCHAR      EQU 1
SC_GETCHAR      EQU 2
SC_PUTS         EQU 3
SC_FS_OPEN      EQU 33
SC_FS_READ      EQU 34
SC_FS_CLOSE     EQU 35
SC_FS_FILE_SIZE EQU 42

ARG1            EQU $0090       ; Filename argument from CCP
SCRIPT_BUF      EQU $2000       ; Where we will load the BASIC script

; ====================================================================
; STRING HEAP CONFIGURATION
; ====================================================================
STRING_HEAP     EQU $3000       ; Start of string heap
STRING_HEAP_END EQU $3FFF       ; End of string heap
STRING_DESC_ADDR EQU $4000      ; String descriptor table address (26 entries for A$-Z$)

; String header in heap (when allocated):
; +0: Previous string pointer (2 bytes, 0 = first block)
; +2: Block size including header (2 bytes)
; +4: Reference count (1 byte)
; +5: Length (1 byte)
; +6: String data starts here

STRING_HDR_PREV     EQU 0
STRING_HDR_SIZE     EQU 2
STRING_HDR_REFCNT   EQU 4
STRING_HDR_LEN      EQU 5
STRING_DATA_OFFSET  EQU 6

; --- Constants ---
ARRAY_TABLE_ADDR EQU $4100      ; 26 entries * 4 bytes = 104 bytes
ARRAY_HEAP       EQU $5000      ; Where array descriptors are dynamically allocated

START:
        ; 1. Check if a filename was provided in ARG1
        LD   A, (ARG1)
        OR   A
        JR   NZ, .open_file

        ; No filename provided, print usage and exit
        LD   DE, MSG_USAGE
        LD   C, SC_PUTS
        CALL $0005
        JP   EXIT

.open_file:
        ; 2. Open the script file
        LD   DE, ARG1
        LD   C, SC_FS_OPEN
        CALL $0005
        OR   A
        JR   Z, .get_size

        ; Open failed
        LD   DE, MSG_ERR_OPEN
        LD   C, SC_PUTS
        CALL $0005
        JP   EXIT

.get_size:
        ; 3. Get exact file size to know how much to read
        LD   DE, FILE_SIZE_BUF
        LD   C, SC_FS_FILE_SIZE
        CALL $0005

        ; 4. Read the file into memory at SCRIPT_BUF
        LD   HL, (FILE_SIZE_BUF)
        LD   A, H
        OR   L
        JR   Z, .close_exit      ; Empty file, just exit

        LD   DE, SCRIPT_BUF
        LD   C, SC_FS_READ
        CALL $0005

        ; Null-terminate the loaded script just to be safe
        LD   HL, (FILE_SIZE_BUF)
        LD   DE, SCRIPT_BUF
        ADD  HL, DE
        LD   (HL), 0

.close_exit:
        ; 5. Close the file
        LD   C, SC_FS_CLOSE
        CALL $0005

        ; 6. Initialize string system
        CALL INIT_STRINGS

		; Initialize FOR loop system
		CALL INIT_FOR_LOOP_SP

        ; 7. Execute the script!
        LD   HL, SCRIPT_BUF
        CALL EXEC_LOOP

EXIT:
        LD   C, SC_EXIT
        CALL $0005

; ====================================================================
; STRING SYSTEM INITIALIZATION
; ====================================================================
INIT_STRINGS:
        ; Initialize string heap
        LD   HL, STRING_HEAP
        LD   (HEAP_PTR), HL

		; --- NEW: Zero the String Heap to prevent GC hangs ---
        LD   DE, STRING_HEAP_END - STRING_HEAP
        LD   HL, STRING_HEAP
.zero_heap:
        LD   (HL), 0
        INC  HL
        DEC  DE
        LD   A, D
        OR   E
        JR   NZ, .zero_heap
        ; -----------------------------------------------------

        ; Initialize all string descriptors to empty
        LD   B, 26                ; 26 string variables (A$-Z$)
        LD   IX, STRING_DESC_ADDR
.init_desc_loop:
        XOR  A
        LD   (IX+0), A           ; Pointer = NULL
        LD   (IX+1), A
        LD   (IX+2), A           ; Length = 0
        LD   (IX+3), A           ; Refcount = 0
        LD   (IX+4), A           ; Flags = 0
        LD   (IX+5), A           ; Padding
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        DJNZ .init_desc_loop

		; Initialize Array Heap Pointer
        LD   HL, ARRAY_HEAP
        LD   (ARRAY_HEAP_PTR), HL

        ; Clear Array Table (26 entries * 4 bytes = 104 bytes)
        LD   B, 104
        LD   HL, ARRAY_TABLE_ADDR
.clear_arrays:
        LD   (HL), 0
        INC  HL
        DJNZ .clear_arrays

        RET

INIT_FOR_LOOP_SP:
		; Initialize FOR Loop Stack Pointer
        LD   HL, FOR_STACK
        LD   (FOR_SP), HL
		RET

; ====================================================================
; INTERPRETER EXECUTION LOOP
; ====================================================================
EXEC_LOOP:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A                  ; Check for EOF
        RET  Z

        ; Skip blank lines (CR or LF)
        CP   13
        JP   Z, skip_blank
        CP   10
        JP   Z, skip_blank

        CALL PARSE_NUM          ; Parse the line number (ignored during normal execution)

EXEC_LOOP_CMD:
        CALL SKIP_WS

        ; Try matching "IF"
        LD   DE, CMD_IF
        CALL MATCH_STR
        JP   Z, DO_IF

        ; Try matching "PRINT"
        LD   DE, CMD_PRINT
        CALL MATCH_STR
        JP   Z, DO_PRINT

        ; Try matching "LET"
        LD   DE, CMD_LET
        CALL MATCH_STR
        JP   Z, DO_LET

        ; Try matching "GOTO"
        LD   DE, CMD_GOTO
        CALL MATCH_STR
        JP   Z, DO_GOTO

        ; Try matching "REM"
        LD   DE, CMD_REM
        CALL MATCH_STR
        JP   Z, DO_REM

        ; Try matching "INPUT"
        LD   DE, CMD_INPUT
        CALL MATCH_STR
        JP   Z, DO_INPUT

		; Try matching "DIM"
		LD   DE, CMD_DIM
		CALL MATCH_STR
		JP   Z, DO_DIM

		; Try matching "FOR"
        LD   DE, CMD_FOR
        CALL MATCH_STR
        JP   Z, DO_FOR

        ; Try matching "NEXT"
        LD   DE, CMD_NEXT
        CALL MATCH_STR
        JP   Z, DO_NEXT

        ; Unknown command
        LD   DE, MSG_ERR_SYNTAX
        LD   C, SC_PUTS
        CALL $0005
        RET

skip_blank:
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: PRINT "..." or PRINT <VAR> or PRINT <STRING$>
; ====================================================================
DO_PRINT:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A
        JP   Z, .print_done_check

		CP   13
        JP   Z, .print_done_check
        CP   10
        JP   Z, .print_done_check

        CP   '"'
        JR   NZ, .check_string_var    ; If no quote, check for variable

        ; --- Print String Literal ---
        INC  HL
.print_literal_loop:
        LD   A, (HL)
        OR   A
        JP   Z, .print_done_check
        CP   '"'
        JP   Z, .print_done_check
        CP   13
        JP   Z, .print_done_check
        CP   10
        JP   Z, .print_done_check
        LD   E, A
        LD   C, SC_PUTCHAR
        PUSH HL
        CALL $0005
        POP  HL
        INC  HL
        JP   .print_literal_loop

.check_string_var:
        ; 1. Check if it's a string expression (e.g., A$, CHR$(x), MID$(A$,...))
        CALL IS_STRING_EXPR
        JP   NC, .print_numeric_expr

        ; --- Print String Expression ---
        CALL EVAL_STRING_EXPR       ; DE = string data, C = length, HL = advanced script ptr
        LD   A, C
        OR   A
        JP   Z, .print_done           ; Empty string

        ; DE points to string data, C = length
        PUSH BC
        PUSH DE
.print_string_loop:
        LD   A, (DE)
        PUSH DE            ; Save string pointer
        PUSH BC            ; Save length counter
        PUSH HL            ; Save script pointer safely
		LD   E, A          ; E = character to print
        LD   C, SC_PUTCHAR
        CALL $0005
		POP  HL            ; Restore script pointer
        POP  BC            ; Restore length counter
        POP  DE            ; Restore string pointer
        INC  DE
        DEC  C
        JR   NZ, .print_string_loop
        
        POP  DE            ; Clean up pushed DE
        POP  BC            ; Clean up pushed BC
        JP   .print_done

.print_numeric_expr:
        ; --- Print Numeric Expression ---
        CALL EVAL_EXPR              ; Evaluates math/vars. DE = result, HL = advanced script ptr
        
        PUSH HL                     ; CRITICAL: PRINT_NUM16 clobbers HL (it swaps DE and HL)
        CALL PRINT_NUM16            ; Print the 16-bit number in DE
        POP  HL                     ; Restore our script pointer so execution continues normally

.print_done:
        CALL PRINT_NL
        CALL SKIP_LINE
        JP   EXEC_LOOP

.print_done_check:
        CALL PRINT_NL
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: LET <VAR> = <EXPR> or LET <STRING$> = <STRING_EXPR>
; ====================================================================
DO_LET:
        CALL SKIP_WS
        CALL IDENTIFY_VAR
        JP   NC, .let_numeric

        ; --- String Assignment ---
        ; IDENTIFY_VAR leaves B = variable index, HL right after the '$'
        CALL GET_STRING_DESC_PTR    ; Parses array index if present. IX = target descriptor
        PUSH IX                     ; Save IX! EVAL_STRING_EXPR might clobber it

        CALL SKIP_WS
        INC  HL                     ; Skip '='
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR       ; Returns DE = new string data, C = length
        
		; --- FIX: Copy to safe buffer to prevent GC invalidation ---
        ; If GC runs during ASSIGN_STRING_VAR, 'DE' becomes invalid.
        ; We copy to INPUT_BUFFER first.
        
        LD   A, C                   ; Check length
        OR   A
        JR   Z, .do_assign_safe     ; If empty, skip copy (DE doesn't matter)

        PUSH HL                     ; Save Script pointer before destroying HL
		PUSH BC                     ; Save length
        PUSH DE                     ; Save source pointer
        LD   HL, INPUT_BUFFER       ; Dest
        EX   DE, HL                 ; HL = Source, DE = Dest
        LDIR                        ; Copy string to safe buffer
        POP  DE                     ; Restore stack (junk value)
        POP  BC                     ; Restore length
        LD   DE, INPUT_BUFFER       ; DE now points to safe buffer
		POP  HL                     ; Restore Script pointer
        ; ---------------------------------------------------------

.do_assign_safe:
        POP  IX                     ; Restore our target descriptor into IX
        PUSH HL                     ; Preserve Script pointer
		CALL ASSIGN_STRING_VAR      ; Assign the string!
		POP  HL                     ; Restore Script pointer

        CALL SKIP_LINE
        JP   EXEC_LOOP

.let_numeric:
        ; --- Numeric Assignment (Original Logic) ---
        LD   A, (HL)
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH BC

        INC  HL
        CALL SKIP_WS
        INC  HL                     ; Skip '='
        CALL SKIP_WS

        CALL EVAL_EXPR

        POP  BC
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: INPUT <VAR> or INPUT <STRING$>
; ====================================================================
DO_INPUT:
        CALL SKIP_WS
        LD   A, (HL)
        CP   '"'
        JR   NZ, .no_prompt

        INC  HL
.prompt_loop:
        LD   A, (HL)
        CP   '"'
        JR   Z, .prompt_done
        LD   E, A
        PUSH HL
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  HL
        INC  HL
        JR   .prompt_loop
.prompt_done:
        INC  HL                     ; Skip quote
        CALL SKIP_WS
        INC  HL                     ; Skip comma
        CALL SKIP_WS

.no_prompt:
        CALL IDENTIFY_VAR
        JP   NC, .input_numeric

        ; --- String Input ---
        CALL GET_STRING_DESC_PTR    ; IX = target descriptor
        PUSH IX                     ; Save descriptor pointer safely on the stack

        CALL SKIP_WS

        ; Read line from console into input buffer
        LD   DE, INPUT_BUFFER
        PUSH HL
        CALL READ_LINE
        POP  HL

        ; Assign input to string variable
        POP  IX                     ; Restore our target descriptor into IX
        PUSH HL
        LD   HL, INPUT_BUFFER
        CALL ASSIGN_STRING_LITERAL  ; Relies on IX being set properly
        POP  HL

        CALL SKIP_LINE
        JP   EXEC_LOOP

.input_numeric:
        ; --- Numeric Input ---
        LD   A, (HL)
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH BC

        ; Read line from console into input buffer
        PUSH HL
		LD   DE, INPUT_BUFFER
        CALL READ_LINE

        ; Parse number from input buffer
        LD   HL, INPUT_BUFFER
        CALL PARSE_NUM
		POP  HL

        POP  BC
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: LEN(<STRING$>) - Returns string length
; ====================================================================
DO_LEN:
        CALL SKIP_WS
        CP   '('
        JP   NZ, ERR_SYNTAX
        INC  HL
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR
        ; C = length of string
        LD   D, 0
        LD   E, C
        ; Store result in variable A (index 0)
        LD   IX, VARIABLES
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: GOTO <LINE>
; ====================================================================
DO_GOTO:
        CALL SKIP_WS
        CALL PARSE_NUM
        PUSH DE

        LD   HL, SCRIPT_BUF
.search_loop:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A
        JP   Z, .not_found

        CALL PARSE_NUM
        POP  BC
        PUSH BC

        LD   A, D
        CP   B
        JR   NZ, .next_line
        LD   A, E
        CP   C
        JR   Z, .found_line

.next_line:
        CALL SKIP_LINE
        JP   .search_loop

.found_line:
        POP  BC
        JP   EXEC_LOOP_CMD

.not_found:
        POP  BC
        LD   DE, MSG_ERR_GOTO
        LD   C, SC_PUTS
        CALL $0005
        RET

; ====================================================================
; COMMAND: IF <EXPR> <OP> <EXPR> THEN <COMMAND>
; ====================================================================
DO_IF:
        CALL SKIP_WS
        
        ; 1. Peek to see if we are dealing with strings or numbers
        CALL IS_STRING_EXPR
        JP   C, .do_string_if

        ; --- Original Numeric Comparison Logic ---
        CALL EVAL_EXPR
        PUSH DE

        CALL SKIP_WS
        LD   A, (HL)
        LD   C, A
        INC  HL

        CALL SKIP_WS

        PUSH BC
        CALL EVAL_EXPR
        POP  BC

        EX   (SP), HL

        LD   A, C
        CP   '='
        JR   Z, .do_eq
        CP   '<'
        JR   Z, .do_lt
        CP   '>'
        JR   Z, .do_gt

        POP  HL
        JP   ERR_SYNTAX

.do_eq:
        OR   A
        SBC  HL, DE
        LD   A, H
        OR   L
        JP   Z, .is_true
        JP   .is_false

.do_lt:
        OR   A
        SBC  HL, DE
        JP   PE, .lt_ovf
        JP   M, .is_true
        JP   .is_false
.lt_ovf:
        JP   P, .is_true
        JP   .is_false

.do_gt:
        OR   A
        SBC  HL, DE
        JP   Z, .is_false
        JP   PE, .gt_ovf
        JP   P, .is_true
        JP   .is_false
.gt_ovf:
        JP   M, .is_true
        JP   .is_false

; --- Lexicographical String Comparison Engine ---
.do_string_if:
        CALL EVAL_STRING_EXPR  ; Evaluate left side. DE = str1, C = len1
        PUSH DE                ; Save str1 pointer to stack
        PUSH BC                ; Save len1 (in C register) to stack

        CALL SKIP_WS
        LD   A, (HL)           ; Get first character of operator
        INC  HL
        
        ; 1. Multi-character Operator Tokenizer
        CP   '<'
        JR   Z, .parse_lt
        CP   '>'
        JR   Z, .parse_gt
        JR   .op_parsed        ; If neither, assume '=' or invalid
        
.parse_lt:
        LD   A, (HL)
        CP   '>'               ; Is it '<>'?
        JR   Z, .make_neq
        CP   '='               ; Is it '<='?
        JR   Z, .make_lte
        LD   A, '<'            ; It's just '<'
        JR   .op_parsed
.make_neq:
        INC  HL
        LD   A, '#'            ; '#' token for '<>'
        JR   .op_parsed
.make_lte:
        INC  HL
        LD   A, 'L'            ; 'L' token for '<='
        JR   .op_parsed

.parse_gt:
        LD   A, (HL)
        CP   '='               ; Is it '>='?
        JR   Z, .make_gte
        LD   A, '>'            ; It's just '>'
        JR   .op_parsed
.make_gte:
        INC  HL
        LD   A, 'G'            ; 'G' token for '>='

.op_parsed:
        PUSH AF                ; Save our internal operator token to stack
        
        CALL SKIP_WS
        CALL EVAL_STRING_EXPR  ; Evaluate right side. DE = str2, C = len2
        
        ; 2. Stack Juggling (Aligning the Registers)
        ; This carefully retrieves our saved variables without destroying the script pointer (HL)
        POP  AF                ; Retrieve operator token into A
        EX   (SP), HL          ; HL = len1 word, Stack = [str1_ptr, script_ptr]
        LD   B, L              ; B = len1. (C is currently len2 from EVAL_STRING_EXPR)
        EX   (SP), HL          ; HL = script_ptr, Stack = [str1_ptr, len1 word]

		; --- FIX: Discard len1 safely without clobbering IY ---
        INC  SP                
        INC  SP                ; Manually advance the Stack Pointer by 2 bytes
        ; ------------------------------------------------------
        
        EX   (SP), HL          ; HL = str1_ptr, Stack = [script_ptr]
        
        ; Registers are now perfectly aligned: 
        ; HL = str1, DE = str2, B = len1, C = len2, A = operator
        PUSH AF                ; Save operator safely: Stack = [script_ptr, operator]

        ; 3. The Lexicographical Comparison
        LD   A, B
        CP   C                 ; Find minimum length
        JR   C, .use_len1      
        LD   A, C              
.use_len1:
        OR   A                 ; If min length is 0, skip char loop
        JR   Z, .check_lengths

        PUSH BC                ; Save len1 and len2
        LD   B, A              ; B is now loop counter (min length)
        
.str_cmp_loop:
        LD   A, (DE)           ; Fetch char2
        LD   C, A              ; Stash char2 safely in C
        LD   A, (HL)           ; Fetch char1
        CP   C                 ; A - C (char1 - char2)
        JR   NZ, .chars_diff   ; If diff found, break loop
        
        INC  HL
        INC  DE
        DJNZ .str_cmp_loop
        
        POP  BC                ; Loop finished, strings match up to min length. Restore lengths.
        
.check_lengths:
        LD   A, B
        CP   C                 ; Compare lengths (len1 - len2)
        JR   Z, .is_equal      ; Same length -> Exact Match
        JR   C, .is_less       ; Left string is shorter -> Less Than
        JR   .is_greater       ; Left string is longer -> Greater Than

.chars_diff:
        POP  BC                ; Restore lengths
        JR   C, .is_less       ; CP sets carry flag if char1 < char2
        JR   .is_greater       ; Otherwise char1 > char2

; 4. Operator Resolution
; We now know the relationship between the strings. Check if it satisfies the operator.
.is_equal:
        POP  AF                ; Retrieve operator
        CP   '='
        JP   Z, .is_true
        CP   'L'               ; <=
        JP   Z, .is_true
        CP   'G'               ; >=
        JP   Z, .is_true
        CP   '<'
        JP   Z, .is_false
        CP   '>'
        JP   Z, .is_false
        CP   '#'
        JP   Z, .is_false
        JR   .str_err          ; Invalid operator

.is_less:
        POP  AF
        CP   '<'
        JP   Z, .is_true
        CP   'L'               ; <=
        JP   Z, .is_true
        CP   '#'               ; <>
        JP   Z, .is_true
        CP   '='
        JP   Z, .is_false
        CP   '>'
        JP   Z, .is_false
        CP   'G'
        JP   Z, .is_false
        JR   .str_err

.is_greater:
        POP  AF
        CP   '>'
        JP   Z, .is_true
        CP   'G'               ; >=
        JP   Z, .is_true
        CP   '#'               ; <>
        JP   Z, .is_true
        CP   '='
        JP   Z, .is_false
        CP   '<'
        JP   Z, .is_false
        CP   'L'               ; <=
        JP   Z, .is_false
        JR   .str_err

.str_err:
        POP  HL                ; Clean up the script pointer from the stack
        JP   ERR_SYNTAX

.is_true:
        POP  HL                ; Restore script ptr
        CALL SKIP_WS
        LD   DE, CMD_THEN
        CALL MATCH_STR
        JP   NZ, ERR_SYNTAX
        JP   EXEC_LOOP_CMD

.is_false:
        POP  HL                ; Restore script ptr
        CALL SKIP_LINE
        JP   EXEC_LOOP

DO_DIM:
        CALL SKIP_WS
        ; Get variable letter (A-Z)
        LD   A, (HL)
        SUB  'A'
        LD   B, A           ; B = Array index (0-25)
        INC  HL
        
        ; Verify '$' and '('
        LD   A, (HL)
        CP   '$'
        JP   NZ, ERR_SYNTAX
        INC  HL
        LD   A, (HL)
        CP   '('
        JP   NZ, ERR_SYNTAX
        INC  HL
        
        PUSH BC             ; Save array index
        CALL EVAL_EXPR      ; E = Array size requested
        POP  BC
        
        ; Skip closing ')'
        CALL SKIP_WS
        INC  HL

		PUSH HL             ; Save the script pointer
        
        INC  E              ; BASIC arrays are usually 0-indexed, so DIM A$(10) = 11 elements

		PUSH DE             ; Save DE before calculating IX (E contains array size)
        
        ; Calculate IX = ARRAY_TABLE_ADDR + (B * 4)
        LD   L, B
        LD   H, 0
        ADD  HL, HL
        ADD  HL, HL
        LD   DE, ARRAY_TABLE_ADDR
        ADD  HL, DE
        PUSH HL
        POP  IX

		POP  DE              ; Restore DE
        
        ; Check if already dimensioned
        LD   A, (IX+0)
        OR   (IX+1)
        JP   NZ, ERR_SYNTAX ; "Array already dimensioned" error
        
        ; Store size
        LD   (IX+0), E
        LD   (IX+1), 0      ; Assuming arrays < 256 for now
        
        ; Calculate memory needed: E * 6 bytes per descriptor
        LD   A, E
        LD   L, A
        LD   H, 0
        LD   E, L
        LD   D, H
        ADD  HL, HL         ; * 2
        ADD  HL, DE         ; * 3
        ADD  HL, HL         ; * 6
        
        ; Allocate from ARRAY_HEAP
        LD   DE, (ARRAY_HEAP_PTR)
        LD   (IX+2), E      ; Store pointer in table
        LD   (IX+3), D
        
		; --- FIX: Zero out allocated memory ---
        PUSH HL             ; Save calculated size
        PUSH DE             ; Save heap pointer
        LD   B, H
        LD   C, L
        EX   DE, HL         ; HL now holds the heap address
.zero_loop:
        LD   A, B           ; Check if BC is already 0
        OR   C
        JR   Z, .zero_done  ; If 0, we are done
        
        LD   (HL), 0        ; Write 0
        INC  HL
        DEC  BC             ; Decrement
        JR   .zero_loop     ; Loop back and check again
.zero_done:
        POP  DE             ; Restore heap pointer
        POP  HL             ; Restore size
        ; --- END FIX ---

        ; Advance array heap pointer
        ADD  HL, DE
        LD   (ARRAY_HEAP_PTR), HL
        
        ; (Optional but recommended: Zero out the allocated memory so refcounts are 0)

		POP  HL             ; Restore the Script pointer
        
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: FOR <VAR> = <START> TO <END> [STEP <STEP>]
; ====================================================================
DO_FOR:
        CALL SKIP_WS
        CALL IDENTIFY_VAR
        JP   C, ERR_SYNTAX         ; Must be a numeric variable
        
        SUB  'A'
        LD   (TEMP_FOR_VAR), A     ; Save the variable index (0-25)

		INC  HL                    ; Skip the variable letter

        CALL SKIP_WS
        INC  HL                    ; Skip '='
        CALL SKIP_WS

        ; Evaluate <START>
        CALL EVAL_EXPR
        
        ; Assign <START> to the variable
        PUSH HL
        LD   A, (TEMP_FOR_VAR)
        ADD  A, A
        LD   C, A
        LD   B, 0
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   (IX+0), E
        LD   (IX+1), D
        POP  HL

        ; Match 'TO'
        CALL SKIP_WS
        LD   DE, CMD_TO
        CALL MATCH_STR
        JP   NZ, ERR_SYNTAX

        ; Evaluate <END>
        CALL EVAL_EXPR
        LD   (TEMP_FOR_END), DE

        ; Check for optional 'STEP'
        CALL SKIP_WS
        LD   DE, CMD_STEP
        CALL MATCH_STR
        JR   Z, .has_step
        
        LD   DE, 1                 ; Default STEP is 1
        JR   .save_frame

.has_step:
        CALL EVAL_EXPR             ; Evaluates STEP into DE

.save_frame:
        ; Check Stack Overflow
        LD   IX, (FOR_SP)
        LD   BC, FOR_STACK_END

		PUSH HL                    ; Save the Script pointer
        PUSH IX
        POP  HL
        OR   A
        SBC  HL, BC
		POP  HL                    ; Restore the Script pointer

        JP   Z, ERR_FOR            ; "Too many nested loops"

        ; Write frame to FOR_STACK
        LD   A, (TEMP_FOR_VAR)
        LD   (IX+0), A             ; [0] Variable Index
        
        LD   BC, (TEMP_FOR_END)
        LD   (IX+1), C             ; [1,2] End Value
        LD   (IX+2), B
        
        LD   (IX+3), E             ; [3,4] Step Value
        LD   (IX+4), D

        ; Find the start of the loop body (next line)
        CALL SKIP_LINE
        LD   (IX+5), L             ; [5,6] Return Address (Loop Body)
        LD   (IX+6), H

        ; Advance Stack Pointer (7 bytes per frame)
        PUSH HL
        LD   HL, (FOR_SP)
        LD   DE, 7
        ADD  HL, DE
        LD   (FOR_SP), HL
        POP  HL

        JP   EXEC_LOOP             ; Execute loop body

; ====================================================================
; COMMAND: NEXT <VAR>
; ====================================================================
DO_NEXT:
        CALL SKIP_WS
        CALL IDENTIFY_VAR
        JP   C, ERR_SYNTAX         ; Must be a numeric variable
        SUB  'A'
        LD   C, A                  ; C = Variable Index expected

		INC  HL                    ; Advance past the variable letter
		PUSH HL                    ; Save the Script pointer

        ; Check Stack Underflow
        LD   HL, (FOR_SP)
        LD   DE, FOR_STACK
        OR   A
        SBC  HL, DE

		POP  HL                    ; Restore the Script pointer

        JP   Z, ERR_FOR            ; "NEXT without FOR" error

		PUSH HL                    ; Save script pointer before we overwrite HL

        ; Get current frame
        LD   IX, (FOR_SP)
        LD   DE, -7
        ADD  IX, DE                ; IX points to current frame

        ; Validate variable matches the current loop
        LD   A, (IX+0)
        CP   C
        JP   NZ, ERR_FOR

        ; Get Step Value
        LD   E, (IX+3)
        LD   D, (IX+4)
        PUSH DE                    ; Save step value safely

        ; Fetch current variable value
        PUSH BC
        LD   A, C
        ADD  A, A
        LD   C, A
        LD   B, 0
        LD   IY, VARIABLES
        ADD  IY, BC
        LD   L, (IY+0)
        LD   H, (IY+1)             ; HL = Current Variable Value
        POP  BC

        ; Add Step to Variable
        POP  DE                    ; DE = Step Value
        ADD  HL, DE                ; HL = New Variable Value

        ; Store back into Variable
        PUSH BC
        LD   A, C
        ADD  A, A
        LD   C, A
        LD   B, 0
        LD   IY, VARIABLES
        ADD  IY, BC
        LD   (IY+0), L
        LD   (IY+1), H
        POP  BC

        ; Evaluate Condition against End Value
        LD   C, (IX+1)
        LD   B, (IX+2)             ; BC = End Value

        BIT  7, D                  ; Check if Step is negative
        JR   NZ, .step_negative

.step_positive:
        ; If New Value > End Value, terminate
        EX   DE, HL                ; DE = New Value
        LD   H, B
        LD   L, C                  ; HL = End Value
        OR   A
        SBC  HL, DE                ; End - New
        JP   M, .terminate         ; If End < New, exit loop
        JR   .loop_continue

.step_negative:
        ; If New Value < End Value, terminate
        EX   DE, HL                ; DE = New Value
        PUSH DE
        POP  HL                    ; HL = New Value
        LD   D, B
        LD   E, C                  ; DE = End Value
        OR   A
        SBC  HL, DE                ; New - End
        JP   M, .terminate         ; If New < End, exit loop

.loop_continue:
        POP  HL                    ; Discard saved pointer (we are jumping back anyway)
		
		; Jump back to the start of the loop body
        LD   L, (IX+5)
        LD   H, (IX+6)
        JP   EXEC_LOOP

.terminate:
        POP  HL                    ; Restore script pointer so SKIP_LINE works
		
		; Pop frame by retreating Stack Pointer
        LD   (FOR_SP), IX
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: REM
; ====================================================================
DO_REM:
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; GLOBAL ERROR HANDLER
; ====================================================================
ERR_SYNTAX:
        LD   DE, MSG_ERR_SYNTAX
        LD   C, SC_PUTS
        CALL $0005
        RET

ERR_BOUNDS:
        LD   DE, MSG_ERR_BOUNDS
        LD   C, SC_PUTS
        CALL $0005
        RET

ERR_FOR:
        LD   DE, MSG_ERR_FOR
        LD   C, SC_PUTS
        CALL $0005
        RET

ERR_OOM:
        LD   DE, MSG_ERR_OOM
        LD   C, SC_PUTS
        CALL $0005
        RET

; ====================================================================
; STRING EXPRESSION EVALUATOR
; ====================================================================

; EVAL_STRING_EXPR: Evaluates string expressions
; Returns: DE = string pointer, C = length
EVAL_STRING_EXPR:
        CALL SKIP_WS

        LD   DE, CMD_LEFT
        CALL MATCH_STR
        JP   Z, EVAL_LEFT

		LD   DE, CMD_RIGHT
        CALL MATCH_STR
        JP   Z, EVAL_RIGHT

        LD   DE, CMD_MID
        CALL MATCH_STR
        JP   Z, EVAL_MID

		LD   DE, CMD_CHR
        CALL MATCH_STR
        JP   Z, EVAL_CHR

        LD   DE, CMD_STR
        CALL MATCH_STR
        JP   Z, EVAL_STR
		
		; Check for string literal
        LD   A, (HL)
        CP   '"'
        JR   NZ, .check_concat

        ; String literal
        INC  HL
        LD   DE, INPUT_BUFFER
        LD   C, 0
.string_lit_loop:
        LD   A, (HL)
        OR   A
        JR   Z, .lit_done
        CP   '"'
        JR   Z, .lit_done
        CP   13
        JR   Z, .lit_done
        CP   10
        JR   Z, .lit_done
        LD   (DE), A
        INC  DE
        INC  HL
        INC  C
        JR   .string_lit_loop
.lit_done:
        ; Check if we stopped because of a quote, if so skip it
        LD   A, (HL)
        CP   '"'
        JR   NZ, .no_quote_skip
        INC  HL                  ; Advance HL past the closing quote!
.no_quote_skip:
        XOR  A
        LD   (DE), A             ; Null terminate

        LD   DE, INPUT_BUFFER    ; DE = string data pointer
        LD   A, C
        LD   (TEMP_LEN), A
        OR   A                   ; Set Z if empty
        RET

.check_concat:
        ; Check for string variable
        CALL IDENTIFY_VAR
        JR   NC, .syntax_err

        ; IDENTIFY_VAR leaves B = index, HL after '$'
        CALL GET_STRING_DESC_PTR    ; IX = descriptor, HL advanced past array brackets
        
        ; Get string variable value
        PUSH HL                     ; Save our advanced script pointer safely
        CALL GET_STRING_VAR         ; Fetch string data using IX. Returns DE = pointer, C = length
        POP  HL                     ; Restore script pointer

        OR   A                      ; Set flags based on length
        RET

.syntax_err:
        JP   ERR_SYNTAX

; ====================================================================
; EVAL_LEFT: Evaluates LEFT$(<string>, <n>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_LEFT:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; DE = string, C = length
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A
        
        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; E = requested length
        
        LD   A, (TEMP_LEN)
        CP   E
        JR   NC, .left_use_n
        LD   E, A                   ; Clamp length
.left_use_n:
        LD   C, E                   ; C = new length
        LD   DE, (TEMP_STRING_PTR)  ; DE = original string pointer
        
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_RIGHT: Evaluates RIGHT$(<string>, <n>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_RIGHT:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; Get string: DE = pointer, C = length
        
        ; Store original string data safely
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A
        
        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get n: E = requested length
        
        LD   A, (TEMP_LEN)          ; A = original length
        CP   E                      ; Compare original length with n
        JR   C, .right_use_all      ; If original < n, just return whole string
        JR   Z, .right_use_all      ; If original == n, return whole string

        ; n is smaller: calculate pointer offset (offset = original - n)
        SUB  E                      ; A = original length - n
        LD   C, E                   ; C = new string length (n)

        ; Advance string pointer by the offset
        LD   E, A
        LD   D, 0
        LD   IX, (TEMP_STRING_PTR)
        ADD  IX, DE                 ; Add offset to original pointer
        PUSH IX
        POP  DE                     ; DE = new advanced pointer
        JR   .right_done

.right_use_all:
        ; Request is larger than string, return original bounds
        LD   C, A                   ; C = original length
        LD   DE, (TEMP_STRING_PTR)

.right_done:
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_MID: Evaluates MID$(<string>, <start>, <length>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_MID:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; Get string: DE = pointer, C = length
        
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A

        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get start position
        PUSH DE                     ; Save start position (in E) to stack

        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get requested length
        LD   B, E                   ; B = requested length (save in B)

        POP  DE                     ; Restore start position into E

        ; Calculate offset (start - 1, since BASIC is 1-indexed)
        LD   A, E
        OR   A                      ; Safety check: if start is 0
        JR   Z, .mid_start_zero
        DEC  A                      ; A = offset (0-indexed)
.mid_start_zero:
        
        LD   E, A                   ; Save offset temporarily in E
        LD   A, (TEMP_LEN)          ; A = original string length
        CP   E                      ; Check if offset goes past string bounds
        JR   C, .mid_empty          ; If length < offset, return empty
        JR   Z, .mid_empty          ; If length == offset, return empty

        ; Calculate maximum available characters from this start point
        SUB  E                      ; A = max length (original - offset)
        CP   B                      ; Compare max length with requested length
        JR   C, .mid_clamp          ; If max available < requested, clamp it
        LD   A, B                   ; Otherwise, use requested length safely
.mid_clamp:
        LD   C, A                   ; C = final clamped length

        ; Advance string pointer by the offset
        LD   D, 0                   ; E already holds the offset
        LD   IX, (TEMP_STRING_PTR)
        ADD  IX, DE
        PUSH IX
        POP  DE                     ; DE = advanced pointer
        JR   .mid_done

.mid_empty:
        LD   C, 0                   ; Return 0 length
        LD   DE, (TEMP_STRING_PTR)  ; Pointer doesn't matter much, but keep it clean

.mid_done:
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_CHR: Evaluates CHR$(<n>)
; Returns: DE = string pointer, C = length (always 1)
; ====================================================================
EVAL_CHR:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_EXPR              ; Evaluate numeric expression, DE = ASCII code

        ; Store the single character in INPUT_BUFFER
        LD   A, E
        LD   (INPUT_BUFFER), A
        XOR  A
        LD   (INPUT_BUFFER+1), A    ; Null terminate

        CALL SKIP_WS
        INC  HL                     ; Skip ')'

        ; Set up return registers
        LD   DE, INPUT_BUFFER
        LD   C, 1                   ; Length is 1
        LD   A, C
        LD   (TEMP_LEN), A          ; Keep TEMP_LEN updated for safety
        RET

; ====================================================================
; EVAL_STR: Evaluates STR$(<n>)
; Returns: DE = string pointer, C = length
; ====================================================================
EVAL_STR:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_EXPR              ; Evaluate numeric expression, DE = number

        ; Convert DE to string (NUM_TO_STR safely preserves HL)
        CALL NUM_TO_STR             ; Outputs null-terminated string to INPUT_BUFFER

        CALL SKIP_WS
        INC  HL                     ; Skip ')'

        ; Calculate the length of the newly created string
        LD   DE, INPUT_BUFFER
        LD   C, 0
.str_len_loop:
        LD   A, (DE)
        OR   A
        JR   Z, .str_len_done
        INC  DE
        INC  C
        JR   .str_len_loop
.str_len_done:
        LD   DE, INPUT_BUFFER       ; Reset DE to start of string
        LD   A, C
        LD   (TEMP_LEN), A          ; Save length
        RET

; ====================================================================
; STRING ALLOCATION AND MANAGEMENT
; ====================================================================

; ====================================================================
; GET_STRING_VAR: Gets string variable data
; Input:  IX = pointer to string descriptor
; Output: DE = string data pointer, C = length, A = 0 if empty
; ====================================================================
GET_STRING_VAR:
        ; 1. Get string heap header pointer from descriptor
        LD   E, (IX+0)
        LD   D, (IX+1)

        ; 2. Get length
        LD   C, (IX+2)
		LD   B, 0                   ; Clear the high byte
        LD   A, C
        OR   A
        RET  Z                      ; If length is 0, string is empty. Return.

        ; 3. Skip heap header to get to actual string data
        ; (Using HL for the addition preserves IX and is faster!)
        EX   DE, HL                 ; HL = heap header pointer
        LD   DE, STRING_DATA_OFFSET ; DE = offset (6 bytes)
        ADD  HL, DE                 ; HL = actual string data pointer
        EX   DE, HL                 ; DE = actual string data pointer

        RET

; ====================================================================
; ASSIGN_STRING_VAR: Assigns a string (with ref counting) to a variable
; Input: IX = pointer to string descriptor, DE = new string pointer, C = length
; ====================================================================
ASSIGN_STRING_VAR:
        PUSH BC              ; Safely store the new string's length (in C)

        ; 1. Check if there is an old string attached to this descriptor
        ; Using L and H here prevents us from clobbering C!
        LD   L, (IX+0)       ; Old pointer Low
        LD   H, (IX+1)       ; Old pointer High
        LD   A, H
        OR   L
        JR   Z, .no_old_string

        ; 2. Decrement old string's ref count
        PUSH DE              ; Save our NEW string pointer
        PUSH HL
        POP  DE              ; Move old string pointer into DE
        CALL DEC_REF_COUNT
        POP  DE              ; Restore our NEW string pointer

.no_old_string:
        ; 3. Allocate new string on the heap
        POP  BC              ; Retrieve new string's length (C)
        PUSH BC              ; Push it right back so we can use it to update the descriptor later
        CALL ALLOC_STRING    ; DE = new string data, C = length -> Returns DE = heap header pointer
        POP  BC              ; Retrieve new string's length (C) one last time

        ; 4. Update the descriptor with the new heap block info
        LD   (IX+0), E       ; Heap pointer Low
        LD   (IX+1), D       ; Heap pointer High
        LD   (IX+2), C       ; String length
        LD   (IX+3), 1       ; Initial reference count = 1

		; --- FIX START ---
        ; CRITICAL: Do not write back-pointer if allocation failed (Empty string)
        LD   A, D
        OR   E
        JR   Z, .skip_back_pointer
        ; --- FIX END ---

		; --- NEW: Store Descriptor Back-Pointer ---
        PUSH HL
        LD   L, E
        LD   H, D            ; HL = Heap Header (DE)
        PUSH IX
        POP  BC              ; BC = Descriptor address (IX)
        LD   (HL), C         ; Save descriptor low byte
        INC  HL
        LD   (HL), B         ; Save descriptor high byte
        POP  HL
        ; ------------------------------------------

.skip_back_pointer:
        RET

; ASSIGN_STRING_LITERAL: Assigns a null-terminated string literal
; Input: BC = variable index, HL = pointer to null-terminated string
ASSIGN_STRING_LITERAL:
        PUSH HL
        LD   C, 0
        PUSH HL
.len_count_loop:
        LD   A, (HL)
        OR   A
        JR   Z, .len_done
        INC  C
        INC  HL
        JR   .len_count_loop
.len_done:
        POP  DE              ; DE = source string
        POP  HL              ; HL = script pointer
        JP   ASSIGN_STRING_VAR

; ASSIGN_STRING_LITERAL_N: Assigns a string with known length
; Input: BC = variable index, HL = pointer to string, C = length
ASSIGN_STRING_LITERAL_N:
        PUSH IX
        PUSH HL

        ; Copy string to input buffer
        LD   B, C
        LD   DE, INPUT_BUFFER
.copy_loop:
        LD   A, (HL)
        LD   (DE), A
        INC  HL
        INC  DE
        DEC  B
        JR   NZ, .copy_loop

        XOR  A
        LD   (DE), A                ; Null terminate

        POP  HL
        POP  IX
        LD   DE, INPUT_BUFFER       ; <--- FIX: Tell ASSIGN_STRING_VAR where the string is
        JP   ASSIGN_STRING_VAR

; ALLOC_STRING: Allocates a string on the heap
; Input: DE = source string pointer, C = length
; Output: DE = heap pointer to string header, A = 0 if success
ALLOC_STRING:
        PUSH HL
        LD   A, C
        OR   A
        JR   Z, .empty_string

        ; Calculate total size needed: header + string + null terminator
        LD   A, C
        ADD  A, STRING_DATA_OFFSET + 1
        LD   (TEMP_LEN), A

        ; Check if we have enough heap space
        LD   HL, (HEAP_PTR)
        PUSH DE                  ; <--- FIX: Save source string pointer!
        LD   E, A
        LD   D, 0
        ADD  HL, DE
        POP  DE                  ; <--- FIX: Restore source string pointer!
        LD   A, H
        CP   $40                 ; Check against STRING_HEAP_END page
        JR   NC, .gc_needed

        ; We have space - allocate
        LD   HL, (HEAP_PTR)

        ; Save current heap pointer as our block
        PUSH HL

        ; =========================================================
        ; FIX: INITIALIZE THE 6-BYTE HEAP HEADER PROPERLY
        ; =========================================================
        XOR  A
        LD   (HL), A             ; [0] Prev ptr low (unused)
        INC  HL
        LD   (HL), A             ; [1] Prev ptr high (unused)
        INC  HL
        
        LD   A, (TEMP_LEN)
        LD   (HL), A             ; [2] Block size low
        INC  HL
        XOR  A
        LD   (HL), A             ; [3] Block size high
        INC  HL
        
        LD   A, 1
        LD   (HL), A             ; [4] Ref Count = 1
        INC  HL
        
        LD   A, C
        LD   (HL), A             ; [5] String Length
        INC  HL
        ; =========================================================
        
        ; Now: HL naturally points to the start of string data
        ; DE = source string
        LD   B, C
.copy_string:
        LD   A, (DE)
        LD   (HL), A
        INC  HL
        INC  DE
        DEC  B
        JR   NZ, .copy_string

        ; Null terminate
        XOR  A
        LD   (HL), A

        ; Update heap pointer
        POP  DE                     ; DE = block header pointer
        LD   HL, (HEAP_PTR)
        LD   A, (TEMP_LEN)
        ADD  A, L
        LD   L, A
        LD   A, 0
        ADC  A, H
        LD   H, A
        LD   (HEAP_PTR), HL

        XOR  A                      ; Success
        POP  HL
        RET

.empty_string:
        LD   DE, 0
        XOR  A
        POP  HL
        RET

.gc_needed:
        ; Run garbage collection
        CALL RUN_GC

		; --- FIX: Check if GC actually freed enough space! ---
        LD   HL, (HEAP_PTR)
        LD   A, (TEMP_LEN)
        LD   E, A
        LD   D, 0
        ADD  HL, DE
        LD   A, H
        CP   $40                 ; Check against STRING_HEAP_END page
        JP   NC, ERR_OOM         ; If it's STILL full after GC, crash cleanly!
        ; -----------------------------------------------------

        ; Retry allocation
        POP  HL
        JP   ALLOC_STRING

; DEC_REF_COUNT: Decrements reference count and frees if zero
; Input: DE = heap pointer to string header
DEC_REF_COUNT:
        LD   A, D
        OR   E
        RET  Z                      ; NULL pointer

		PUSH HL

        ; Get ref count location
        PUSH DE
        POP  HL
        LD   BC, STRING_HDR_REFCNT
        ADD  HL, BC

        ; Decrement ref count
        DEC  (HL)
		POP  HL
        RET  NZ                     ; Still referenced

        ; Ref count is zero - block will be reclaimed by GC
        RET

; RUN_GC: Mark-and-sweep garbage collection
RUN_GC:
        PUSH HL
        PUSH DE
        PUSH BC
        PUSH AF

        ; We can skip the Mark Phase!
        ; Your DEC_REF_COUNT already reduces dead strings to Ref Count 0.
        ; We just need to sweep and compact blocks where Ref Count > 0.

        LD   HL, STRING_HEAP
        LD   DE, STRING_HEAP          ; DE will be our new compacted Heap Pointer

.sweep_loop:
        ; Check if we've reached current heap end
        PUSH HL
        LD   HL, (HEAP_PTR)
        LD   B, H
        LD   C, L
        POP  HL
        
        LD   A, B
        CP   H
        JR   NZ, .check_sweep_block
        LD   A, C
        CP   L
        JR   Z, .sweep_done           ; Reached end of active heap

.check_sweep_block:
        ; Get block size into BC
        PUSH HL
        LD   BC, STRING_HDR_SIZE
        ADD  HL, BC
        LD   C, (HL)
        INC  HL
        LD   B, (HL)
        POP  HL                       ; HL points to block start, BC = size

        ; Prevent Infinite Loop if block size is corrupted/0
        LD   A, B
        OR   C
        JR   Z, .sweep_done           ; Emergency exit if size is 0

        ; Check Ref Count (offset 4)
        PUSH BC                       ; Save block size safely
		PUSH HL
        LD   BC, STRING_HDR_REFCNT
        ADD  HL, BC
        LD   A, (HL)
        POP  HL
		POP  BC                       ; Restore the block size

        OR   A
        JR   Z, .sweep_next           ; Refcount 0, it's garbage, skip it

        ; Refcount > 0. This block is reachable - compact it!
        
        ; --- NEW: Update the variable descriptor ---
        PUSH BC                 ; Save block size safely
        PUSH HL                 ; Save current read pointer
        
        ; 1. Read the Back-Pointer
        LD   C, (HL)
        INC  HL
        LD   B, (HL)            ; BC now holds the memory address of the descriptor (e.g. A$)
        
        ; 2. Update the variable descriptor with our new heap destination (DE)
        LD   H, B
        LD   L, C               ; HL = Descriptor Address
        LD   (HL), E            ; Update Descriptor Low
        INC  HL
        LD   (HL), D            ; Update Descriptor High
        
        POP  HL                 ; Restore HL to start of block
        POP  BC                 ; Restore BC to block size
        ; -------------------------------------------

        ; --- NEW: Optimized Z80 Block Copy ---
        PUSH HL                 ; Save read pointer for .sweep_next
        PUSH BC                 ; Save block size for .sweep_next
        
        LDIR                    ; Z80 Magic! Copies BC bytes from HL to DE. 
                                ; This automatically advances DE to the next free space!
        
        POP  BC                 ; Restore block size
        POP  HL                 ; Restore read pointer
        ; -------------------------------------

.sweep_next:
        ; Advance HL by block size (BC)
        ADD  HL, BC
        JP   .sweep_loop

.sweep_done:
        ; Update HEAP_PTR to our new compacted end (DE)
        LD   (HEAP_PTR), DE
        
        POP  AF
        POP  BC
        POP  DE
        POP  HL
        RET

; ====================================================================
; HELPER ROUTINES
; ====================================================================

; IS_STRING_EXPR: Checks if expression at HL evaluates to a string
; Output: Carry = 1 if string expression, Carry = 0 if numeric
IS_STRING_EXPR:
        LD   A, (HL)
        CP   '"'
        SCF
        RET  Z                 ; It's a string literal

        PUSH HL
        CALL IDENTIFY_VAR
        POP  HL
        RET  C                 ; Carry set = it's a string variable (e.g., A$)

        ; Check for string functions (LEFT$, RIGHT$, MID$, CHR$, STR$)
        PUSH HL
        LD   DE, CMD_LEFT
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_RIGHT
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_MID
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_CHR
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_STR
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        OR   A                 ; Clear carry flag (it's numeric)
        RET

; IDENTIFY_VAR: Checks if current position has a variable
; Output: 
;   Carry = 1: String Var. B = index (0-25). 
;              Z Flag = 1 if Array A$(x), NZ if Scalar A$
;   Carry = 0: Numeric var. A = variable letter
;   NZ if not a variable
IDENTIFY_VAR:
        LD   A, (HL)
        CP   'A'
        JR   C, .not_var
        CP   'Z'+1
        JR   NC, .not_var

        LD   C, A            ; Temporarily save the character
        INC  HL
        LD   A, (HL)
        CP   '$'
        JR   NZ, .numeric_var

        ; --- It's a string variable ---
        INC  HL              ; Skip '$'
        LD   A, C            
        SUB  'A'             
        LD   B, A            ; Store variable index in B

        ; Detect Array context without consuming it
        LD   A, (HL)
        CP   '('
        JR   Z, .is_array

.is_scalar:
        LD   A, 1            ; Ensure A is non-zero
        OR   A               ; Clears Z flag (NZ = Scalar)
        SCF                  ; Set Carry = String
        RET

.is_array:
        XOR  A               ; Sets Z flag (Z = Array)
        SCF                  ; Set Carry = String
        RET
        
.numeric_var:
        DEC  HL
        LD   A, C
        SCF
        CCF                  ; Clear carry
        RET
        
.not_var:
        OR   1
        SCF
        CCF                  ; Clear carry
        RET

; READ_LINE: Reads a line from console into buffer
; Input: DE = buffer pointer
; Output: Null-terminated string in buffer
READ_LINE:
        PUSH DE
.read_char:
        ; Read character
        PUSH DE             ; <--- FIX: Save buffer pointer before syscall clobbers E
        LD   E, 0
        LD   C, SC_GETCHAR
        CALL $0005
        POP  DE             ; <--- FIX: Restore buffer pointer

        ; Check for Enter
        CP   13
        JR   Z, .enter_pressed
        CP   10
        JR   Z, .enter_pressed

        ; Store character
        LD   (DE), A
        INC  DE

        ; Echo character
        PUSH DE             ; <--- FIX: Save buffer pointer before syscall clobbers E
        LD   E, A
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  DE             ; <--- FIX: Restore buffer pointer

        JR   .read_char

.enter_pressed:
        ; Null terminate
        XOR  A
        LD   (DE), A

        ; Print newline
        CALL PRINT_NL

        POP  DE             ; Restore original start pointer
        RET

; NUM_TO_STR: Converts number in DE to string in buffer
; Input: DE = 16-bit number
; Output: Null-terminated string at INPUT_BUFFER
NUM_TO_STR:
        PUSH DE
        PUSH HL
        LD   HL, INPUT_BUFFER
        ; Check if negative
        BIT  7, D
        JR   Z, .positive

        ; Negative - print '-'
        LD   (HL), '-'
        INC  HL

        ; Negate DE
        LD   A, D
        CPL
        LD   D, A
        LD   A, E
        CPL
        LD   E, A
        INC  DE

.positive:
        ; Convert to string
        EX   DE, HL           ; HL = number, DE = buffer ptr
        PUSH DE               ; Save start of digit buffer
        CALL .HL_TO_DEC       ; Writes 5 digits to DE, advancing DE
        
        ; Null terminate
        XOR  A
        LD   (DE), A          
        
        ; Strip leading zeros
        POP  DE               ; DE = start of digits
        PUSH DE
        POP  HL               ; HL = start of digits (to read from)

.skip_zeros:
        LD   A, (HL)
        CP   '0'
        JR   NZ, .shift_chars ; If not '0', we found our first real digit
        INC  HL
        LD   A, (HL)
        OR   A                ; Are we at the null terminator?
        JR   Z, .last_zero
        JR   .skip_zeros

.last_zero:
        DEC  HL               ; If it was all zeros, leave at least one '0'

.shift_chars:
        ; Shift the characters left to overwrite the leading zeros
        LD   A, (HL)
        LD   (DE), A
        INC  HL
        INC  DE
        OR   A                ; Did we just copy the null terminator?
        JR   NZ, .shift_chars ; If not, keep copying
        
        POP  HL
        POP  DE
        RET

; HL_TO_DEC: Convert 16-bit number to decimal string
; Input: HL = number, DE = buffer pointer
; Output: DE = updated buffer pointer
.HL_TO_DEC:
        PUSH BC
        PUSH HL

        LD   BC, -10000       ; <-- FIX: Use BC for divisor, preserving DE
        CALL .divmod_digit
        LD   BC, -1000
        CALL .divmod_digit
        LD   BC, -100
        CALL .divmod_digit
        LD   BC, -10
        CALL .divmod_digit
        LD   BC, -1
        CALL .divmod_digit

        POP  HL
        POP  BC
        RET

.divmod_digit:
        LD   A, '0' - 1
.divmod_loop:
        INC  A
        ADD  HL, BC           ; <-- FIX: Divisor is now in BC
        JR   C, .divmod_loop
        SBC  HL, BC
        LD   (DE), A          ; <-- FIX: Safe write to buffer pointer
        INC  DE               ; <-- FIX: Advance buffer pointer
        RET

; PARSE_NUM_FROM_STRING: Parses number from string
; Input: DE = string pointer, C = length
; Output: DE = parsed number
PARSE_NUM_FROM_STRING:
        ; Save string end
        PUSH DE
        LD   A, C
        LD   L, A
        LD   H, 0
        ADD  HL, DE
        ; Save end position
        LD   (TEMP_STRING_PTR), HL
        POP  DE

        ; Null terminate temporarily
        LD   A, (HL)
        LD   (TEMP_LEN), A
        PUSH AF
        LD   (HL), 0

        ; Parse
        EX   DE, HL
        CALL PARSE_NUM
        EX   DE, HL

        ; Restore original character
        POP  AF
		PUSH HL
        LD   HL, (TEMP_STRING_PTR)
        LD   (HL), A
		POP  HL

        RET

; MATCH_STR: Checks if string at HL matches null-terminated string at DE.
MATCH_STR:
        PUSH HL
        PUSH DE
.match_loop:
        LD   A, (DE)
        OR   A
        JR   Z, .matched

        LD   B, A
        LD   A, (HL)
        CP   B
        JR   NZ, .mismatch

        INC  HL
        INC  DE
        JP   .match_loop
.matched:
        POP  DE
        POP  AF
        XOR  A
        RET
.mismatch:
        POP  DE
        POP  HL
        LD   A, 1
        OR   A
        RET

; SKIP_WS: Advances HL past spaces and tabs
SKIP_WS:
        LD   A, (HL)
        CP   ' '
        JR   Z, .skip_ws
        CP   9
        JR   Z, .skip_ws
        RET
.skip_ws:
        INC  HL
        JP   SKIP_WS

; SKIP_LINE: Advances HL past the next CR/LF
SKIP_LINE:
        LD   A, (HL)
        OR   A
        RET  Z
        CP   10
        JR   Z, .found_nl
        CP   13
        JR   Z, .found_cr
        INC  HL
        JP   SKIP_LINE
.found_cr:
        INC  HL
        LD   A, (HL)
        CP   10
        JR   Z, .skip_one_more
        RET
.found_nl:
        INC  HL
        LD   A, (HL)
        CP   13
        JR   Z, .skip_one_more
        RET
.skip_one_more:
        INC  HL
        RET

; PRINT_NL: Prints Carriage Return + Line Feed
PRINT_NL:
        PUSH HL
		LD   E, 13
        LD   C, SC_PUTCHAR
        CALL $0005
        LD   E, 10
        LD   C, SC_PUTCHAR
        CALL $0005
		POP  HL
        RET

; GET_STRING_DESC_PTR
; Parses scalar or array index and returns the descriptor address.
; Input:  B = variable index (0-25), HL points after '$'
; Output: IX = Pointer to the 6-byte string descriptor
;         HL advanced past the array '()' if present
GET_STRING_DESC_PTR:
        LD   A, (HL)
        CP   '('
        JR   Z, .eval_array

.eval_scalar:
        PUSH HL
		
		; Calculate IX = STRING_DESC_ADDR + (B * 6)
        LD   L, B
        LD   H, 0
        LD   E, L
        LD   D, H            ; DE = B
        ADD  HL, HL          ; HL = 2 * B
        ADD  HL, DE          ; HL = 3 * B
        ADD  HL, HL          ; HL = 6 * B
        LD   DE, STRING_DESC_ADDR
        ADD  HL, DE          ; HL = STRING_DESC_ADDR + 6 * B
        PUSH HL
        POP  IX

		POP  HL
        RET

.eval_array:
        INC  HL              ; Skip '('
        PUSH BC              ; Save variable index
        CALL EVAL_EXPR       ; Evaluate index into DE (E = requested index)
        POP  BC              ; Restore variable index

        CALL SKIP_WS
        LD   A, (HL)
        CP   ')'
        JP   NZ, ERR_SYNTAX
        INC  HL              ; Skip ')'

        ; Calculate Array Table Entry: ARRAY_TABLE_ADDR + (B * 4)
        PUSH HL              ; Save script pointer safely!
		PUSH DE              ; Save the evaluated array index
        LD   L, B
        LD   H, 0
        ADD  HL, HL          ; * 2
        ADD  HL, HL          ; * 4
        LD   DE, ARRAY_TABLE_ADDR
        ADD  HL, DE
        PUSH HL
        POP  IX
		POP  DE              ; Restore the evaluated array index

        ; Fast check: Is it dimensioned?
        LD   A, (IX+0)
        OR   (IX+1)
        JP   Z, ERR_SYNTAX   ; Error: Array not dimensioned

        ; --- BOUNDS CHECK START ---
        ; DE holds requested index. Currently supporting < 256 (D must be 0).
        LD   A, D
        OR   A
        JP   NZ, ERR_BOUNDS  ; If D > 0, index exceeds 255 (out of bounds)

        LD   A, (IX+0)       ; A = allocated size (max_index + 1)
        CP   E               ; Compare size (A) with requested index (E)
        JP   Z, ERR_BOUNDS   ; If Size == Index, out of bounds
        JP   C, ERR_BOUNDS   ; If Size < Index, out of bounds
        ; --- BOUNDS CHECK END ---

        ; Get base pointer from table
        LD   C, (IX+2)
        LD   B, (IX+3)

        ; Calculate Element Offset = (E * 6)
        LD   L, E
        LD   H, 0
        LD   E, L
        LD   D, H
        ADD  HL, HL          ; * 2
        ADD  HL, DE          ; * 3
        ADD  HL, HL          ; * 6

        ; Add Base Pointer + Offset
        LD   D, B
        LD   E, C
        ADD  HL, DE

        PUSH HL
        POP  IX              ; IX = Exact memory address of descriptor
        POP  HL              ; Restore script pointer
        RET

; ====================================================================
; MATH EVALUATOR
; ====================================================================

; ====================================================================
; GET_FACTOR: Parses numbers, variables, functions, and (expressions)
; ====================================================================
GET_FACTOR:
        CALL SKIP_WS

        ; --- 1. Check for Parentheses ---
        LD   A, (HL)
        CP   '('
        JR   NZ, .no_parens

        ; Handle '('
        INC  HL                 ; Skip '('
        CALL EVAL_EXPR          ; Recursively evaluate the inside expression! Result goes to DE
        PUSH DE                 ; Save our calculated result
        
        CALL SKIP_WS
        LD   A, (HL)
        CP   ')'
        JP   NZ, ERR_SYNTAX     ; If no closing parenthesis, crash with a syntax error

        INC  HL                 ; Skip ')'
        POP  DE                 ; Restore our calculated result into DE
        RET

.no_parens:
        ; --- 2. Check for Built-in Functions ---
        LD   DE, CMD_LEN
        CALL MATCH_STR
        JR   Z, EVAL_LEN

        LD   DE, CMD_VAL
        CALL MATCH_STR
        JR   Z, EVAL_VAL

        ; --- 3. Check for Variables (A-Z) ---
        LD   A, (HL)
        CP   'A'
        JR   C, .is_num
        CP   'Z'+1
        JR   NC, .is_num

.is_var:
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH HL
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   E, (IX+0)
        LD   D, (IX+1)
        POP  HL
        INC  HL
        RET

.is_num:
        ; --- 4. It must be a Number ---
        CALL PARSE_NUM
        RET

EVAL_LEN:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; C = length
        LD   E, C
        LD   D, 0                   ; Return length in DE
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_VAL: Evaluates VAL(<string$>)
; Returns: DE = parsed 16-bit number
; ====================================================================
EVAL_VAL:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR       ; Returns DE = string pointer, C = length

        ; CRITICAL: Save the script pointer! PARSE_NUM_FROM_STRING uses HL internally.
        PUSH HL                     

        CALL PARSE_NUM_FROM_STRING  
        ; Note: PARSE_NUM_FROM_STRING outputs the parsed number in HL, not DE!
        
        EX   DE, HL                 ; Move the parsed number from HL to DE

        POP  HL                     ; Restore the script pointer safely

        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_EXPR: Handles Addition and Subtraction
; ====================================================================
EVAL_EXPR:
        CALL EVAL_TERM          ; Get the first term
.expr_loop:
        CALL SKIP_WS

        LD   A, (HL)
        CP   '+'
        JR   Z, .do_add
        CP   '-'
        JR   Z, .do_sub

        RET                     ; No more + or -, return result in DE

.do_add:
        INC  HL
        PUSH DE
        CALL EVAL_TERM          ; Get the next term
        EX   (SP), HL           ; HL = left side, stack = script ptr
        ADD  HL, DE
        EX   DE, HL             ; Put result back in DE
        POP  HL                 ; Restore script ptr
        JR   .expr_loop         ; Loop to allow chaining (e.g., 1 + 2 + 3)

.do_sub:
        INC  HL
        PUSH DE
        CALL EVAL_TERM
        EX   (SP), HL
        OR   A
        SBC  HL, DE
        EX   DE, HL
        POP  HL
        JR   .expr_loop

; ====================================================================
; EVAL_TERM: Handles Multiplication and Division
; ====================================================================
EVAL_TERM:
        CALL GET_FACTOR         ; Get the first number/variable
.term_loop:
        CALL SKIP_WS
        LD   A, (HL)
        CP   '*'
        JR   Z, .do_mul
        CP   '/'
        JR   Z, .do_div
        RET                     ; No more * or /, return result in DE

.do_mul:
        INC  HL
        PUSH DE                 ; Save left side
        CALL GET_FACTOR         ; Get right side into DE
        EX   (SP), HL           ; HL = left side, stack = script ptr
        CALL MUL16              ; Perform DE = HL * DE
        POP  HL                 ; Restore script ptr
        JR   .term_loop

.do_div:
        INC  HL
        PUSH DE                 ; Save left side
        CALL GET_FACTOR         ; Get right side into DE
        EX   (SP), HL           ; HL = left side, stack = script ptr
        CALL DIV16              ; Perform DE = HL / DE
        POP  HL                 ; Restore script ptr
        JR   .term_loop

; PARSE_NUM: Parses ASCII number at HL into 16-bit integer in DE.
PARSE_NUM:
        LD   A, (HL)
        CP   '-'
        JR   NZ, .parse_unsigned

        INC  HL
        CALL .parse_unsigned

        ; Negate DE (Two's Complement)
        LD   A, D
        CPL
        LD   D, A
        LD   A, E
        CPL
        LD   E, A
        INC  DE
        RET

.parse_unsigned:
        LD   DE, 0
.loop:
        LD   A, (HL)
        CP   '0'
        RET  C
        CP   '9'+1
        RET  NC
        SUB  '0'

        PUSH HL
        LD   H, D
        LD   L, E
        ADD  HL, HL
        PUSH HL
        ADD  HL, HL
        ADD  HL, HL
        POP  BC
        ADD  HL, BC
        LD   C, A
        LD   B, 0
        ADD  HL, BC
        EX   DE, HL

        POP  HL
        INC  HL
        JP   .loop

; PRINT_NUM16: Prints the 16-bit signed integer in DE without leading zeros.
PRINT_NUM16:
        EX   DE, HL

        BIT  7, H
        JR   Z, .positive

        PUSH HL
        LD   E, '-'
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  HL

        LD   A, H
        CPL
        LD   H, A
        LD   A, L
        CPL
        LD   L, A
        INC  HL

.positive:
        LD   B, 0
        LD   DE, 10000
        CALL .digit
        LD   DE, 1000
        CALL .digit
        LD   DE, 100
        CALL .digit
        LD   DE, 10
        CALL .digit

        LD   B, 1
        LD   DE, 1

.digit:
        LD   A, '0'
.sub_loop:
        OR   A
        SBC  HL, DE
        JR   C, .done
        INC  A
        JP   .sub_loop
.done:
        ADD  HL, DE

        CP   '0'
        JR   NZ, .print_it

        LD   A, B
        OR   A
        RET  Z

        LD   A, '0'

.print_it:
        LD   B, 1
        PUSH HL
        PUSH BC
        LD   E, A
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  BC
        POP  HL
        RET

; ====================================================================
; MUL16: 16-bit Integer Multiplication
; Input:  HL = Multiplicand, DE = Multiplier
; Output: DE = Result
; Note:   This shift-and-add algorithm naturally handles 2's 
;         complement signed numbers seamlessly!
; ====================================================================
MUL16:
        LD   B, 16
        LD   C, D
        LD   A, E               ; CA = multiplier
        EX   DE, HL             ; DE = multiplicand
        LD   HL, 0              ; HL = accumulator for result
.mul_loop:
        SRL  C
        RRA                     ; Shift multiplier right, LSB to carry
        JR   NC, .no_add
        ADD  HL, DE             ; Add multiplicand if bit was 1
.no_add:
        SLA  E
        RL   D                  ; Shift multiplicand left
        DJNZ .mul_loop
        EX   DE, HL             ; Move final result into DE
        RET

; ====================================================================
; DIV16: 16-bit Unsigned Integer Division
; Input:  HL = Dividend, DE = Divisor
; Output: DE = Quotient
; ====================================================================
DIV16:
        LD   A, D
        OR   E
        RET  Z                  ; Divide by zero safety: just return 0

        LD   B, 16
        LD   A, H
        LD   C, L               ; AC virtually holds the dividend
        LD   HL, 0              ; Remainder accumulator
.div_loop:
        SLA  C
        RLA                     ; Shift dividend left, bit 7 to carry
        ADC  HL, HL             ; Shift remainder left, pull in carry
        SBC  HL, DE             ; Trial subtraction
        JR   NC, .no_restore
        ADD  HL, DE             ; If it went negative, restore it
        JR   .div_next
.no_restore:
        INC  C                  ; Set bit 0 of quotient
.div_next:
        DJNZ .div_loop
        
        LD   D, A               ; High byte of quotient
        LD   E, C               ; Low byte of quotient
        RET

; ====================================================================
; DATA SECTION
; ====================================================================

MSG_USAGE:      DB "Usage: BASIC <filename>", 13, 10, 0
MSG_ERR_OPEN:   DB "Error: Cannot open script file", 13, 10, 0
MSG_ERR_SYNTAX: DB "Syntax Error", 13, 10, 0
MSG_ERR_GOTO:   DB "Line Not Found", 13, 10, 0
MSG_ERR_BOUNDS: DB "Subscript Out of Range", 13, 10, 0
MSG_ERR_FOR:    DB "FOR/NEXT Error", 13, 10, 0
MSG_ERR_OOM:    DB "Out of Memory", 13, 10, 0

CMD_PRINT:      DB "PRINT", 0
CMD_LET:        DB "LET", 0
CMD_GOTO:       DB "GOTO", 0
CMD_IF:         DB "IF", 0
CMD_THEN:       DB "THEN", 0
CMD_REM:        DB "REM", 0
CMD_INPUT:      DB "INPUT", 0
CMD_LEN:        DB "LEN", 0
CMD_LEFT:       DB "LEFT$", 0
CMD_RIGHT:      DB "RIGHT$", 0
CMD_MID:        DB "MID$", 0
CMD_CHR:        DB "CHR$", 0
CMD_STR:        DB "STR$", 0
CMD_VAL:        DB "VAL", 0
CMD_DIM:        DB "DIM", 0
CMD_FOR:        DB "FOR", 0
CMD_TO:         DB "TO", 0
CMD_STEP:       DB "STEP", 0
CMD_NEXT:       DB "NEXT", 0

FILE_SIZE_BUF:  DS 4, 0

VARIABLES:      DS 52, 0        ; Memory for A-Z (26 variables * 2 bytes)

HEAP_PTR:       DS 2, 0         ; Current heap allocation pointer
FOR_SP:         DS 2, 0         ; Pointer to current top of FOR_STACK
FOR_STACK:      DS 70, 0        ; Stack for up to 10 nested loops (7 bytes per frame)
FOR_STACK_END:  EQU FOR_STACK + 70

TEMP_LEN:       DS 1, 0        ; Temporary storage for string length
TEMP_STRING_PTR: DS 2, 0        ; Temporary pointer storage
TEMP_FOR_VAR:   DS 1, 0         ; Temporarily stores loop variable index
TEMP_FOR_END:   DS 2, 0         ; Temporarily stores loop end value

INPUT_BUFFER:   DS 256, 0      ; Buffer for INPUT and string operations

; String descriptor table - 26 entries for A$ through Z$
; Each entry is 6 bytes:
;   +0: Pointer to heap allocation (2 bytes)
;   +2: String length (1 byte)
;   +3: Reference count (1 byte)
;   +4: Flags (1 byte)
;   +5: Unused padding
STRING_DESC:    DS 26 * 6, 0   ; 156 bytes total for string descriptors

; --- Data Section Variables ---
ARRAY_HEAP_PTR:  DS 2, 0        ; Tracks next free byte in ARRAY_HEAP
