; Z80 Continuous Horizontal Rainbow Gradient (Fixed HSV Math)
; Target: CP/M (.COM file, ORG 0x0100)
; Mode 1: 120x90, 24-bit color (RGB)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
VDP_STAT_PORT   EQU 44H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; Switch to Video Mode 1
        LD A, 1
        OUT (VDP_MODE_PORT), A

FRAME_LOOP:
        ; 1. Check for keypress to exit
        IN A, (CON_STAT_PORT)
        OR A            
        JR NZ, EXIT_PROG 

        ; 2. Copy the "Frame Start" state to "Working" state
        LD HL, F_STATE
        LD DE, W_STATE
        LD BC, 5
        LDIR

        ; 3. Generate the 120-pixel Line Buffer
        LD HL, LINE_BUFFER
        LD B, 120       
        
GEN_LINE_LOOP:
        ; Write Working RGB to the line buffer
        LD A, (W_STATE+0)
		LD (HL), A
		INC HL   ; Red
        LD A, (W_STATE+1)
		LD (HL), A
		INC HL   ; Green
        LD A, (W_STATE+2)
		LD (HL), A
		INC HL   ; Blue
        
        ; Advance the Working state by 1 pixel (Shift by 5)
        PUSH BC
        PUSH HL
        LD IX, W_STATE
        CALL ADV_STATE
        POP HL
        POP BC
        
        DJNZ GEN_LINE_LOOP

        ; 4. Wait for VBlank
        CALL WAIT_VBLANK

        ; 5. Reset VRAM Pointer
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; 6. Blast the Line Buffer to the screen 90 times
        LD D, 90        
DRAW_Y_LOOP:
        LD HL, LINE_BUFFER
        LD C, VDP_DATA  
        LD B, 0
        OTIR
        LD B, 104
        OTIR
        DEC D
        JR NZ, DRAW_Y_LOOP

        ; 7. Advance the whole gradient by 1 step for the next frame
        LD IX, F_STATE
        CALL ADV_STATE

        JP FRAME_LOOP

EXIT_PROG:
        IN A, (CON_DATA_PORT) 
        XOR A
        OUT (VDP_MODE_PORT), A
        JP  $003B

; ---------------------------------------------------------
; ADV_STATE Subroutine (Advances HSV state by 5 color points)
; ---------------------------------------------------------
ADV_STATE:
        LD A, (IX+3)    ; Load Phase
        
        OR A
		JR Z, P0_G_UP
        CP 1
		JR Z, P1_R_DN
        CP 2
		JR Z, P2_B_UP
        CP 3
		JR Z, P3_G_DN
        CP 4
		JR Z, P4_R_UP
        JR P5_B_DN

P0_G_UP:
		LD A, (IX+1)
		ADD A, 5
		LD (IX+1), A
		JR DONE_PH

P1_R_DN:
		LD A, (IX+0)
		SUB 5
		LD (IX+0), A
		JR DONE_PH

P2_B_UP:
		LD A, (IX+2)
		ADD A, 5
		LD (IX+2), A
		JR DONE_PH

P3_G_DN:
		LD A, (IX+1)
		SUB 5
		LD (IX+1), A
		JR DONE_PH

P4_R_UP:
		LD A, (IX+0)
		ADD A, 5
		LD (IX+0), A
		JR DONE_PH

P5_B_DN:
		LD A, (IX+2)
		SUB 5
		LD (IX+2), A
		JR DONE_PH

DONE_PH:
        ; Decrement the 51-step counter
        LD A, (IX+4)
        DEC A
        LD (IX+4), A
        JR NZ, END_ADV  
        
        ; Counter hit 0! Reset to 51 and advance phase
        LD A, 51
        LD (IX+4), A
        
        LD A, (IX+3)
        INC A
        CP 6            
        JR NZ, SAVE_PH
        XOR A           ; Wrap phase back to 0
SAVE_PH:
        LD (IX+3), A
END_ADV:
        RET

; ---------------------------------------------------------
; WAIT_VBLANK Subroutine
; ---------------------------------------------------------
WAIT_VBLANK:
WAIT_VBLANK_OUT:
        IN A, (VDP_STAT_PORT)
        BIT 0, A                
        JR NZ, WAIT_VBLANK_OUT  
WAIT_VBLANK_IN:
        IN A, (VDP_STAT_PORT)
        BIT 0, A                
        JR Z, WAIT_VBLANK_IN    
        RET

; ---------------------------------------------------------
; STATE & MEMORY BUFFERS
; ---------------------------------------------------------
F_STATE:
        DB 255  ; RED
        DB 0    ; GREEN
        DB 0    ; BLUE
        DB 0    ; PHASE
        DB 51   ; COUNTER (51 steps per phase perfectly hits 255)

W_STATE:
        DS 5    

LINE_BUFFER:
        DS 360