; ====================================================================
; WAV Player for Custom Z80 Emulator
; ====================================================================
; Plays an 8-bit, Mono, unsigned PCM WAV file.
; Default target sample rate: 8000 Hz.
;
; Assemble with e.g. pasmo:
; pasmo playwav.asm PLAYWAV.COM
; ====================================================================

        ORG $0100           ; User programs start at 0x0100

        ; --- Constants ---
SYSCALL     EQU $0005
BUFFER      EQU $4000       ; Buffer address in free memory
CHUNK_SIZE  EQU 4096        ; Read chunks of 4KB at a time

        ; Delay constant for Audio Sample Rate
        ; CPU is 3.5 MHz. 
        ; For 8000 Hz:  Use 25 (~7972 Hz real)
        ; For 11025 Hz: Use 17 (~11254 Hz real)
DELAY_CONST EQU 25          

        ; --- 1. Enable the DAC ---
        LD A, 1
        OUT ($30), A        ; Port 0x30 controls DAC enable

        ; --- 2. Open the WAV File ---
        LD C, 33            ; SYS_FS_OPEN
        LD DE, $0090		; ARG1 is filename     
        CALL SYSCALL
        
        OR A                ; Check if A == 0 (Success)
        JR NZ, exit_error   ; If not 0, jump to error handler

        ; --- 3. Skip the 44-byte WAV Header ---
        ; (A standard WAV header is 44 bytes long. We just read it 
        ; into the buffer once and overwrite it on the next read).
        LD C, 34            ; SYS_FS_READ
        LD DE, BUFFER
        LD HL, 44           ; 44 bytes
        CALL SYSCALL

read_loop:
        ; --- 4. Read Audio Chunk into Buffer ---
        LD C, 34            ; SYS_FS_READ
        LD DE, BUFFER
        LD HL, CHUNK_SIZE   ; 4096 bytes
        CALL SYSCALL
        
        PUSH AF             ; Save the return status (0=Success, 1=EOF)

        ; --- 5. Play Audio Chunk ---
        LD HL, BUFFER
        LD B, 0             ; Inner loop runs 256 times
        LD C, CHUNK_SIZE / 256 ; Outer loop runs 16 times (16 * 256 = 4096)

play_byte:
        LD A, (HL)          ; [7t] Fetch audio sample
        OUT ($31), A        ; [11t] Send to DAC port
        INC HL              ; [6t] Advance buffer pointer

        ; --- 6. Cycle-Accurate Delay Loop ---
        ; We need to pause just enough so the samples hit the target rate
        LD E, DELAY_CONST   ; [7t] Set delay length
delay:
        DEC E               ; [4t]
        JR NZ, delay        ; [12t / 7t] Loop until E == 0

        DJNZ play_byte      ; [13t / 8t] Loop 256 times (inner)
        DEC C               ; [4t]
        JR NZ, play_byte    ; [12t / 7t] Loop outer chunk counter

        ; --- 7. Check for End of File ---
        POP AF              ; Retrieve the status from SYS_FS_READ
        CP 1                ; Did we hit EOF? (A == 1)
        JR Z, exit_ok       ; If yes, finish up
        
        JR read_loop        ; Otherwise, grab the next chunk!

exit_ok:
        ; --- 8. Clean up and Exit ---
        LD C, 35            ; SYS_FS_CLOSE
        CALL SYSCALL

        ; Reset DAC to silence (128) and disable
        LD A, 128
        OUT ($31), A
        XOR A
        OUT ($30), A

        ; Exit program
        LD C, 0             ; SYS_EXIT
        CALL SYSCALL

exit_error:
        ; --- 9. Error Handler ---
        LD C, 3             ; SYS_PUTS
        LD DE, ERR_MSG
        CALL SYSCALL
        
        LD C, 0             ; SYS_EXIT
        CALL SYSCALL

        ; --- Data Section ---
ERR_MSG:  DB "Error: Cannot open the file", 13, 10, 0