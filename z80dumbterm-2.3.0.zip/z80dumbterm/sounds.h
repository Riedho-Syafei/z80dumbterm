// psg.h
#include <stdint.h>
#include <stdbool.h>
#include "minimp3.h"

typedef struct {
    uint16_t freq_reload; // 16-bit frequency
    uint16_t timer;       // Cycle countdown
    uint8_t volume;       // 0-15
    uint8_t duty_pattern; // 0=12.5%, 1=25%, 2=50%, 3=75%
    uint8_t phase;        // 0-7 (current step in the duty cycle)
    bool enabled;
} SquareChannel;

typedef struct {
    uint16_t freq_reload;
    uint16_t timer;
    uint8_t volume;
    uint16_t lfsr;        // 15-bit shift register for noise
    bool enabled;
} NoiseChannel;

typedef struct {
    uint8_t sample_value; // The current raw 8-bit PCM value (0-255)
    bool enabled;
} DacChannel;

typedef struct {
    uint8_t input_buffer[16384]; // 16KB FIFO buffer for raw MP3 bytes
    int input_cursor;
    
    short pcm_buffer[MINIMP3_MAX_SAMPLES_PER_FRAME]; // Decoded audio
    int pcm_samples_left;
    int pcm_cursor;
    
    mp3dec_t mp3d;
} Mp3Coprocessor;

extern SquareChannel sq[3];
extern NoiseChannel noise;
extern DacChannel dac;
extern Mp3Coprocessor mp3_hw;

void psg_init(void);
void psg_write_register(uint8_t reg, uint8_t val);
float psg_get_sample(void);
void psg_step_clocks(uint32_t cycles);
void mp3_hw_push_byte(uint8_t val);
float mp3_hw_get_sample(void);
bool mp3_hw_is_full(void);