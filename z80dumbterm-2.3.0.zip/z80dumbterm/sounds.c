// psg.c
#include "sounds.h"
#define MINIMP3_IMPLEMENTATION
#include "minimp3.h"
#include <string.h>

SquareChannel sq[3];
NoiseChannel noise;
DacChannel dac;
Mp3Coprocessor mp3_hw;

// The 4 duty cycle patterns represented as 8 steps
static const uint8_t duty_table[4][8] = {
    {0, 0, 0, 0, 0, 0, 0, 1}, // 12.5%
    {1, 0, 0, 0, 0, 0, 0, 1}, // 25%
    {1, 0, 0, 0, 1, 1, 1, 1}, // 50%
    {0, 1, 1, 1, 1, 1, 1, 1}  // 75%
};

void psg_init(void) {
    // Zero out all channels and seed the LFSR
    noise.lfsr = 0x7FFF;

	// Initialize DAC
    dac.sample_value = 128; // 128 is center/silence for 8-bit unsigned PCM
    dac.enabled = false;

	// Initialize Mp3 Coprocessor
	mp3dec_init(&mp3_hw.mp3d);
    mp3_hw.input_cursor = 0;
    mp3_hw.pcm_samples_left = 0;
}

void psg_step_clocks(uint32_t cycles) {
    // Step Square Channels
    for (int i = 0; i < 3; i++) {
        if (!sq[i].enabled) continue;
        
        if (sq[i].timer <= cycles) {
            sq[i].timer = sq[i].freq_reload;
            sq[i].phase = (sq[i].phase + 1) & 7; // Advance 0-7
        } else {
            sq[i].timer -= cycles;
        }
    }

    // Step Noise Channel
    if (noise.enabled) {
        if (noise.timer <= cycles) {
            noise.timer = noise.freq_reload;
            // Standard LFSR polynomial shift
            uint8_t xor_bit = (noise.lfsr ^ (noise.lfsr >> 1)) & 1;
            noise.lfsr = (noise.lfsr >> 1) | (xor_bit << 14);
        } else {
            noise.timer -= cycles;
        }
    }
}

// Still in psg.c
float psg_get_sample(void) {
    float mixed = 0.0f;
    float max_vol_scale = 1.0f / 15.0f; // Scale 0-15 to 0.0-1.0

    // Mix Squares
    for(int i = 0; i < 3; i++) {
        if(sq[i].enabled && duty_table[sq[i].duty_pattern][sq[i].phase]) {
            mixed += (sq[i].volume * max_vol_scale);
        }
    }

    // Mix Noise (output is inverted bit 0 of LFSR)
    if(noise.enabled && (~noise.lfsr & 1)) {
        mixed += (noise.volume * max_vol_scale);
    }

	// Mix in the DAC if enabled
    if (dac.enabled) {
        // Convert 0...255 to -1.0f...+1.0f
        float dac_float = (dac.sample_value / 127.5f) - 1.0f;
        mixed += dac_float; 
    }

	// Mix in the MP3 coprocessor
    mixed += mp3_hw_get_sample();

    // Average out the 6 channels to prevent clipping (-1.0 to 1.0 mapping)
    // 6 channels maxing out would be 6.0. 
    return (mixed / 6.0f) * 2.0f - 1.0f; 
}

void psg_write_register(uint8_t reg, uint8_t val) {
    // Safety check: ensure we are strictly within 0x00 - 0x0F
    reg &= 0x0F; 
    
    uint8_t ch = reg / 4;       // Channel: 0, 1, 2 (Square), 3 (Noise)
    uint8_t offset = reg % 4;   // Setting: 0 (Freq LSB), 1 (Freq MSB), 2 (Vol/Duty), 3 (Ctrl)

    if (ch < 3) {
        // --- Square Channels (0, 1, 2) ---
        switch (offset) {
            case 0: // Frequency LSB
                sq[ch].freq_reload = (sq[ch].freq_reload & 0xFF00) | val;
                break;
            case 1: // Frequency MSB
                sq[ch].freq_reload = (sq[ch].freq_reload & 0x00FF) | (val << 8);
                break;
            case 2: // Volume and Duty Cycle
                sq[ch].volume = val & 0x0F;              // Lower 4 bits
                sq[ch].duty_pattern = (val >> 6) & 0x03; // Upper 2 bits
                break;
            case 3: // Control (Enable)
                sq[ch].enabled = (val & 0x01);           // Bit 0
                break;
        }
    } else {
        // --- Noise Channel (3) ---
        switch (offset) {
            case 0: // Frequency LSB
                noise.freq_reload = (noise.freq_reload & 0xFF00) | val;
                break;
            case 1: // Frequency MSB
                noise.freq_reload = (noise.freq_reload & 0x00FF) | (val << 8);
                break;
            case 2: // Volume
                noise.volume = val & 0x0F;               // Lower 4 bits
                break;
            case 3: // Control (Enable)
                noise.enabled = (val & 0x01);            // Bit 0
                
                // Optional: Reset LFSR when turned on so percussion sounds hit consistently
                if (noise.enabled) {
                    noise.lfsr = 0x7FFF; 
                }
                break;
        }
    }
}

// 1. The Z80 pushes a byte into the hardware buffer
void mp3_hw_push_byte(uint8_t val) {
    if (mp3_hw.input_cursor < sizeof(mp3_hw.input_buffer)) {
        mp3_hw.input_buffer[mp3_hw.input_cursor++] = val;
    }
}

// 2. Check if the hardware buffer is full
bool mp3_hw_is_full(void) {
    // Leave a small margin (e.g., 1024 bytes) so we don't accidentally overflow
    return mp3_hw.input_cursor >= (sizeof(mp3_hw.input_buffer) - 1024);
}

// 3. The audio thread pulls the next float sample
float mp3_hw_get_sample(void) {
    // If we have decoded PCM ready, play it
    if (mp3_hw.pcm_samples_left > 0) {
        short pcm_val = mp3_hw.pcm_buffer[mp3_hw.pcm_cursor++];
        mp3_hw.pcm_samples_left--;
        // Convert 16-bit signed int to a -1.0f to 1.0f float
        return (pcm_val / 32768.0f); 
    }

    // If out of PCM, try to decode the next frame from the input buffer
    if (mp3_hw.input_cursor > 0) {
        mp3dec_frame_info_t info;
        int samples = mp3dec_decode_frame(&mp3_hw.mp3d, mp3_hw.input_buffer, mp3_hw.input_cursor, mp3_hw.pcm_buffer, &info);

        if (samples > 0) {
            // Frame decoded successfully! 
            // Shift the remaining unprocessed bytes (if any) to the front of the buffer
            int bytes_used = info.frame_bytes;
            mp3_hw.input_cursor -= bytes_used;
            if (mp3_hw.input_cursor > 0) {
                memmove(mp3_hw.input_buffer, mp3_hw.input_buffer + bytes_used, mp3_hw.input_cursor);
            }

            mp3_hw.pcm_samples_left = samples * info.channels;
            mp3_hw.pcm_cursor = 0;
        }
    }
    return 0.0f; // Silence if nothing is playing
}
