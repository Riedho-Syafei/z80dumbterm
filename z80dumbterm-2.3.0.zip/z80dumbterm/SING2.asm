    org 0x0100      ; Program starts at memory address 100

; ==========================================
; TETRIS TYPE-A THEME (Korobeiniki)
; Full 83-second arrangement
;
; Structure:
;   A theme × 2  (25.6s)
;   Bridge × 1   (12.8s)
;   A theme × 2  (25.6s)
;   Bridge × 1   (12.8s)
;   A theme × 0.5 (6.4s)  ← first 4 measures only, as the song fades
;   Total ≈ 83.2s at 200ms/step
;
; Channels:
;   Square 0 (ports 0x20-0x23): Melody
;   Square 1 (ports 0x24-0x27): Bass
;   Square 2 (ports 0x28-0x2B): Harmony
;   Noise    (ports 0x2C-0x2F): Percussion
;
; Freq formula: 437500 / Hz
; Each step = 200ms (DELAY_40MS + DELAY_160MS) at 3.5 MHz
; ==========================================

; --- SILENCE ---
OFF     EQU 0x0000

; --- MELODY (Square 0) ---
M_B4    EQU 0x0375  ; B4  = 493.88 Hz
M_C5    EQU 0x0344  ; C5  = 523.25 Hz
M_D5    EQU 0x02E8  ; D5  = 587.33 Hz
M_E5    EQU 0x0297  ; E5  = 659.26 Hz
M_F5    EQU 0x0272  ; F5  = 698.46 Hz
M_G5    EQU 0x022E  ; G5  = 783.99 Hz
M_A4    EQU 0x03E2  ; A4  = 440.00 Hz
M_A5    EQU 0x01F1  ; A5  = 880.00 Hz
M_FS5   EQU 0x024F  ; F#5 = 739.99 Hz
M_GS4   EQU 0x041D  ; G#4 = 415.30 Hz

; --- BASS (Square 1) ---
B_E3    EQU 0x0A5E  ; E3  = 164.81 Hz
B_A3    EQU 0x07C4  ; A3  = 220.00 Hz
B_D3    EQU 0x0BA3  ; D3  = 146.83 Hz
B_C3    EQU 0x0D10  ; C3  = 130.81 Hz
B_GS3   EQU 0x083A  ; G#3 = 207.65 Hz

; --- HARMONY (Square 2) ---
H_GS3   EQU 0x083A  ; G#3 = 207.65 Hz
H_B3    EQU 0x06EB  ; B3  = 246.94 Hz
H_C4    EQU 0x0688  ; C4  = 261.63 Hz
H_E4    EQU 0x052F  ; E4  = 329.63 Hz
H_F3    EQU 0x0935  ; F3  = 174.61 Hz
H_A3    EQU 0x07C4  ; A3  = 220.00 Hz
H_G3    EQU 0x08B8  ; G3  = 196.00 Hz
H_E3    EQU 0x0A5E  ; E3  = 164.81 Hz

; --- PERCUSSION (Noise) ---
N_K     EQU 0x1500  ; Kick drum
N_S     EQU 0x0200  ; Snare drum


; ==========================================
; MAIN
; ==========================================
START:

    ; === A Theme × 2 ===
    LD HL, SONG_A
    LD B, 64
    CALL PLAY_SECTION
    LD HL, SONG_A
    LD B, 64
    CALL PLAY_SECTION

    ; === Bridge × 1 ===
    LD HL, SONG_BRIDGE
    LD B, 64
    CALL PLAY_SECTION

    ; === A Theme × 2 ===
    LD HL, SONG_A
    LD B, 64
    CALL PLAY_SECTION
    LD HL, SONG_A
    LD B, 64
    CALL PLAY_SECTION

    ; === Bridge × 1 ===
    LD HL, SONG_BRIDGE
    LD B, 64
    CALL PLAY_SECTION

    ; === Final A Theme (first 4 measures = 32 steps) ===
    LD HL, SONG_A
    LD B, 32
    CALL PLAY_SECTION

    ; --- Silence all channels ---
    XOR A
    OUT (0x23), A   ; Disable Square 0
    OUT (0x27), A   ; Disable Square 1
    OUT (0x2B), A   ; Disable Square 2
    OUT (0x33), A   ; Disable Noise

    JP  $003B       ; Return to OS


; ==========================================
; PLAY_SECTION
; Input:  HL = pointer to section data
;         B  = number of steps to play
; Effect: HL is advanced through data.
;         B/C are preserved across the call.
; ==========================================
PLAY_SECTION:
PSEC_LOOP:
    PUSH BC             ; Save step counter

    LD C, 0x20          ; Base port: Square 0
    CALL UPDATE_SQUARE_CHANNEL   ; Ch0 → C=0x24
    CALL UPDATE_SQUARE_CHANNEL   ; Ch1 → C=0x28
    CALL UPDATE_SQUARE_CHANNEL   ; Ch2 → C=0x2C
    CALL UPDATE_NOISE_CHANNEL    ; Ch3 → C=0x30

    CALL DELAY_40MS              ; Short ring-out for percussive attack
    XOR A
    OUT  (0x33), A               ; Mute noise channel early
    CALL DELAY_160MS             ; Rest of the 1/8th note step

    POP BC              ; Restore step counter
    DEC B
    JR NZ, PSEC_LOOP
    RET


; ==========================================
; CHANNEL UPDATE ROUTINES
; Reads one DW from (HL), outputs to
; the 4 ports starting at C, then INC C×4.
; ==========================================
UPDATE_SQUARE_CHANNEL:
    LD E, (HL)
    INC HL
    LD D, (HL)
    INC HL

    LD A, D
    OR E
    JR Z, DISABLE_SQUARE

    LD A, E
    OUT (C), A          ; Freq LSB
    INC C
    LD A, D
    OUT (C), A          ; Freq MSB
    INC C
    LD A, 0x8A          ; Duty=50%, Volume=10
    OUT (C), A
    INC C
    LD A, 0x01
    OUT (C), A          ; Enable channel
    INC C
    RET

DISABLE_SQUARE:
    INC C               ; Skip Freq LSB
    INC C               ; Skip Freq MSB
    INC C               ; Skip Duty/Vol
    XOR A
    OUT (C), A          ; Disable channel
    INC C
    RET


UPDATE_NOISE_CHANNEL:
    LD E, (HL)
    INC HL
    LD D, (HL)
    INC HL

    LD A, D
    OR E
    JR Z, DISABLE_NOISE

    LD A, E
    OUT (C), A          ; Freq LSB
    INC C
    LD A, D
    OUT (C), A          ; Freq MSB
    INC C
    LD A, 0x06          ; Volume = 6
    OUT (C), A
    INC C
    LD A, 0x01
    OUT (C), A          ; Enable channel
    INC C
    RET

DISABLE_NOISE:
    INC C
    INC C
    INC C
    XOR A
    OUT (C), A          ; Disable noise channel
    INC C
    RET


; ==========================================
; DELAY SUBROUTINES  (3.5 MHz clock)
; DELAY_40MS  ≈  40 ms  (26 T-states/iter × 5384  iters)
; DELAY_160MS ≈ 160 ms  (26 T-states/iter × 21538 iters)
; Total per step: ~200 ms = 1/8th note at ~150 BPM
; ==========================================
DELAY_40MS:
    PUSH BC
    LD BC, 5384
    JR DELAY_LOOP_CORE

DELAY_160MS:
    PUSH BC
    LD BC, 21538

DELAY_LOOP_CORE:
    DEC BC              ; 6 T-states
    LD A, B             ; 4 T-states
    OR C                ; 4 T-states
    JR NZ, DELAY_LOOP_CORE  ; 12 T-states (26 total per loop)
    POP BC
    RET


; ==========================================
; TRACKER DATA
; Format per step: DW Melody, Bass, Harmony, Noise
; 64 steps × 4 DW × 2 bytes = 512 bytes per section
; ==========================================

; ------------------------------------------
; SONG_A  –  Main "Korobeiniki" A-theme
; 8 measures × 8 steps = 64 steps
; ------------------------------------------
SONG_A:
    ; --- Measure 1: E B C D C B ---
    DW M_E5, B_E3, OFF,   N_K
    DW M_E5, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_C5, OFF,  OFF,   N_S
    DW M_B4, OFF,  H_B3,  OFF

    ; --- Measure 2: A A C E D C ---
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_C4,  OFF
    DW M_E5, B_A3, OFF,   N_K
    DW M_E5, OFF,  H_E4,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_E4,  OFF

    ; --- Measure 3: B B C D E ---
    DW M_B4, B_E3, OFF,   N_K
    DW M_B4, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_E5, OFF,  H_B3,  OFF

    ; --- Measure 4: C A A (rest) ---
    DW M_C5, B_A3, OFF,   N_K
    DW M_C5, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_E4,  OFF
    DW OFF,  OFF,  OFF,   N_S
    DW OFF,  OFF,  H_E4,  OFF

    ; --- Measure 5: D F A G F (B section) ---
    DW M_D5, B_D3, OFF,   N_K
    DW M_D5, OFF,  H_F3,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_F5, OFF,  H_F3,  OFF
    DW M_A5, B_D3, OFF,   N_K
    DW M_A5, OFF,  H_A3,  OFF
    DW M_G5, OFF,  OFF,   N_S
    DW M_F5, OFF,  H_A3,  OFF

    ; --- Measure 6: E C E D C ---
    DW M_E5, B_C3, OFF,   N_K
    DW M_E5, OFF,  H_E3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_E3,  OFF
    DW M_E5, B_C3, OFF,   N_K
    DW M_E5, OFF,  H_G3,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_G3,  OFF

    ; --- Measure 7: B B C D E ---
    DW M_B4, B_E3, OFF,   N_K
    DW M_B4, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_E5, OFF,  H_B3,  OFF

    ; --- Measure 8: C A A (rest) ---
    DW M_C5, B_A3, OFF,   N_K
    DW M_C5, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_E4,  OFF
    DW OFF,  OFF,  OFF,   N_S
    DW OFF,  OFF,  H_E4,  OFF


; ------------------------------------------
; SONG_BRIDGE  –  Atmospheric bridge section
; 8 measures × 8 steps = 64 steps
;
; Chord motion: Am → E7 → Am → E7 (×2)
;   Am  = A3 bass  + E4 harmony  (A minor)
;   E7  = G#3 bass + B3 harmony  (E dominant 7th)
; Melody runs G5/A5/F#5 passages over the top.
; ------------------------------------------
SONG_BRIDGE:
    ; --- Bridge M1: Am - opening ascent (E5 → G5) ---
    DW OFF,  B_A3,  H_E4,  N_K
    DW M_E5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  OFF
    DW M_E5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  N_K
    DW M_G5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  OFF
    DW M_G5, OFF,   OFF,   N_S

    ; --- Bridge M2: E7 - ascent peak (G5 → A5), descent begins (F#5 → D5) ---
    DW M_G5,  B_GS3, H_B3,  OFF
    DW M_A5,  OFF,   OFF,   OFF
    DW M_A5,  B_GS3, H_B3,  OFF
    DW M_A5,  OFF,   OFF,   OFF
    DW M_A5,  B_GS3, H_B3,  N_K
    DW M_FS5, OFF,   OFF,   OFF
    DW M_FS5, B_GS3, H_B3,  OFF
    DW M_D5,  OFF,   OFF,   N_S

    ; --- Bridge M3: Am - descending figure (F#5 → G5 → B4 → E5) ---
    DW M_FS5, B_A3,  H_E4,  OFF
    DW M_G5,  OFF,   OFF,   OFF
    DW M_G5,  B_A3,  H_E4,  OFF
    DW M_G5,  OFF,   OFF,   OFF
    DW M_G5,  B_A3,  H_E4,  N_K
    DW M_B4,  OFF,   OFF,   OFF
    DW M_E5,  B_A3,  H_C4,  OFF
    DW M_E5,  OFF,   OFF,   N_S

    ; --- Bridge M4: E7 - melody lands on E5, sustained D5 ---
    DW M_E5,  B_GS3, H_B3,  OFF
    DW M_D5,  OFF,   OFF,   OFF
    DW M_D5,  B_GS3, H_B3,  OFF
    DW M_D5,  OFF,   OFF,   OFF
    DW M_D5,  B_GS3, H_B3,  N_K
    DW M_D5,  OFF,   OFF,   OFF
    DW M_D5,  B_GS3, H_B3,  OFF
    DW M_D5,  OFF,   OFF,   N_S

    ; --- Bridge M5: Am - repeat of M1 ---
    DW OFF,  B_A3,  H_E4,  N_K
    DW M_E5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  OFF
    DW M_G5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  N_K
    DW M_E5, OFF,   OFF,   OFF
    DW M_G5, B_A3,  H_E4,  OFF
    DW M_G5, OFF,   OFF,   N_S

    ; --- Bridge M6: E7 - repeat of M2 ---
    DW M_G5,  B_GS3, H_B3,  OFF
    DW M_A5,  OFF,   OFF,   OFF
    DW M_A5,  B_GS3, H_B3,  OFF
    DW M_A5,  OFF,   OFF,   OFF
    DW M_A5,  B_GS3, H_B3,  N_K
    DW M_FS5, OFF,   OFF,   OFF
    DW M_FS5, B_GS3, H_B3,  OFF
    DW M_FS5, OFF,   OFF,   N_S

    ; --- Bridge M7: Am - descent, settling to A4 ---
    DW M_FS5, B_A3,  H_E4,  OFF
    DW M_G5,  OFF,   OFF,   OFF
    DW M_G5,  B_A3,  H_E4,  OFF
    DW M_E5,  OFF,   OFF,   OFF
    DW M_G5,  B_A3,  H_E4,  N_K
    DW M_A4,  OFF,   OFF,   OFF
    DW M_A4,  B_A3,  H_E4,  OFF
    DW M_A4,  OFF,   OFF,   N_S

    ; --- Bridge M8: Am/E - chromatic settle, lead back to A theme ---
    DW M_A4,  B_A3,  H_C4,  OFF
    DW M_A4,  OFF,   OFF,   OFF
    DW M_GS4, B_A3,  H_C4,  OFF
    DW M_GS4, OFF,   OFF,   OFF
    DW M_A4,  B_A3,  H_E4,  N_K
    DW M_A4,  OFF,   OFF,   OFF
    DW M_A4,  B_A3,  H_E4,  OFF
    DW M_A4,  OFF,   OFF,   OFF
