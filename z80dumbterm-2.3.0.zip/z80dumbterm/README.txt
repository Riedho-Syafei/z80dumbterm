What's new:
Added MP3 player and WAV player
There are some musics in B: drive

BASIC interpreter
Statements:
PRINT (can evaluate expression)
LET (supports add, sub, mult, div, evaluating expression)
INPUT (string)
GOTO
IF ... THEN
DIM
FOR TO ... NEXT

String expressions:
LEFT$
MID$
RIGHT$
LEN
CHR$
STR$
VAL

CCP Version 1.0.0

CCP supported commands:

internal commands:
DIR
TYPE <filename>
EXIT
CREATE <filename>
DEL <filename>
REN <old filename> <new filename>

transient commands:
DISKSPACE [drive letter]
COPYTO [src drive letter, dest drive letter] [src filename] [dest filename]
PRINT [filename]
