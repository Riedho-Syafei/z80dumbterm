		ORG $0100           ; Standard starting address for CP/M-like programs

        ; ----------------------------------------------------
        ; 1. Print Startup Message
        ; ----------------------------------------------------
        LD   C, 3           ; SYS_PUTS
        LD   DE, MSG_START
        CALL $0005

        ; ----------------------------------------------------
        ; 2. Open the MP3 File
        ; ----------------------------------------------------
        LD   C, 33          ; SYS_FS_OPEN
        LD   DE, $0090      ; Pointer to null-terminated filename
        CALL $0005
        OR   A              ; A = 0 on success, FF on failure
        JR   NZ, ERROR_OPEN

READ_FILE_LOOP:
        ; ----------------------------------------------------
        ; 3. Clear the buffer to 0 
        ; We do this so if we hit EOF and get a partial chunk, 
        ; the rest of the buffer fed to the MP3 hardware is 
        ; just padded with zeroes (harmless silence to MP3s).
        ; ----------------------------------------------------
        LD   HL, BUFFER
        LD   (HL), 0
        LD   DE, BUFFER + 1
        LD   BC, 127
        LDIR                ; Z80 block copy (propagates the 0)

        ; ----------------------------------------------------
        ; 4. Read a 128-byte chunk from the file
        ; ----------------------------------------------------
        LD   C, 34          ; SYS_FS_READ
        LD   DE, BUFFER     ; Destination buffer
        LD   HL, 128        ; Number of bytes to read
        CALL $0005

        PUSH AF             ; Save return code (0=OK, 1=EOF, FF=Fail)

        ; Check for hard read error
        CP   $FF
        JR   Z, ERROR_READ_POP

        ; ----------------------------------------------------
        ; 5. Feed the chunk to the MP3 Coprocessor
        ; ----------------------------------------------------
        LD   HL, BUFFER     ; Pointer to the chunk
        LD   B, 128         ; Bytes to process

FEED_LOOP:
        ; Poll the MP3 hardware state
        IN   A, ($32)       ; Read from Port 0x32
        OR   A              ; 0x00 = Ready, 0xFF = Buffer Full
        JR   NZ, FEED_LOOP  ; If not 0, keep waiting for space

        ; Hardware has space, send 1 byte
        LD   A, (HL)
        OUT  ($32), A       ; Write byte to Port 0x32
        
        INC  HL             ; Advance buffer pointer
        DJNZ FEED_LOOP      ; Decrement B, loop if not zero

        ; ----------------------------------------------------
        ; 6. Check if we've reached End-Of-File
        ; ----------------------------------------------------
        POP  AF             ; Retrieve SYS_FS_READ return code
        CP   1              ; Did we hit EOF?
        JR   Z, PLAY_DONE

        ; Not EOF, read next chunk
        JR   READ_FILE_LOOP

PLAY_DONE:
        ; ----------------------------------------------------
        ; 7. Close the file and Exit
        ; ----------------------------------------------------
        LD   C, 35          ; SYS_FS_CLOSE
        CALL $0005

        LD   C, 3           ; SYS_PUTS
        LD   DE, MSG_DONE
        CALL $0005

        LD   C, 0           ; SYS_EXIT
        CALL $0005

; ============================================================
; Error Handlers
; ============================================================
ERROR_READ_POP:
        POP  AF             ; Clean up stack before exiting
ERROR_READ:
        LD   C, 3
        LD   DE, MSG_ERR_RD
        CALL $0005
        LD   C, 0           ; SYS_EXIT
        CALL $0005

ERROR_OPEN:
        LD   C, 3
        LD   DE, MSG_ERR_OP
        CALL $0005
        LD   C, 0           ; SYS_EXIT
        CALL $0005


; ============================================================
; Data Section
; ============================================================

MSG_START:  DB "Playing MP3 through Coprocessor...", 13, 10, 0
MSG_DONE:   DB "Playback finished.", 13, 10, 0
MSG_ERR_OP: DB "Error: Could not open the audio file", 13, 10, 0
MSG_ERR_RD: DB "Error: Disk read failed.", 13, 10, 0

; 128-byte chunk buffer
BUFFER:     DS 128, 0