		ORG 0100h       ; Standard CP/M .COM origin

START:  LD DE, 1000     ; Duration counter (number of full sound waves)

LOOP:   
        ; 1. Set speaker HIGH
        LD A, 01h
        OUT (20h), A

        ; 2. Delay for the first half of the waveform
        CALL DELAY

        ; 3. Set speaker LOW
        LD A, 00h
        OUT (20h), A

        ; 4. Delay for the second half of the waveform
        CALL DELAY

        ; 5. Decrement duration counter and loop if not zero
        DEC DE
        LD A, D
        OR E            ; Logical OR to check if DE is 0000h
        JR NZ, LOOP     ; If not zero, jump back to LOOP

        ; 6. Exit cleanly to CP/M
        JP $003B             

; ---------------------------------------------------------
; Delay Subroutine
; The value in register B controls the pitch.
; A smaller value = shorter delay = higher frequency tone.
; ---------------------------------------------------------
DELAY:  
        LD B, 255       ; Pitch control (150 is approx 1kHz at 4MHz)
WAIT:   DJNZ WAIT       ; Decrement B, jump to WAIT if not zero
        RET