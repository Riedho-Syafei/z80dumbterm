	ORG 0100h               ; Standard origin for CP/M-like binaries

    ; --- Constants ---
COLOR_BG    EQU 0x00    ; Black
COLOR_SNAKE EQU 0x1C    ; Green (000 111 00 -> R=0, G=7, B=0)
COLOR_FOOD  EQU 0xE0    ; Red   (111 000 00 -> R=7, G=0, B=0)
    
GRID_W      EQU 55      ; 220 / 4
GRID_H      EQU 36      ; 144 / 4
    
PORT_KBD_ST EQU 00h     ; Keyboard Status
PORT_KBD_DT EQU 01h     ; Keyboard Data
PORT_TIMER  EQU 08h     ; Timer for random seed
PORT_VMODE  EQU 40h     ; VDP Mode
PORT_VADDRL EQU 41h     ; VDP Address Low
PORT_VADDRH EQU 42h     ; VDP Address High
PORT_VDATA  EQU 43h     ; VDP Data

START:
    ; 1. Initialize Graphics Mode 2 (220x144, 8bpp)
    ld a, 2
    out (PORT_VMODE), a

    ; 2. Clear the screen (VRAM is 32KB, 220*144 = 31680 bytes)
    call CLEAR_SCREEN

    ; 3. Initialize Snake State
    ld a, 27
    ld (SNAKE_X), a         ; Start head at logical X = 27
    ld a, 18
    ld (SNAKE_Y), a         ; Start head at logical Y = 18
    
    xor a
    ld (HEAD_PTR), a
    ld (TAIL_PTR), a
    
    ld a, 1
    ld (DIR), a             ; Initial direction: 1 = Right
	ld (LAST_DIR), a

    ; Draw initial head
    ld b, 27
    ld c, 18
    ld a, COLOR_SNAKE
    call DRAW_CELL

    ; 4. Spawn the first food
    call SPAWN_FOOD

MAIN_LOOP:
    call DELAY              ; Pace the game (slow down the 3.5MHz CPU)
    call READ_INPUT         ; Check for WASD keys

    ; --- Lock in the physical move ---
    ld a, (DIR)
    ld (LAST_DIR), a
	
	; --- Calculate new head position ---
    ld a, (HEAD_PTR)
    ld e, a
    ld d, 0
    ld hl, SNAKE_X
    add hl, de
    ld b, (hl)              ; B = Current X
    ld hl, SNAKE_Y
    add hl, de
    ld c, (hl)              ; C = Current Y

    ; Apply direction delta to (B, C)
    ld a, (DIR)
    cp 0
    jr z, .move_up
    cp 1
    jr z, .move_right
    cp 2
    jr z, .move_down
    cp 3
    jr z, .move_left

.move_up:
	dec c
	jr .check_bounds

.move_right:
	inc b
	jr .check_bounds

.move_down:
	inc c
	jr .check_bounds

.move_left:
	dec b
	jr .check_bounds

.check_bounds:
    ; Wall Collision: Check X
    ld a, b
    cp GRID_W
    jp nc, GAME_OVER        ; if X >= 55 or X < 0 (wraps to 255)
    
    ; Wall Collision: Check Y
    ld a, c
    cp GRID_H
    jp nc, GAME_OVER        ; if Y >= 36 or Y < 0

    ; Check if moving onto Food
    ld a, (FOOD_X)
    cp b
    jr nz, .not_food
    ld a, (FOOD_Y)
    cp c
    jr nz, .not_food

    ; --- EATING FOOD ---
    ; Don't erase tail, just advance head (increases length)
    call ADVANCE_HEAD
    call SPAWN_FOOD
	CALL SFX_EAT
    jp MAIN_LOOP

.not_food:
    ; --- NORMAL MOVE ---
    ; 1. Erase the tail cell to free up the space
    push bc
	call ERASE_TAIL
	pop  bc
    
    ; 2. Check Self-Collision (Now safe to check after tail shrinks)
    push bc
	call CHECK_COLLISION
	pop  bc
    
    ; 3. Draw and register the new head
    call ADVANCE_HEAD
    jp MAIN_LOOP


; ==========================================
;               SUBROUTINES
; ==========================================

ADVANCE_HEAD:
    ; B = New X, C = New Y
    push bc
	ld a, COLOR_SNAKE
    call DRAW_CELL          ; Draw to screen
	pop  bc

    ld a, (HEAD_PTR)
    inc a
    ld (HEAD_PTR), a        ; Ring buffer advance
    
    ld e, a
    ld d, 0
    ld hl, SNAKE_X
    add hl, de
    ld (hl), b              ; Store new X
    ld hl, SNAKE_Y
    add hl, de
    ld (hl), c              ; Store new Y
    ret

ERASE_TAIL:
    ld a, (TAIL_PTR)
    ld e, a
    ld d, 0
    ld hl, SNAKE_X
    add hl, de
    ld b, (hl)              ; Tail X
    ld hl, SNAKE_Y
    add hl, de
    ld c, (hl)              ; Tail Y

    ld a, COLOR_BG
    call DRAW_CELL          ; Overwrite with black

    ld a, (TAIL_PTR)
    inc a
    ld (TAIL_PTR), a        ; Move tail pointer forward
    ret

CHECK_COLLISION:
    ; Checks if VRAM at logical block (B, C) is already Green
    call SET_ADDR_FOR_CELL
    in a, (PORT_VDATA)
    cp COLOR_SNAKE
    jp z, GAME_OVER
    ret

SPAWN_FOOD:
.retry:
    in a, (PORT_TIMER)      ; Grab elapsed time as a random seed
.mod_x:
    cp GRID_W
    jr c, .x_ok
    sub GRID_W
    jr .mod_x
.x_ok:
    ld b, a
    ld (FOOD_X), a

    in a, (PORT_TIMER)
    add a, b                ; Mix seed slightly for Y
.mod_y:
    cp GRID_H
    jr c, .y_ok
    sub GRID_H
    jr .mod_y
.y_ok:
    ld c, a
    ld (FOOD_Y), a

    ; Check if this spot is currently empty in VRAM
    push bc
	call SET_ADDR_FOR_CELL
	pop  bc
    in a, (PORT_VDATA)
    or a                    ; Is it 0 (Black)?
    jr nz, .retry           ; If it hit the snake, roll again

    ld a, COLOR_FOOD
    call DRAW_CELL
    ret

READ_INPUT:
.poll:
    in a, (PORT_KBD_ST)
    or a
    ret z                   ; Exit if keyboard buffer is empty

    in a, (PORT_KBD_DT)     ; Pop the keycode
    ld b, a
    ld a, (LAST_DIR)
    ld c, a                 ; C = last physically moved direction

    ld a, b
    cp 'w'
    jr z, .up
    cp 's'
    jr z, .down
    cp 'a'
    jr z, .left
    cp 'd'
    jr z, .right
    jr .poll                ; Flush any other unknown keys

.up:
    ld a, c
    cp 2                    ; Prevent 180 degree suicide
    jr z, .poll
    ld a, 0
    ld (DIR), a
    jr .poll
.down:
    ld a, c
    cp 0
    jr z, .poll
    ld a, 2
    ld (DIR), a
    jr .poll
.left:
    ld a, c
    cp 1
    jr z, .poll
    ld a, 3
    ld (DIR), a
    jr .poll
.right:
    ld a, c
    cp 3
    jr z, .poll
    ld a, 1
    ld (DIR), a
    jr .poll

DELAY:
    ; Nested loop. Tweak outer 'B' to change game speed.
    ld b, 60
.d1:
    ld c, 255
.d2:
    nop
    nop
    dec c
    jr nz, .d2
    djnz .d1
    ret

GAME_OVER:
    CALL SFX_DIE
	
	XOR  A
    OUT  (PORT_VMODE), A      ; Restore text mode

	jp $003B                    ; Jump to WBOOT (exit)

CLEAR_SCREEN:
    xor a
    out (PORT_VADDRL), a
    out (PORT_VADDRH), a
    ld de, 31680            ; Total pixel count
.cl_loop:
    xor a
    out (PORT_VDATA), a
    dec de
    ld a, d
    or e
    jr nz, .cl_loop
    ret

; ==========================================
;           GRAPHICS PRIMITIVES
; ==========================================

; Draws a 4x4 block
; Inputs: B = logical X, C = logical Y, A = Color
DRAW_CELL:
    ld (TEMP_COLOR), a
    
    ; Pixel X = B * 4
    ld a, b
    add a, a
    add a, a
    ld (TEMP_X), a

    ; Pixel Y = C * 4
    ld a, c
    add a, a
    add a, a
    ld c, a                 ; C now holds the Pixel Y counter

    ld b, 4                 ; We draw 4 rows per cell
.row_loop:
    push bc

    ; Address = (C * 220) + TEMP_X
    ld b, c
    ld hl, 0
    ld a, b
    or a
    jr z, .mul_zero
    ld de, 220
.mul_loop:
    add hl, de
    djnz .mul_loop
.mul_zero:
    
    ld a, (TEMP_X)
    ld e, a
    ld d, 0
    add hl, de              ; HL now holds absolute VRAM address

    ; Push address to VDP
    ld a, l
    out (PORT_VADDRL), a
    ld a, h
    out (PORT_VADDRH), a

    ; Fast block fill via auto-increment
    ld a, (TEMP_COLOR)
    out (PORT_VDATA), a
    out (PORT_VDATA), a
    out (PORT_VDATA), a
    out (PORT_VDATA), a

    pop bc
    inc c                   ; Move to the next horizontal pixel line
    djnz .row_loop
    ret

; Calculates the top-left VRAM address for cell (B,C)
; Used for collision checking and bounds querying
SET_ADDR_FOR_CELL:
    ; Pixel X = B * 4
    ld a, b
    add a, a
    add a, a
    ld e, a
    ld d, 0                 ; DE = Pixel X

    ; Pixel Y = C * 4
    ld a, c
    add a, a
    add a, a
    ld b, a                 ; B = Pixel Y multiplier

    ; HL = B * 220
    ld hl, 0
    ld a, b
    or a
    jr z, .mul_zero2
    push de
    ld de, 220
.mul_loop2:
    add hl, de
    djnz .mul_loop2
    pop de
.mul_zero2:
    add hl, de

    ld a, l
    out (PORT_VADDRL), a
    ld a, h
    out (PORT_VADDRH), a
    ret

; ==========================================
;               SOUND EFFECTS
; ==========================================

SFX_EAT:  
    ; ==========================================
    ; Initialize Channel 0
    ; ==========================================
    ld a, 0x8A          ; Duty = 50% (10), Volume = 10 (1010)
    out (0x22), a
    
    ld a, 0x01          ; Enable Channel 0
    out (0x23), a

    ; ==========================================
    ; Pitch Sweep Setup
    ; ==========================================
    ; We use HL to track the 16-bit frequency divider.
    ; Higher divider = lower pitch. We will start at 0x0A00.
    ld hl, 0x0500       

.sweep_loop:
    ; 1. Output the current frequency in HL to Channel 0
    ld a, l             ; Load Freq LSB
    out (0x20), a
    
    ld a, h             ; Load Freq MSB
    out (0x21), a
    
    ; 2. Very short delay before the next pitch change
    ; Using 'djnz' loop. ~145 iterations * 13 T-states ≈ 1885 T-states
    ld b, 145           
.delay_loop:
    djnz .delay_loop     
    
    ; 3. Slide the pitch up
    dec hl              ; Decrease the divider (increases the pitch)
    
    ; 4. Check if we've reached the target end pitch
    ; When HL decrements from 0x0300 to 0x02FF, H becomes 0x02.
    ld a, h             
    cp 0x00             ; Compare MSB to 0x02
    jr nz, .sweep_loop   ; If not 0x02, loop back and keep ascending

    ; ==========================================
    ; Cleanup
    ; ==========================================
    ld a, 0x00          ; Disable Channel 0
    out (0x23), a

    ; 7. Exit cleanly 
    RET

SFX_DIE:  
        
	; ==========================================
    ; Initialize Noise Channel (Channel 3)
    ; ==========================================
    
    ; Set Frequency LSB
    ld a, 0xFF          ; Set to a high value for a deep rumble
    out (0x2C), a       
    
    ; Set Frequency MSB
    ld a, 0x0F          ; Complete the 16-bit high divider
    out (0x2D), a       
    
    ; Set Initial Volume to Max (15)
    ld a, 0x0F          
    out (0x2E), a       
    
    ; Enable Channel 3 (Bit 0 = 1)
    ; In your emulator, this also resets the LFSR for a consistent "hit"
    ld a, 0x01          
    out (0x2F), a       

    ; ==========================================
    ; Volume Fade Envelope (2 seconds total)
    ; ==========================================
    ; We start with volume at 15 in register D.
    ; We will decrement this 15 times until it hits 0.
    ld d, 15            

.fade_loop:
    ; --- Delay Sub-loop ---
    ; To get a 2-second total duration across 15 fade steps on a 3.5 MHz CPU,
    ; each step needs to take ~466,666 T-states (3,500,000 * 2 / 15).
    ; The inner loop takes 26 T-states. 466,666 / 26 = ~17948 (0x461C).
    
    ld bc, 17948        ; Load delay counter
    
.delay_loop:
    dec bc              ; 6 T-states
    ld a, b             ; 4 T-states
    or c                ; 4 T-states
    jr nz, .delay_loop   ; 12 T-states (7 on the final pass)

    ; --- Decrease Volume ---
    dec d               ; Lower the volume by 1
    ld a, d             ; Move new volume to A
    out (0x2E), a       ; Update the PSG volume register

    ; Check if volume has reached 0
    jr nz, .fade_loop    ; If not zero, wait and decrement again

    ; ==========================================
    ; Cleanup
    ; ==========================================
    ld a, 0x00          ; Disable Channel 3
    out (0x2F), a

    ; 4. Exit cleanly 
    RET


; ==========================================
;              MEMORY ALLOCATION
; ==========================================
SNAKE_X:    DEFS 256
SNAKE_Y:    DEFS 256
HEAD_PTR:   DB 0
TAIL_PTR:   DB 0
DIR:        DB 0
LAST_DIR:   DB 0
FOOD_X:     DB 0
FOOD_Y:     DB 0
TEMP_X:     DB 0
TEMP_COLOR: DB 0