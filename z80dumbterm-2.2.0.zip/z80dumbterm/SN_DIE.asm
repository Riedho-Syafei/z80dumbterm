	org 0x0100          ; Program starts at memory address 100

SFX_DIE:
    ; ==========================================
    ; Initialize Noise Channel (Channel 3)
    ; ==========================================
    
    ; Set Frequency LSB
    ld a, 0xFF          ; Set to a high value for a deep rumble
    out (0x2C), a       
    
    ; Set Frequency MSB
    ld a, 0x0F          ; Complete the 16-bit high divider
    out (0x2D), a       
    
    ; Set Initial Volume to Max (15)
    ld a, 0x0F          
    out (0x2E), a       
    
    ; Enable Channel 3 (Bit 0 = 1)
    ; In your emulator, this also resets the LFSR for a consistent "hit"
    ld a, 0x01          
    out (0x2F), a       

    ; ==========================================
    ; Volume Fade Envelope (2 seconds total)
    ; ==========================================
    ; We start with volume at 15 in register D.
    ; We will decrement this 15 times until it hits 0.
    ld d, 15            

.fade_loop:
    ; --- Delay Sub-loop ---
    ; To get a 2-second total duration across 15 fade steps on a 3.5 MHz CPU,
    ; each step needs to take ~466,666 T-states (3,500,000 * 2 / 15).
    ; The inner loop takes 26 T-states. 466,666 / 26 = ~17948 (0x461C).
    
    ld bc, 17948        ; Load delay counter
    
.delay_loop:
    dec bc              ; 6 T-states
    ld a, b             ; 4 T-states
    or c                ; 4 T-states
    jr nz, .delay_loop   ; 12 T-states (7 on the final pass)

    ; --- Decrease Volume ---
    dec d               ; Lower the volume by 1
    ld a, d             ; Move new volume to A
    out (0x2E), a       ; Update the PSG volume register

    ; Check if volume has reached 0
    jr nz, .fade_loop    ; If not zero, wait and decrement again

    ; ==========================================
    ; Cleanup
    ; ==========================================
    ld a, 0x00          ; Disable Channel 3
    out (0x2F), a

    jp $003B            ; Exit program (assumes CP/M-like warm boot)