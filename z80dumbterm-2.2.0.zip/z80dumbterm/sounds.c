// psg.c
#include "sounds.h"

SquareChannel sq[3];
NoiseChannel noise;

// The 4 duty cycle patterns represented as 8 steps
static const uint8_t duty_table[4][8] = {
    {0, 0, 0, 0, 0, 0, 0, 1}, // 12.5%
    {1, 0, 0, 0, 0, 0, 0, 1}, // 25%
    {1, 0, 0, 0, 1, 1, 1, 1}, // 50%
    {0, 1, 1, 1, 1, 1, 1, 1}  // 75%
};

void psg_init(void) {
    // Zero out all channels and seed the LFSR
    noise.lfsr = 0x7FFF; 
}

void psg_step_clocks(uint32_t cycles) {
    // Step Square Channels
    for (int i = 0; i < 3; i++) {
        if (!sq[i].enabled) continue;
        
        if (sq[i].timer <= cycles) {
            sq[i].timer = sq[i].freq_reload;
            sq[i].phase = (sq[i].phase + 1) & 7; // Advance 0-7
        } else {
            sq[i].timer -= cycles;
        }
    }

    // Step Noise Channel
    if (noise.enabled) {
        if (noise.timer <= cycles) {
            noise.timer = noise.freq_reload;
            // Standard LFSR polynomial shift
            uint8_t xor_bit = (noise.lfsr ^ (noise.lfsr >> 1)) & 1;
            noise.lfsr = (noise.lfsr >> 1) | (xor_bit << 14);
        } else {
            noise.timer -= cycles;
        }
    }
}

// Still in psg.c
float psg_get_sample(void) {
    float mixed = 0.0f;
    float max_vol_scale = 1.0f / 15.0f; // Scale 0-15 to 0.0-1.0

    // Mix Squares
    for(int i = 0; i < 3; i++) {
        if(sq[i].enabled && duty_table[sq[i].duty_pattern][sq[i].phase]) {
            mixed += (sq[i].volume * max_vol_scale);
        }
    }

    // Mix Noise (output is inverted bit 0 of LFSR)
    if(noise.enabled && (~noise.lfsr & 1)) {
        mixed += (noise.volume * max_vol_scale);
    }

    // Average out the 4 channels to prevent clipping (-1.0 to 1.0 mapping)
    // 4 channels maxing out would be 4.0. 
    return (mixed / 4.0f) * 2.0f - 1.0f; 
}

void psg_write_register(uint8_t reg, uint8_t val) {
    // Safety check: ensure we are strictly within 0x00 - 0x0F
    reg &= 0x0F; 
    
    uint8_t ch = reg / 4;       // Channel: 0, 1, 2 (Square), 3 (Noise)
    uint8_t offset = reg % 4;   // Setting: 0 (Freq LSB), 1 (Freq MSB), 2 (Vol/Duty), 3 (Ctrl)

    if (ch < 3) {
        // --- Square Channels (0, 1, 2) ---
        switch (offset) {
            case 0: // Frequency LSB
                sq[ch].freq_reload = (sq[ch].freq_reload & 0xFF00) | val;
                break;
            case 1: // Frequency MSB
                sq[ch].freq_reload = (sq[ch].freq_reload & 0x00FF) | (val << 8);
                break;
            case 2: // Volume and Duty Cycle
                sq[ch].volume = val & 0x0F;              // Lower 4 bits
                sq[ch].duty_pattern = (val >> 6) & 0x03; // Upper 2 bits
                break;
            case 3: // Control (Enable)
                sq[ch].enabled = (val & 0x01);           // Bit 0
                break;
        }
    } else {
        // --- Noise Channel (3) ---
        switch (offset) {
            case 0: // Frequency LSB
                noise.freq_reload = (noise.freq_reload & 0xFF00) | val;
                break;
            case 1: // Frequency MSB
                noise.freq_reload = (noise.freq_reload & 0x00FF) | (val << 8);
                break;
            case 2: // Volume
                noise.volume = val & 0x0F;               // Lower 4 bits
                break;
            case 3: // Control (Enable)
                noise.enabled = (val & 0x01);            // Bit 0
                
                // Optional: Reset LFSR when turned on so percussion sounds hit consistently
                if (noise.enabled) {
                    noise.lfsr = 0x7FFF; 
                }
                break;
        }
    }
}
