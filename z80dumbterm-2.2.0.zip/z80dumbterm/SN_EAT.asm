	org 0x0100          ; Program starts at memory address 100

SFX_EAT:
    ; ==========================================
    ; Initialize Channel 0
    ; ==========================================
    ld a, 0x8A          ; Duty = 50% (10), Volume = 10 (1010)
    out (0x22), a
    
    ld a, 0x01          ; Enable Channel 0
    out (0x23), a

    ; ==========================================
    ; Pitch Sweep Setup
    ; ==========================================
    ; We use HL to track the 16-bit frequency divider.
    ; Higher divider = lower pitch. We will start at 0x0A00.
    ld hl, 0x0500       

.sweep_loop:
    ; 1. Output the current frequency in HL to Channel 0
    ld a, l             ; Load Freq LSB
    out (0x20), a
    
    ld a, h             ; Load Freq MSB
    out (0x21), a
    
    ; 2. Very short delay before the next pitch change
    ; Using 'djnz' loop. ~145 iterations * 13 T-states ≈ 1885 T-states
    ld b, 145           
.delay_loop:
    djnz .delay_loop     
    
    ; 3. Slide the pitch up
    dec hl              ; Decrease the divider (increases the pitch)
    
    ; 4. Check if we've reached the target end pitch
    ; When HL decrements from 0x0300 to 0x02FF, H becomes 0x02.
    ld a, h             
    cp 0x00             ; Compare MSB to 0x02
    jr nz, .sweep_loop   ; If not 0x02, loop back and keep ascending

    ; ==========================================
    ; Cleanup
    ; ==========================================
    ld a, 0x00          ; Disable Channel 0
    out (0x23), a

    jp $003B            ; Exit program