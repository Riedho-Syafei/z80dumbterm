What's new:
Removed 1-bit speaker.

Added sound card.
3 square waves channel
1 noise channel

Added BASIC interpreter (and some test programs and game).
Statements:
PRINT (string or variables, can't evaluate expression)
LET (supports adding, subtracting, evaluating expression)
INPUT (string)
GOTO
IF ... THEN

String expressions:
LEFT$
MID$
RIGHT$
LEN
CHR$
STR$
VAL

Redesigned SYS_FS_LIST
It prints the files in 3 column with its respective file sizes!

CCP Version 1.0.0

CCP supported commands:

internal commands:
DIR
TYPE <filename>
EXIT
CREATE <filename>
DEL <filename>
REN <old filename> <new filename>

transient commands:
DISKSPACE [drive letter]
COPYTO [src drive letter, dest drive letter] [src filename] [dest filename]
PRINT [filename]
