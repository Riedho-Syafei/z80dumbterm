// psg.h
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    uint16_t freq_reload; // 16-bit frequency
    uint16_t timer;       // Cycle countdown
    uint8_t volume;       // 0-15
    uint8_t duty_pattern; // 0=12.5%, 1=25%, 2=50%, 3=75%
    uint8_t phase;        // 0-7 (current step in the duty cycle)
    bool enabled;
} SquareChannel;

typedef struct {
    uint16_t freq_reload;
    uint16_t timer;
    uint8_t volume;
    uint16_t lfsr;        // 15-bit shift register for noise
    bool enabled;
} NoiseChannel;

extern SquareChannel sq[3];
extern NoiseChannel noise;

void psg_init(void);
void psg_write_register(uint8_t reg, uint8_t val);
float psg_get_sample(void);
void psg_step_clocks(uint32_t cycles);