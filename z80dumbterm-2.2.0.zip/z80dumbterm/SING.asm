		org 0x0100      ; Program starts at memory address 100

; ==========================================
; CONSTANTS / FREQUENCIES
; Calculated as: 437500 / Desired_Hz
; ==========================================
OFF     EQU 0x0000

; Melody Frequencies (Square 0)
M_E5    EQU 0x0297
M_D5    EQU 0x02E8
M_C5    EQU 0x0344
M_B4    EQU 0x0375
M_A4    EQU 0x03E2
M_F5    EQU 0x0272
M_A5    EQU 0x01F1
M_G5    EQU 0x022E

; Bass Frequencies (Square 1)
B_E3    EQU 0x0A5E
B_A3    EQU 0x07C4
B_D3    EQU 0x0BA3
B_C3    EQU 0x0D10

; Harmony Frequencies (Square 2)
H_GS3   EQU 0x083A  ; G#3
H_B3    EQU 0x06EB
H_C4    EQU 0x0688
H_E4    EQU 0x052F
H_F3    EQU 0x0935
H_A3    EQU 0x07C4
H_G3    EQU 0x08B8
H_E3    EQU 0x0A5E

; Noise LFSR Reloads (Noise Channel)
; Lower number = higher pitch
N_K     EQU 0x1500  ; Kick drum
N_S     EQU 0x0200  ; Snare drum

; ==========================================
; MAIN PLAYER LOOP
; ==========================================
START:
SONG_LOOP:
    LD HL, SONG_DATA
    LD B, 64       ; 64 steps in the song (8 measures * 8 steps)

PLAY_STEP_LOOP:
    PUSH BC        ; Save our step counter

    LD C, 0x20     ; Start with Channel 0 base port (0x20)
    CALL UPDATE_SQUARE_CHANNEL  ; Updates Ch 0, advances C to 0x24
    CALL UPDATE_SQUARE_CHANNEL  ; Updates Ch 1, advances C to 0x28
    CALL UPDATE_SQUARE_CHANNEL  ; Updates Ch 2, advances C to 0x2C
    CALL UPDATE_NOISE_CHANNEL   ; Updates Ch 3, advances C to 0x30

    ; --- PERCUSSIVE ENVELOPE FIX ---
    CALL DELAY_40MS             ; Let the drum "hit" ring out briefly
    
    XOR A
    OUT (0x33), A               ; Mute Noise Channel (Port 0x33) early!
    
    CALL DELAY_160MS            ; Wait for the rest of the 1/8th note
    ; -------------------------------

    POP BC         ; Restore step counter
    DEC B          ; Next step
    JR NZ, PLAY_STEP_LOOP

    ld a, 0x00      ; Disable Channel 0
    out (0x23), a

	ld a, 0x00      ; Disable Channel 1
    out (0x27), a

	ld a, 0x00      ; Disable Channel 2
    out (0x2B), a
	
	JP   $003B		; Back to OS

; ==========================================
; CHANNEL UPDATE ROUTINES
; ==========================================
; Reads 2 bytes from HL, updates the channel starting at port (C).
; Uses the ED 79 opcode OUT (C), A natively supported by your emulator.

UPDATE_SQUARE_CHANNEL:
    LD E, (HL)
    INC HL
    LD D, (HL)
    INC HL
    
    LD A, D
    OR E
    JR Z, DISABLE_SQUARE
    
    ; Note is active - Enable Path
    LD A, E
    OUT (C), A      ; Set Freq LSB
    INC C
    LD A, D
    OUT (C), A      ; Set Freq MSB
    INC C
    LD A, 0x8A      ; Duty = 50% (10), Volume = 10 (1010)
    OUT (C), A
    INC C
    LD A, 0x01
    OUT (C), A      ; Enable channel
    INC C
    RET

DISABLE_SQUARE:
    INC C           ; Skip Freq LSB
    INC C           ; Skip Freq MSB
    INC C           ; Skip Duty/Vol
    XOR A
    OUT (C), A      ; Write 0 to Ctrl (Disable channel)
    INC C           ; Advance C to next channel
    RET

UPDATE_NOISE_CHANNEL:
    LD E, (HL)
    INC HL
    LD D, (HL)
    INC HL
    
    LD A, D
    OR E
    JR Z, DISABLE_NOISE
    
    ; Note is active - Enable Path
    LD A, E
    OUT (C), A      ; Set Freq LSB
    INC C
    LD A, D
    OUT (C), A      ; Set Freq MSB
    INC C
    LD A, 0x06      ; Volume = 12
    OUT (C), A
    INC C
    LD A, 0x01
    OUT (C), A      ; Enable channel
    INC C
    RET

DISABLE_NOISE:
    INC C           ; Skip Freq LSB
    INC C           ; Skip Freq MSB
    INC C           ; Skip Vol
    XOR A
    OUT (C), A      ; Write 0 to Ctrl (Disable channel)
    INC C           ; Advance C to next channel
    RET

; ==========================================
; DELAY SUBROUTINES (3.5 MHz)
; Split to allow drum decay
; ==========================================
DELAY_40MS:
    PUSH BC
    LD BC, 5384         ; Inner loop for ~40ms
    JR DELAY_LOOP_CORE

DELAY_160MS:
    PUSH BC
    LD BC, 21538        ; Inner loop for ~160ms

DELAY_LOOP_CORE:
    DEC BC              ; 6 T-states
    LD A, B             ; 4 T-states
    OR C                ; 4 T-states
    JR NZ, DELAY_LOOP_CORE ; 12 T-states 
    POP BC
    RET


; ==========================================
; TRACKER DATA (64 Steps)
; Format: DW Melody, Bass, Harmony, Noise
; ==========================================
SONG_DATA:
    ; Measure 1 (E5 B4 C5 D5 C5 B4)
    DW M_E5, B_E3, OFF,   N_K
    DW M_E5, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_C5, OFF,  OFF,   N_S
    DW M_B4, OFF,  H_B3,  OFF

    ; Measure 2 (A4 A4 C5 E5 D5 C5)
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_C4,  OFF
    DW M_E5, B_A3, OFF,   N_K
    DW M_E5, OFF,  H_E4,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_E4,  OFF

    ; Measure 3 (B4 B4 C5 D5 E5)
    DW M_B4, B_E3, OFF,   N_K
    DW M_B4, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_E5, OFF,  H_B3,  OFF

    ; Measure 4 (C5 A4 A4)
    DW M_C5, B_A3, OFF,   N_K
    DW M_C5, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_E4,  OFF
    DW OFF,  OFF,  OFF,   N_S
    DW OFF,  OFF,  H_E4,  OFF

    ; Measure 5 (D5 F5 A5 G5 F5)
    DW M_D5, B_D3, OFF,   N_K
    DW M_D5, OFF,  H_F3,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_F5, OFF,  H_F3,  OFF
    DW M_A5, B_D3, OFF,   N_K
    DW M_A5, OFF,  H_A3,  OFF
    DW M_G5, OFF,  OFF,   N_S
    DW M_F5, OFF,  H_A3,  OFF

    ; Measure 6 (E5 C5 E5 D5 C5)
    DW M_E5, B_C3, OFF,   N_K
    DW M_E5, OFF,  H_E3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_E3,  OFF
    DW M_E5, B_C3, OFF,   N_K
    DW M_E5, OFF,  H_G3,  OFF
    DW M_D5, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_G3,  OFF

    ; Measure 7 (B4 B4 C5 D5 E5)
    DW M_B4, B_E3, OFF,   N_K
    DW M_B4, OFF,  H_GS3, OFF
    DW M_B4, OFF,  OFF,   N_S
    DW M_C5, OFF,  H_GS3, OFF
    DW M_D5, B_E3, OFF,   N_K
    DW M_D5, OFF,  H_B3,  OFF
    DW M_E5, OFF,  OFF,   N_S
    DW M_E5, OFF,  H_B3,  OFF

    ; Measure 8 (C5 A4 A4)
    DW M_C5, B_A3, OFF,   N_K
    DW M_C5, OFF,  H_C4,  OFF
    DW M_A4, OFF,  OFF,   N_S
    DW M_A4, OFF,  H_C4,  OFF
    DW M_A4, B_A3, OFF,   N_K
    DW M_A4, OFF,  H_E4,  OFF
    DW OFF,  OFF,  OFF,   N_S
    DW OFF,  OFF,  H_E4,  OFF