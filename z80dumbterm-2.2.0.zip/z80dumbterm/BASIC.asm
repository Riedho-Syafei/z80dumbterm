; ====================================================================
; BASIC INTERPRETER WITH STRING VARIABLE SUPPORT
; Features: Dynamic string allocation, reference counting, garbage collection
; Run as: BASIC SCRIPT.BAS
; ====================================================================

        ORG $0100

        ; OS Syscall Constants
SC_EXIT         EQU 0
SC_PUTCHAR      EQU 1
SC_GETCHAR      EQU 2
SC_PUTS         EQU 3
SC_FS_OPEN      EQU 33
SC_FS_READ      EQU 34
SC_FS_CLOSE     EQU 35
SC_FS_FILE_SIZE EQU 42

ARG1            EQU $0090       ; Filename argument from CCP
SCRIPT_BUF      EQU $2000       ; Where we will load the BASIC script

; ====================================================================
; STRING HEAP CONFIGURATION
; ====================================================================
STRING_HEAP     EQU $3000       ; Start of string heap
STRING_HEAP_END EQU $3FFF       ; End of string heap
STRING_DESC_ADDR EQU $4000      ; String descriptor table address (26 entries for A$-Z$)

; String header in heap (when allocated):
; +0: Previous string pointer (2 bytes, 0 = first block)
; +2: Block size including header (2 bytes)
; +4: Reference count (1 byte)
; +5: Length (1 byte)
; +6: String data starts here

STRING_HDR_PREV     EQU 0
STRING_HDR_SIZE     EQU 2
STRING_HDR_REFCNT   EQU 4
STRING_HDR_LEN      EQU 5
STRING_DATA_OFFSET  EQU 6

START:
        ; 1. Check if a filename was provided in ARG1
        LD   A, (ARG1)
        OR   A
        JR   NZ, .open_file

        ; No filename provided, print usage and exit
        LD   DE, MSG_USAGE
        LD   C, SC_PUTS
        CALL $0005
        JP   EXIT

.open_file:
        ; 2. Open the script file
        LD   DE, ARG1
        LD   C, SC_FS_OPEN
        CALL $0005
        OR   A
        JR   Z, .get_size

        ; Open failed
        LD   DE, MSG_ERR_OPEN
        LD   C, SC_PUTS
        CALL $0005
        JP   EXIT

.get_size:
        ; 3. Get exact file size to know how much to read
        LD   DE, FILE_SIZE_BUF
        LD   C, SC_FS_FILE_SIZE
        CALL $0005

        ; 4. Read the file into memory at SCRIPT_BUF
        LD   HL, (FILE_SIZE_BUF)
        LD   A, H
        OR   L
        JR   Z, .close_exit      ; Empty file, just exit

        LD   DE, SCRIPT_BUF
        LD   C, SC_FS_READ
        CALL $0005

        ; Null-terminate the loaded script just to be safe
        LD   HL, (FILE_SIZE_BUF)
        LD   DE, SCRIPT_BUF
        ADD  HL, DE
        LD   (HL), 0

.close_exit:
        ; 5. Close the file
        LD   C, SC_FS_CLOSE
        CALL $0005

        ; 6. Initialize string system
        CALL INIT_STRINGS

        ; 7. Execute the script!
        LD   HL, SCRIPT_BUF
        CALL EXEC_LOOP

EXIT:
        LD   C, SC_EXIT
        CALL $0005

; ====================================================================
; STRING SYSTEM INITIALIZATION
; ====================================================================
INIT_STRINGS:
        ; Initialize string heap
        LD   HL, STRING_HEAP
        LD   (HEAP_PTR), HL

        ; Initialize all string descriptors to empty
        LD   B, 26                ; 26 string variables (A$-Z$)
        LD   IX, STRING_DESC_ADDR
.init_desc_loop:
        XOR  A
        LD   (IX+0), A           ; Pointer = NULL
        LD   (IX+1), A
        LD   (IX+2), A           ; Length = 0
        LD   (IX+3), A           ; Refcount = 0
        LD   (IX+4), A           ; Flags = 0
        LD   (IX+5), A           ; Padding
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        INC  IX
        DJNZ .init_desc_loop

        RET

; ====================================================================
; INTERPRETER EXECUTION LOOP
; ====================================================================
EXEC_LOOP:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A                  ; Check for EOF
        RET  Z

        ; Skip blank lines (CR or LF)
        CP   13
        JP   Z, skip_blank
        CP   10
        JP   Z, skip_blank

        CALL PARSE_NUM          ; Parse the line number (ignored during normal execution)

EXEC_LOOP_CMD:
        CALL SKIP_WS

        ; Try matching "IF"
        LD   DE, CMD_IF
        CALL MATCH_STR
        JP   Z, DO_IF

        ; Try matching "PRINT"
        LD   DE, CMD_PRINT
        CALL MATCH_STR
        JP   Z, DO_PRINT

        ; Try matching "LET"
        LD   DE, CMD_LET
        CALL MATCH_STR
        JP   Z, DO_LET

        ; Try matching "GOTO"
        LD   DE, CMD_GOTO
        CALL MATCH_STR
        JP   Z, DO_GOTO

        ; Try matching "REM"
        LD   DE, CMD_REM
        CALL MATCH_STR
        JP   Z, DO_REM

        ; Try matching "INPUT"
        LD   DE, CMD_INPUT
        CALL MATCH_STR
        JP   Z, DO_INPUT

        ; Unknown command
        LD   DE, MSG_ERR_SYNTAX
        LD   C, SC_PUTS
        CALL $0005
        RET

skip_blank:
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: PRINT "..." or PRINT <VAR> or PRINT <STRING$>
; ====================================================================
DO_PRINT:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A
        JP   Z, .print_done_check

		CP   13
        JP   Z, .print_done_check
        CP   10
        JP   Z, .print_done_check

        CP   '"'
        JR   NZ, .check_string_var    ; If no quote, check for variable

        ; --- Print String Literal ---
        INC  HL
.print_literal_loop:
        LD   A, (HL)
        OR   A
        JP   Z, .print_done_check
        CP   '"'
        JP   Z, .print_done_check
        CP   13
        JP   Z, .print_done_check
        CP   10
        JP   Z, .print_done_check
        LD   E, A
        LD   C, SC_PUTCHAR
        PUSH HL
        CALL $0005
        POP  HL
        INC  HL
        JP   .print_literal_loop

.check_string_var:
        ; Check if it's a string variable (ends with $)
        CALL IDENTIFY_VAR
        JP   NC, .print_numeric_var

        ; It's a string variable - print it
        PUSH HL
        CALL GET_STRING_VAR
        POP  HL
        OR   A
        JP   Z, .print_done           ; Empty string

        ; DE points to string data, C = length
        PUSH BC
        PUSH DE
.print_string_loop:
        LD   A, (DE)
        PUSH DE            ; Save string pointer
        PUSH BC            ; Save length counter
        PUSH HL
		LD   E, A          ; E = character to print
        LD   C, SC_PUTCHAR
        CALL $0005
		POP  HL
        POP  BC            ; Restore length counter
        POP  DE            ; Restore string pointer
        INC  DE
        DEC  C
        JR   NZ, .print_string_loop
        
        POP  DE            ; <--- FIX: Clean up pushed DE
        POP  BC            ; <--- FIX: Clean up pushed BC
        JP   .print_done

.print_numeric_var:
        ; --- Print Numeric Variable ---
        PUSH HL
        LD   A, (HL)                 ; <--- FIX: Re-read the variable character
		SUB  'A'                     ; Get 0-25 index
        ADD  A, A
        LD   C, A
        LD   B, 0
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   E, (IX+0)
        LD   D, (IX+1)
        CALL PRINT_NUM16
        POP  HL

.print_done:
        CALL PRINT_NL
        CALL SKIP_LINE
        JP   EXEC_LOOP

.print_done_check:
        CALL PRINT_NL
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: LET <VAR> = <EXPR> or LET <STRING$> = <STRING_EXPR>
; ====================================================================
DO_LET:
        CALL SKIP_WS
        CALL IDENTIFY_VAR
        JP   NC, .let_numeric

        ; --- String Assignment ---
        LD   A, B
        PUSH AF                     ; Save variable index
        CALL SKIP_WS
        INC  HL                     ; Skip '='
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR       ; Returns DE = pointer, C = length
        
        POP  AF
        LD   B, A                   ; Restore index into B. C & DE are intact!
        CALL ASSIGN_STRING_VAR

        CALL SKIP_LINE
        JP   EXEC_LOOP

.let_numeric:
        ; --- Numeric Assignment (Original Logic) ---
        LD   A, (HL)
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH BC

        INC  HL
        CALL SKIP_WS
        INC  HL                     ; Skip '='
        CALL SKIP_WS

        CALL EVAL_EXPR

        POP  BC
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: INPUT <VAR> or INPUT <STRING$>
; ====================================================================
DO_INPUT:
        CALL SKIP_WS
        LD   A, (HL)
        CP   '"'
        JR   NZ, .no_prompt

        INC  HL
.prompt_loop:
        LD   A, (HL)
        CP   '"'
        JR   Z, .prompt_done
        LD   E, A
        PUSH HL
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  HL
        INC  HL
        JR   .prompt_loop
.prompt_done:
        INC  HL                     ; Skip quote
        CALL SKIP_WS
        INC  HL                     ; Skip comma
        CALL SKIP_WS

.no_prompt:
        CALL IDENTIFY_VAR
        JP   NC, .input_numeric

        ; --- String Input ---
        PUSH BC                     ; Save variable index

        CALL SKIP_WS

        ; Read line from console into input buffer
        LD   DE, INPUT_BUFFER
		PUSH HL
        CALL READ_LINE
		POP  HL

        ; Assign input to string variable
        POP  BC                     ; BC = variable index
		PUSH HL
        LD   HL, INPUT_BUFFER
        CALL ASSIGN_STRING_LITERAL
		POP  HL

        CALL SKIP_LINE
        JP   EXEC_LOOP

.input_numeric:
        ; --- Numeric Input ---
        LD   A, (HL)
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH BC

        ; Read line from console into input buffer
        PUSH HL
		LD   DE, INPUT_BUFFER
        CALL READ_LINE

        ; Parse number from input buffer
        LD   HL, INPUT_BUFFER
        CALL PARSE_NUM
		POP  HL

        POP  BC
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: LEN(<STRING$>) - Returns string length
; ====================================================================
DO_LEN:
        CALL SKIP_WS
        CP   '('
        JP   NZ, ERR_SYNTAX
        INC  HL
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR
        ; C = length of string
        LD   D, 0
        LD   E, C
        ; Store result in variable A (index 0)
        LD   IX, VARIABLES
        LD   (IX+0), E
        LD   (IX+1), D

        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: GOTO <LINE>
; ====================================================================
DO_GOTO:
        CALL SKIP_WS
        CALL PARSE_NUM
        PUSH DE

        LD   HL, SCRIPT_BUF
.search_loop:
        CALL SKIP_WS
        LD   A, (HL)
        OR   A
        JP   Z, .not_found

        CALL PARSE_NUM
        POP  BC
        PUSH BC

        LD   A, D
        CP   B
        JR   NZ, .next_line
        LD   A, E
        CP   C
        JR   Z, .found_line

.next_line:
        CALL SKIP_LINE
        JP   .search_loop

.found_line:
        POP  BC
        JP   EXEC_LOOP_CMD

.not_found:
        POP  BC
        LD   DE, MSG_ERR_GOTO
        LD   C, SC_PUTS
        CALL $0005
        RET

; ====================================================================
; COMMAND: IF <EXPR> <OP> <EXPR> THEN <COMMAND>
; ====================================================================
DO_IF:
        CALL SKIP_WS
        
        ; 1. Peek to see if we are dealing with strings or numbers
        CALL IS_STRING_EXPR
        JP   C, .do_string_if

        ; --- Original Numeric Comparison Logic ---
        CALL EVAL_EXPR
        PUSH DE

        CALL SKIP_WS
        LD   A, (HL)
        LD   C, A
        INC  HL

        CALL SKIP_WS

        PUSH BC
        CALL EVAL_EXPR
        POP  BC

        EX   (SP), HL

        LD   A, C
        CP   '='
        JR   Z, .do_eq
        CP   '<'
        JR   Z, .do_lt
        CP   '>'
        JR   Z, .do_gt

        POP  HL
        JP   ERR_SYNTAX

.do_eq:
        OR   A
        SBC  HL, DE
        LD   A, H
        OR   L
        JR   Z, .is_true
        JP   .is_false

.do_lt:
        OR   A
        SBC  HL, DE
        JP   PE, .lt_ovf
        JP   M, .is_true
        JR   .is_false
.lt_ovf:
        JP   P, .is_true
        JR   .is_false

.do_gt:
        OR   A
        SBC  HL, DE
        JR   Z, .is_false
        JP   PE, .gt_ovf
        JP   P, .is_true
        JR   .is_false
.gt_ovf:
        JP   M, .is_true
        JR   .is_false

; --- New String Comparison Logic (With <> Support) ---
.do_string_if:
        CALL EVAL_STRING_EXPR  ; Evaluate left side. DE = str1, C = len1
        PUSH DE                ; Save str1 pointer
        PUSH BC                ; Save len1 (in C register)

        CALL SKIP_WS
        LD   A, (HL)           ; Get first character of operator
        INC  HL
        
        ; 1. Multi-character operator parsing
        CP   '<'               ; Is it '<'?
        JR   NZ, .op_parsed    ; If not, skip ahead
        
        LD   B, A              ; Temporarily stash the '<'
        LD   A, (HL)           ; Peek at the next character
        CP   '>'               ; Is it '>'?
        JR   NZ, .not_neq      ; If not, it's just a normal '<'
        
        INC  HL                ; Consume the '>'
        LD   A, '#'            ; Use '#' as our internal token for '<>'
        JR   .op_parsed
        
.not_neq:
        LD   A, B              ; It wasn't '<>', restore the '<'

.op_parsed:
        LD   B, A              ; Save our final operator in B
        CALL SKIP_WS

        PUSH BC                ; Save operator to stack
        CALL EVAL_STRING_EXPR  ; Evaluate right side. DE = str2, C = len2
        POP  AF                ; Pop operator into A (clever Z80 trick: old B goes to A)

        POP  BC                ; Restore len1 (goes into C)
        LD   B, C              ; Move len1 into B. Now B = len1, C = len2
        EX   (SP), HL          ; HL = str1 ptr, and script ptr is tucked safely on stack

        PUSH AF                ; Save the operator safely on the stack for a moment

        ; 2. The Comparison Engine
        LD   A, B
        CP   C                 ; Fast fail: do the lengths match?
        JR   NZ, .str_diff     
        
        OR   A                 ; If length is 0, both are empty strings
        JR   Z, .str_same

.str_cmp_loop:
        LD   A, (DE)
        CP   (HL)
        JR   NZ, .str_diff     ; Found a mismatched character
        INC  DE
        INC  HL
        DEC  C
        JR   NZ, .str_cmp_loop

        ; --- They are identical ---
.str_same:
        POP  AF                ; Retrieve our operator
        CP   '='
        JP   Z, .is_true
        CP   '#'               ; If operator was '<>', then matching means FALSE
        JP   Z, .is_false
        JR   .str_err

        ; --- They are different ---
.str_diff:
        POP  AF                ; Retrieve our operator
        CP   '='
        JP   Z, .is_false
        CP   '#'               ; If operator was '<>', then differing means TRUE
        JP   Z, .is_true
        JR   .str_err

.str_err:
        POP  HL                ; Clean up the script pointer from the stack
        JP   ERR_SYNTAX

.is_true:
        POP  HL                ; Restore script ptr
        CALL SKIP_WS
        LD   DE, CMD_THEN
        CALL MATCH_STR
        JP   NZ, ERR_SYNTAX
        JP   EXEC_LOOP_CMD

.is_false:
        POP  HL                ; Restore script ptr
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; COMMAND: REM
; ====================================================================
DO_REM:
        CALL SKIP_LINE
        JP   EXEC_LOOP

; ====================================================================
; GLOBAL ERROR HANDLER
; ====================================================================
ERR_SYNTAX:
        LD   DE, MSG_ERR_SYNTAX
        LD   C, SC_PUTS
        CALL $0005
        RET

; ====================================================================
; STRING EXPRESSION EVALUATOR
; ====================================================================

; EVAL_STRING_EXPR: Evaluates string expressions
; Returns: DE = string pointer, C = length
EVAL_STRING_EXPR:
        CALL SKIP_WS

        LD   DE, CMD_LEFT
        CALL MATCH_STR
        JP   Z, EVAL_LEFT

		LD   DE, CMD_RIGHT
        CALL MATCH_STR
        JP   Z, EVAL_RIGHT

        LD   DE, CMD_MID
        CALL MATCH_STR
        JP   Z, EVAL_MID

		LD   DE, CMD_CHR
        CALL MATCH_STR
        JP   Z, EVAL_CHR

        LD   DE, CMD_STR
        CALL MATCH_STR
        JP   Z, EVAL_STR
		
		; Check for string literal
        LD   A, (HL)
        CP   '"'
        JR   NZ, .check_concat

        ; String literal
        INC  HL
        LD   DE, INPUT_BUFFER
        LD   C, 0
.string_lit_loop:
        LD   A, (HL)
        OR   A
        JR   Z, .lit_done
        CP   '"'
        JR   Z, .lit_done
        CP   13
        JR   Z, .lit_done
        CP   10
        JR   Z, .lit_done
        LD   (DE), A
        INC  DE
        INC  HL
        INC  C
        JR   .string_lit_loop
.lit_done:
        ; Check if we stopped because of a quote, if so skip it
        LD   A, (HL)
        CP   '"'
        JR   NZ, .no_quote_skip
        INC  HL                  ; Advance HL past the closing quote!
.no_quote_skip:
        XOR  A
        LD   (DE), A             ; Null terminate

        LD   DE, INPUT_BUFFER    ; DE = string data pointer
        LD   A, C
        LD   (TEMP_LEN), A
        OR   A                   ; Set Z if empty
        RET

.check_concat:
        ; Check for string variable
        CALL IDENTIFY_VAR
        JR   NC, .syntax_err

        ; Get string variable value
		PUSH HL
        CALL GET_STRING_VAR
		POP  HL

        OR   A                      ; Set flags based on length
        RET

.syntax_err:
        JP   ERR_SYNTAX

; ====================================================================
; EVAL_LEFT: Evaluates LEFT$(<string>, <n>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_LEFT:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; DE = string, C = length
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A
        
        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; E = requested length
        
        LD   A, (TEMP_LEN)
        CP   E
        JR   NC, .left_use_n
        LD   E, A                   ; Clamp length
.left_use_n:
        LD   C, E                   ; C = new length
        LD   DE, (TEMP_STRING_PTR)  ; DE = original string pointer
        
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_RIGHT: Evaluates RIGHT$(<string>, <n>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_RIGHT:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; Get string: DE = pointer, C = length
        
        ; Store original string data safely
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A
        
        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get n: E = requested length
        
        LD   A, (TEMP_LEN)          ; A = original length
        CP   E                      ; Compare original length with n
        JR   C, .right_use_all      ; If original < n, just return whole string
        JR   Z, .right_use_all      ; If original == n, return whole string

        ; n is smaller: calculate pointer offset (offset = original - n)
        SUB  E                      ; A = original length - n
        LD   C, E                   ; C = new string length (n)

        ; Advance string pointer by the offset
        LD   E, A
        LD   D, 0
        LD   IX, (TEMP_STRING_PTR)
        ADD  IX, DE                 ; Add offset to original pointer
        PUSH IX
        POP  DE                     ; DE = new advanced pointer
        JR   .right_done

.right_use_all:
        ; Request is larger than string, return original bounds
        LD   C, A                   ; C = original length
        LD   DE, (TEMP_STRING_PTR)

.right_done:
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_MID: Evaluates MID$(<string>, <start>, <length>)
; Returns: DE = new string pointer, C = new length
; ====================================================================
EVAL_MID:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; Get string: DE = pointer, C = length
        
        LD   (TEMP_STRING_PTR), DE
        LD   A, C
        LD   (TEMP_LEN), A

        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get start position
        PUSH DE                     ; Save start position (in E) to stack

        CALL SKIP_WS
        INC  HL                     ; Skip ','
        CALL EVAL_EXPR              ; Get requested length
        LD   B, E                   ; B = requested length (save in B)

        POP  DE                     ; Restore start position into E

        ; Calculate offset (start - 1, since BASIC is 1-indexed)
        LD   A, E
        OR   A                      ; Safety check: if start is 0
        JR   Z, .mid_start_zero
        DEC  A                      ; A = offset (0-indexed)
.mid_start_zero:
        
        LD   E, A                   ; Save offset temporarily in E
        LD   A, (TEMP_LEN)          ; A = original string length
        CP   E                      ; Check if offset goes past string bounds
        JR   C, .mid_empty          ; If length < offset, return empty
        JR   Z, .mid_empty          ; If length == offset, return empty

        ; Calculate maximum available characters from this start point
        SUB  E                      ; A = max length (original - offset)
        CP   B                      ; Compare max length with requested length
        JR   C, .mid_clamp          ; If max available < requested, clamp it
        LD   A, B                   ; Otherwise, use requested length safely
.mid_clamp:
        LD   C, A                   ; C = final clamped length

        ; Advance string pointer by the offset
        LD   D, 0                   ; E already holds the offset
        LD   IX, (TEMP_STRING_PTR)
        ADD  IX, DE
        PUSH IX
        POP  DE                     ; DE = advanced pointer
        JR   .mid_done

.mid_empty:
        LD   C, 0                   ; Return 0 length
        LD   DE, (TEMP_STRING_PTR)  ; Pointer doesn't matter much, but keep it clean

.mid_done:
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_CHR: Evaluates CHR$(<n>)
; Returns: DE = string pointer, C = length (always 1)
; ====================================================================
EVAL_CHR:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_EXPR              ; Evaluate numeric expression, DE = ASCII code

        ; Store the single character in INPUT_BUFFER
        LD   A, E
        LD   (INPUT_BUFFER), A
        XOR  A
        LD   (INPUT_BUFFER+1), A    ; Null terminate

        CALL SKIP_WS
        INC  HL                     ; Skip ')'

        ; Set up return registers
        LD   DE, INPUT_BUFFER
        LD   C, 1                   ; Length is 1
        LD   A, C
        LD   (TEMP_LEN), A          ; Keep TEMP_LEN updated for safety
        RET

; ====================================================================
; EVAL_STR: Evaluates STR$(<n>)
; Returns: DE = string pointer, C = length
; ====================================================================
EVAL_STR:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_EXPR              ; Evaluate numeric expression, DE = number

        ; Convert DE to string (NUM_TO_STR safely preserves HL)
        CALL NUM_TO_STR             ; Outputs null-terminated string to INPUT_BUFFER

        CALL SKIP_WS
        INC  HL                     ; Skip ')'

        ; Calculate the length of the newly created string
        LD   DE, INPUT_BUFFER
        LD   C, 0
.str_len_loop:
        LD   A, (DE)
        OR   A
        JR   Z, .str_len_done
        INC  DE
        INC  C
        JR   .str_len_loop
.str_len_done:
        LD   DE, INPUT_BUFFER       ; Reset DE to start of string
        LD   A, C
        LD   (TEMP_LEN), A          ; Save length
        RET

; ====================================================================
; STRING ALLOCATION AND MANAGEMENT
; ====================================================================

; GET_STRING_VAR: Gets string variable data
; Input: B = variable index (0-25)
; Output: DE = string pointer, C = length, A = 0 if empty
GET_STRING_VAR:
        PUSH HL              ; <--- FIX: Save script pointer!
        
        ; Cleanly calculate IX = STRING_DESC_ADDR + (B * 6)
        LD   L, B
        LD   H, 0
        LD   E, L
        LD   D, H            ; DE = B
        ADD  HL, HL          ; HL = 2 * B
        ADD  HL, DE          ; HL = 3 * B
        ADD  HL, HL          ; HL = 6 * B
        LD   DE, STRING_DESC_ADDR
        ADD  HL, DE          ; HL = STRING_DESC_ADDR + 6 * B
        PUSH HL
        POP  IX
        
        POP  HL              ; <--- FIX: Restore script pointer!

        ; Get pointer from descriptor
        LD   C, (IX+0)
        LD   B, (IX+1)
        LD   E, C
        LD   D, B

        LD   C, (IX+2)              ; Length
        LD   A, C
        OR   A
        RET  Z                      ; Empty string

        ; String data pointer is in DE (points to heap header)
        ; Skip header to get to actual string data
        PUSH DE
        POP  IX
        LD   DE, STRING_DATA_OFFSET
        ADD  IX, DE
        PUSH IX
        POP  DE

        RET

; ASSIGN_STRING_VAR: Assigns a string (with ref counting) to a variable
; Input: BC = variable index (0-25), DE = string pointer, C = length
ASSIGN_STRING_VAR:
        PUSH BC

        PUSH HL              
        PUSH DE              
        
        ; Cleanly calculate IX = STRING_DESC_ADDR + (B * 6)
        LD   L, B
        LD   H, 0
        LD   E, L
        LD   D, H            
        ADD  HL, HL          
        ADD  HL, DE          
        ADD  HL, HL          
        LD   DE, STRING_DESC_ADDR
        ADD  HL, DE          
        PUSH HL
        POP  IX
        
        POP  DE              
        POP  HL              

        ; Decrement old string's ref count
        LD   C, (IX+0)
        LD   B, (IX+1)
        LD   A, B
        OR   C
        JR   Z, .no_old_string

        PUSH DE              ; <--- FIX: Save the incoming string pointer
        PUSH BC
        POP  DE
        CALL DEC_REF_COUNT
        POP  DE              ; <--- FIX: Restore the incoming string pointer

.no_old_string:
        ; Allocate new string
        POP  BC
		PUSH BC
        CALL ALLOC_STRING

		POP  BC

        ; Update descriptor
        LD   (IX+0), E
        LD   (IX+1), D
        LD   (IX+2), C       ; <--- FIX: Store C directly
        LD   (IX+3), 1       ; Ref count = 1

        RET

; ASSIGN_STRING_LITERAL: Assigns a null-terminated string literal
; Input: BC = variable index, HL = pointer to null-terminated string
ASSIGN_STRING_LITERAL:
        PUSH HL
        LD   C, 0
        PUSH HL
.len_count_loop:
        LD   A, (HL)
        OR   A
        JR   Z, .len_done
        INC  C
        INC  HL
        JR   .len_count_loop
.len_done:
        POP  DE              ; DE = source string
        POP  HL              ; HL = script pointer
        JP   ASSIGN_STRING_VAR

; ASSIGN_STRING_LITERAL_N: Assigns a string with known length
; Input: BC = variable index, HL = pointer to string, C = length
ASSIGN_STRING_LITERAL_N:
        PUSH BC
        PUSH HL

        ; Copy string to input buffer
        LD   B, C
        LD   DE, INPUT_BUFFER
.copy_loop:
        LD   A, (HL)
        LD   (DE), A
        INC  HL
        INC  DE
        DEC  B
        JR   NZ, .copy_loop

        XOR  A
        LD   (DE), A                ; Null terminate

        POP  HL
        POP  BC
        LD   DE, INPUT_BUFFER       ; <--- FIX: Tell ASSIGN_STRING_VAR where the string is
        JP   ASSIGN_STRING_VAR

; ALLOC_STRING: Allocates a string on the heap
; Input: DE = source string pointer, C = length
; Output: DE = heap pointer to string header, A = 0 if success
ALLOC_STRING:
        PUSH HL
        LD   A, C
        OR   A
        JR   Z, .empty_string

        ; Calculate total size needed: header + string + null terminator
        LD   A, C
        ADD  A, STRING_DATA_OFFSET + 1
        LD   (TEMP_LEN), A

        ; Check if we have enough heap space
        LD   HL, (HEAP_PTR)
        PUSH DE                  ; <--- FIX: Save source string pointer!
        LD   E, A
        LD   D, 0
        ADD  HL, DE
        POP  DE                  ; <--- FIX: Restore source string pointer!
        LD   A, H
        CP   $40                 ; Check against STRING_HEAP_END page
        JR   NC, .gc_needed

        ; We have space - allocate
        LD   HL, (HEAP_PTR)

        ; Save current heap pointer as our block
        PUSH HL

        ; Advance HL to point to the string data area
        PUSH DE                  ; <--- FIX: Save source string pointer again!
        LD   DE, STRING_DATA_OFFSET
        ADD  HL, DE
        POP  DE                  ; <--- FIX: Restore source string pointer!

        ; Now: DE = source string, HL = destination heap data
        LD   B, C
.copy_string:
        LD   A, (DE)
        LD   (HL), A
        INC  HL
        INC  DE
        DEC  B
        JR   NZ, .copy_string

        ; Null terminate
        XOR  A
        LD   (HL), A

        ; Update heap pointer
        POP  DE                     ; DE = block header pointer
        LD   HL, (HEAP_PTR)
        LD   A, (TEMP_LEN)
        ADD  A, L
        LD   L, A
        LD   A, 0
        ADC  A, H
        LD   H, A
        LD   (HEAP_PTR), HL

        XOR  A                      ; Success
        POP  HL
        RET

.empty_string:
        LD   DE, 0
        XOR  A
        POP  HL
        RET

.gc_needed:
        ; Run garbage collection
        CALL RUN_GC

        ; Retry allocation
        POP  HL
        JP   ALLOC_STRING

; DEC_REF_COUNT: Decrements reference count and frees if zero
; Input: DE = heap pointer to string header
DEC_REF_COUNT:
        LD   A, D
        OR   E
        RET  Z                      ; NULL pointer

		PUSH HL

        ; Get ref count location
        PUSH DE
        POP  HL
        LD   BC, STRING_HDR_REFCNT
        ADD  HL, BC

        ; Decrement ref count
        DEC  (HL)
		POP  HL
        RET  NZ                     ; Still referenced

        ; Ref count is zero - block will be reclaimed by GC
        RET

; RUN_GC: Mark-and-sweep garbage collection
RUN_GC:
        PUSH HL
        PUSH DE
        PUSH BC
        PUSH AF

        ; Mark phase: Reset all ref counts for heap strings
        LD   HL, STRING_HEAP
        LD   DE, STRING_HEAP_END
.mark_loop:
        ; Check if we've reached the end
        PUSH HL
        POP  BC
        LD   A, B
        CP   D
        JR   NZ, .check_block
        LD   A, L
        CP   E
        JR   Z, .mark_done

.check_block:
        ; Check if block is allocated
        LD   A, (HL)
        OR   A
        JR   Z, .next_block

        ; Mark: set ref count to 1
        LD   BC, STRING_HDR_REFCNT
        ADD  HL, BC
        LD   (HL), 1
        LD   A, 1
        SUB  0                      ; Clear nothing, just set A=1
        DEC  HL                     ; Back to block start

.next_block:
        ; Get block size and advance
        LD   BC, STRING_HDR_SIZE
        ADD  HL, BC
        LD   C, (HL)
        INC  HL
        LD   B, (HL)
        DEC  HL                     ; Back to block start
        ADD  HL, BC
        JP   .mark_loop

.mark_done:
        ; Sweep phase: compact by copying reachable blocks
        LD   HL, STRING_HEAP
        LD   (HEAP_PTR), HL        ; Reset heap pointer

.sweep_loop:
        ; Check if we've reached current heap end
        LD   DE, (HEAP_PTR)
        PUSH HL
        POP  BC
        LD   A, B
        CP   D
        JR   NZ, .check_sweep_block
        LD   A, L
        CP   E
        JR   Z, .sweep_done

.check_sweep_block:
        LD   A, (HL)
        OR   A
        JR   Z, .sweep_next

        LD   BC, STRING_HDR_REFCNT
        ADD  HL, BC
        LD   A, (HL)
        DEC  HL                     ; Back to block start

        OR   A
        JR   Z, .sweep_next        ; Refcount 0, skip

        ; This block is reachable - compact it
        ; Copy block to new heap position
        PUSH HL
        LD   BC, STRING_HDR_SIZE
        ADD  HL, BC
        LD   C, (HL)
        INC  HL
        LD   B, (HL)
        DEC  HL                     ; BC = block size
        POP  HL

        ; Copy block
        PUSH BC
        PUSH HL
        LD   DE, (HEAP_PTR)
        ; Copy from HL to DE, BC bytes
.copy_block:
        LD   A, (HL)
        LD   (DE), A
        INC  HL
        INC  DE
        DEC  BC
        LD   A, B
        OR   C
        JR   NZ, .copy_block
        POP  HL
        POP  BC

        ; Update heap pointer
        LD   (HEAP_PTR), DE
        JP   .sweep_loop

.sweep_next:
        ; Skip to next block
        LD   BC, STRING_HDR_SIZE
        ADD  HL, BC
        LD   C, (HL)
        INC  HL
        LD   B, (HL)
        DEC  HL
        ADD  HL, BC
        JP   .sweep_loop

.sweep_done:
        POP  AF
        POP  BC
        POP  DE
        POP  HL
        RET

; ====================================================================
; HELPER ROUTINES
; ====================================================================

; IS_STRING_EXPR: Checks if expression at HL evaluates to a string
; Output: Carry = 1 if string expression, Carry = 0 if numeric
IS_STRING_EXPR:
        LD   A, (HL)
        CP   '"'
        SCF
        RET  Z                 ; It's a string literal

        PUSH HL
        CALL IDENTIFY_VAR
        POP  HL
        RET  C                 ; Carry set = it's a string variable (e.g., A$)

        ; Check for string functions (LEFT$, RIGHT$, MID$, CHR$, STR$)
        PUSH HL
        LD   DE, CMD_LEFT
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_RIGHT
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_MID
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_CHR
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        PUSH HL
        LD   DE, CMD_STR
        CALL MATCH_STR
        POP  HL
        SCF
        RET  Z

        OR   A                 ; Clear carry flag (it's numeric)
        RET

; IDENTIFY_VAR: Checks if current position has a variable
; Output: Carry = 1 if string var (ends with $), B = index (0-25)
;         Carry = 0 if numeric var, A = variable letter
;         NZ if not a variable
IDENTIFY_VAR:
        LD   A, (HL)
        CP   'A'
        JR   C, .not_var
        CP   'Z'+1
        JR   NC, .not_var

        LD   C, A            ; Temporarily save the character
        INC  HL
        LD   A, (HL)
        CP   '$'
        JR   NZ, .numeric_var

        ; --- FIX: It's a string variable ---
        INC  HL
		LD   A, C            
        SUB  'A'             
        LD   B, A            ; Store index in B
        SCF
        RET
        
.numeric_var:
        DEC  HL
        LD   A, C
        SCF
        CCF
        RET
        
.not_var:
        OR   1
		SCF
		CCF
        RET

; READ_LINE: Reads a line from console into buffer
; Input: DE = buffer pointer
; Output: Null-terminated string in buffer
READ_LINE:
        PUSH DE
.read_char:
        ; Read character
        PUSH DE             ; <--- FIX: Save buffer pointer before syscall clobbers E
        LD   E, 0
        LD   C, SC_GETCHAR
        CALL $0005
        POP  DE             ; <--- FIX: Restore buffer pointer

        ; Check for Enter
        CP   13
        JR   Z, .enter_pressed
        CP   10
        JR   Z, .enter_pressed

        ; Store character
        LD   (DE), A
        INC  DE

        ; Echo character
        PUSH DE             ; <--- FIX: Save buffer pointer before syscall clobbers E
        LD   E, A
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  DE             ; <--- FIX: Restore buffer pointer

        JR   .read_char

.enter_pressed:
        ; Null terminate
        XOR  A
        LD   (DE), A

        ; Print newline
        CALL PRINT_NL

        POP  DE             ; Restore original start pointer
        RET

; NUM_TO_STR: Converts number in DE to string in buffer
; Input: DE = 16-bit number
; Output: Null-terminated string at INPUT_BUFFER
NUM_TO_STR:
        PUSH DE
        PUSH HL
        LD   HL, INPUT_BUFFER
        ; Check if negative
        BIT  7, D
        JR   Z, .positive

        ; Negative - print '-'
        LD   (HL), '-'
        INC  HL

        ; Negate DE
        LD   A, D
        CPL
        LD   D, A
        LD   A, E
        CPL
        LD   E, A
        INC  DE

.positive:
        ; Convert to string
        EX   DE, HL           ; HL = number, DE = buffer ptr
        PUSH DE               ; Save start of digit buffer
        CALL .HL_TO_DEC       ; Writes 5 digits to DE, advancing DE
        
        ; Null terminate
        XOR  A
        LD   (DE), A          
        
        ; Strip leading zeros
        POP  DE               ; DE = start of digits
        PUSH DE
        POP  HL               ; HL = start of digits (to read from)

.skip_zeros:
        LD   A, (HL)
        CP   '0'
        JR   NZ, .shift_chars ; If not '0', we found our first real digit
        INC  HL
        LD   A, (HL)
        OR   A                ; Are we at the null terminator?
        JR   Z, .last_zero
        JR   .skip_zeros

.last_zero:
        DEC  HL               ; If it was all zeros, leave at least one '0'

.shift_chars:
        ; Shift the characters left to overwrite the leading zeros
        LD   A, (HL)
        LD   (DE), A
        INC  HL
        INC  DE
        OR   A                ; Did we just copy the null terminator?
        JR   NZ, .shift_chars ; If not, keep copying
        
        POP  HL
        POP  DE
        RET

; HL_TO_DEC: Convert 16-bit number to decimal string
; Input: HL = number, DE = buffer pointer
; Output: DE = updated buffer pointer
.HL_TO_DEC:
        PUSH BC
        PUSH HL

        LD   BC, -10000       ; <-- FIX: Use BC for divisor, preserving DE
        CALL .divmod_digit
        LD   BC, -1000
        CALL .divmod_digit
        LD   BC, -100
        CALL .divmod_digit
        LD   BC, -10
        CALL .divmod_digit
        LD   BC, -1
        CALL .divmod_digit

        POP  HL
        POP  BC
        RET

.divmod_digit:
        LD   A, '0' - 1
.divmod_loop:
        INC  A
        ADD  HL, BC           ; <-- FIX: Divisor is now in BC
        JR   C, .divmod_loop
        SBC  HL, BC
        LD   (DE), A          ; <-- FIX: Safe write to buffer pointer
        INC  DE               ; <-- FIX: Advance buffer pointer
        RET

; PARSE_NUM_FROM_STRING: Parses number from string
; Input: DE = string pointer, C = length
; Output: DE = parsed number
PARSE_NUM_FROM_STRING:
        ; Save string end
        PUSH DE
        LD   A, C
        LD   L, A
        LD   H, 0
        ADD  HL, DE
        ; Save end position
        LD   (TEMP_STRING_PTR), HL
        POP  DE

        ; Null terminate temporarily
        LD   A, (HL)
        LD   (TEMP_LEN), A
        PUSH AF
        LD   (HL), 0

        ; Parse
        EX   DE, HL
        CALL PARSE_NUM
        EX   DE, HL

        ; Restore original character
        POP  AF
		PUSH HL
        LD   HL, (TEMP_STRING_PTR)
        LD   (HL), A
		POP  HL

        RET

; MATCH_STR: Checks if string at HL matches null-terminated string at DE.
MATCH_STR:
        PUSH HL
        PUSH DE
.match_loop:
        LD   A, (DE)
        OR   A
        JR   Z, .matched

        LD   B, A
        LD   A, (HL)
        CP   B
        JR   NZ, .mismatch

        INC  HL
        INC  DE
        JP   .match_loop
.matched:
        POP  DE
        POP  AF
        XOR  A
        RET
.mismatch:
        POP  DE
        POP  HL
        LD   A, 1
        OR   A
        RET

; SKIP_WS: Advances HL past spaces and tabs
SKIP_WS:
        LD   A, (HL)
        CP   ' '
        JR   Z, .skip_ws
        CP   9
        JR   Z, .skip_ws
        RET
.skip_ws:
        INC  HL
        JP   SKIP_WS

; SKIP_LINE: Advances HL past the next CR/LF
SKIP_LINE:
        LD   A, (HL)
        OR   A
        RET  Z
        CP   10
        JR   Z, .found_nl
        CP   13
        JR   Z, .found_cr
        INC  HL
        JP   SKIP_LINE
.found_cr:
        INC  HL
        LD   A, (HL)
        CP   10
        JR   Z, .skip_one_more
        RET
.found_nl:
        INC  HL
        LD   A, (HL)
        CP   13
        JR   Z, .skip_one_more
        RET
.skip_one_more:
        INC  HL
        RET

; PRINT_NL: Prints Carriage Return + Line Feed
PRINT_NL:
        PUSH HL
		LD   E, 13
        LD   C, SC_PUTCHAR
        CALL $0005
        LD   E, 10
        LD   C, SC_PUTCHAR
        CALL $0005
		POP  HL
        RET

; ====================================================================
; MATH EVALUATOR
; ====================================================================

; GET_TERM: Parses a number or a variable at HL.
GET_TERM:
        CALL SKIP_WS

		LD   DE, CMD_LEN
        CALL MATCH_STR
        JR   Z, EVAL_LEN

		LD   DE, CMD_VAL
        CALL MATCH_STR
        JR   Z, EVAL_VAL

        LD   A, (HL)
        CP   'A'
        JR   C, .is_num
        CP   'Z'+1
        JR   NC, .is_num

.is_var:
        SUB  'A'
        ADD  A, A
        LD   C, A
        LD   B, 0
        PUSH HL
        LD   IX, VARIABLES
        ADD  IX, BC
        LD   E, (IX+0)
        LD   D, (IX+1)
        POP  HL
        INC  HL
        RET

.is_num:
        CALL PARSE_NUM
        RET

EVAL_LEN:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL EVAL_STRING_EXPR       ; C = length
        LD   E, C
        LD   D, 0                   ; Return length in DE
        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; ====================================================================
; EVAL_VAL: Evaluates VAL(<string$>)
; Returns: DE = parsed 16-bit number
; ====================================================================
EVAL_VAL:
        CALL SKIP_WS
        INC  HL                     ; Skip '('
        CALL SKIP_WS

        CALL EVAL_STRING_EXPR       ; Returns DE = string pointer, C = length

        ; CRITICAL: Save the script pointer! PARSE_NUM_FROM_STRING uses HL internally.
        PUSH HL                     

        CALL PARSE_NUM_FROM_STRING  
        ; Note: PARSE_NUM_FROM_STRING outputs the parsed number in HL, not DE!
        
        EX   DE, HL                 ; Move the parsed number from HL to DE

        POP  HL                     ; Restore the script pointer safely

        CALL SKIP_WS
        INC  HL                     ; Skip ')'
        RET

; EVAL_EXPR: Evaluates "Term", "Term + Term", or "Term - Term"
EVAL_EXPR:
        CALL GET_TERM
        CALL SKIP_WS

        LD   A, (HL)
        CP   '+'
        JR   Z, .do_add
        CP   '-'
        JR   Z, .do_sub

        RET

.do_add:
        INC  HL
        PUSH DE
        CALL GET_TERM

        EX   (SP), HL
        ADD  HL, DE
        EX   DE, HL
        POP  HL
        RET

.do_sub:
        INC  HL
        PUSH DE
        CALL GET_TERM

        EX   (SP), HL
        OR   A
        SBC  HL, DE
        EX   DE, HL
        POP  HL
        RET

; PARSE_NUM: Parses ASCII number at HL into 16-bit integer in DE.
PARSE_NUM:
        LD   A, (HL)
        CP   '-'
        JR   NZ, .parse_unsigned

        INC  HL
        CALL .parse_unsigned

        ; Negate DE (Two's Complement)
        LD   A, D
        CPL
        LD   D, A
        LD   A, E
        CPL
        LD   E, A
        INC  DE
        RET

.parse_unsigned:
        LD   DE, 0
.loop:
        LD   A, (HL)
        CP   '0'
        RET  C
        CP   '9'+1
        RET  NC
        SUB  '0'

        PUSH HL
        LD   H, D
        LD   L, E
        ADD  HL, HL
        PUSH HL
        ADD  HL, HL
        ADD  HL, HL
        POP  BC
        ADD  HL, BC
        LD   C, A
        LD   B, 0
        ADD  HL, BC
        EX   DE, HL

        POP  HL
        INC  HL
        JP   .loop

; PRINT_NUM16: Prints the 16-bit signed integer in DE without leading zeros.
PRINT_NUM16:
        EX   DE, HL

        BIT  7, H
        JR   Z, .positive

        PUSH HL
        LD   E, '-'
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  HL

        LD   A, H
        CPL
        LD   H, A
        LD   A, L
        CPL
        LD   L, A
        INC  HL

.positive:
        LD   B, 0
        LD   DE, 10000
        CALL .digit
        LD   DE, 1000
        CALL .digit
        LD   DE, 100
        CALL .digit
        LD   DE, 10
        CALL .digit

        LD   B, 1
        LD   DE, 1

.digit:
        LD   A, '0'
.sub_loop:
        OR   A
        SBC  HL, DE
        JR   C, .done
        INC  A
        JP   .sub_loop
.done:
        ADD  HL, DE

        CP   '0'
        JR   NZ, .print_it

        LD   A, B
        OR   A
        RET  Z

        LD   A, '0'

.print_it:
        LD   B, 1
        PUSH HL
        PUSH BC
        LD   E, A
        LD   C, SC_PUTCHAR
        CALL $0005
        POP  BC
        POP  HL
        RET

; ====================================================================
; DATA SECTION
; ====================================================================

MSG_USAGE:      DB "Usage: BASIC <filename>", 13, 10, 0
MSG_ERR_OPEN:   DB "Error: Cannot open script file", 13, 10, 0
MSG_ERR_SYNTAX: DB "Syntax Error", 13, 10, 0
MSG_ERR_GOTO:   DB "Line Not Found", 13, 10, 0

CMD_PRINT:      DB "PRINT", 0
CMD_LET:        DB "LET", 0
CMD_GOTO:       DB "GOTO", 0
CMD_IF:         DB "IF", 0
CMD_THEN:       DB "THEN", 0
CMD_REM:        DB "REM", 0
CMD_INPUT:      DB "INPUT", 0
CMD_LEN:        DB "LEN", 0
CMD_LEFT:       DB "LEFT$", 0
CMD_RIGHT:      DB "RIGHT$", 0
CMD_MID:        DB "MID$", 0
CMD_CHR:        DB "CHR$", 0
CMD_STR:        DB "STR$", 0
CMD_VAL:        DB "VAL", 0

FILE_SIZE_BUF:  DS 4, 0

VARIABLES:      DS 52, 0        ; Memory for A-Z (26 variables * 2 bytes)

HEAP_PTR:       DS 2, 0         ; Current heap allocation pointer
TEMP_LEN:       DS 1, 0        ; Temporary storage for string length
TEMP_STRING_PTR: DS 2, 0        ; Temporary pointer storage

INPUT_BUFFER:   DS 256, 0      ; Buffer for INPUT and string operations

; String descriptor table - 26 entries for A$ through Z$
; Each entry is 6 bytes:
;   +0: Pointer to heap allocation (2 bytes)
;   +2: String length (1 byte)
;   +3: Reference count (1 byte)
;   +4: Flags (1 byte)
;   +5: Unused padding
STRING_DESC:    DS 26 * 6, 0   ; 156 bytes total for string descriptors
