	org 0x0100      ; Program starts at memory address 100

start:
    ; ==========================================
    ; Channel 0: C4 (0x0688)
    ; ==========================================
    ld a, 0x88      ; Freq LSB
    out (0x20), a
    
    ld a, 0x06      ; Freq MSB
    out (0x21), a
    
    ld a, 0x8A      ; Duty = 50% (10), Volume = 10 (1010)
    out (0x22), a
    
    ld a, 0x01      ; Enable Channel 0
    out (0x23), a

    ; ==========================================
    ; Channel 1: E4 (0x052F)
    ; ==========================================
    ld a, 0x2F      ; Freq LSB
    out (0x24), a
    
    ld a, 0x05      ; Freq MSB
    out (0x25), a
    
    ld a, 0x8A      ; Duty = 50% (10), Volume = 10 (1010)
    out (0x26), a
    
    ld a, 0x01      ; Enable Channel 1
    out (0x27), a

    ; ==========================================
    ; Channel 2: G4 (0x045C)
    ; ==========================================
    ld a, 0x5C      ; Freq LSB
    out (0x28), a
    
    ld a, 0x04      ; Freq MSB
    out (0x29), a
    
    ld a, 0x8A      ; Duty = 50% (10), Volume = 10 (1010)
    out (0x2A), a
    
    ld a, 0x01      ; Enable Channel 2
    out (0x2B), a

; Delay Subroutine for 2 seconds @ 3.5 MHz
; Total T-states required: 7,000,000
; -----------------------------------------
DELAY_2S:
    PUSH BC             ; 11 T-states
    PUSH DE             ; 11 T-states
    PUSH AF             ; 11 T-states

    LD D, 10            ; 7 T-states - Outer loop counter
OUTER_LOOP:
    LD BC, 26918        ; 10 T-states - Inner loop constant
INNER_LOOP:
    DEC BC              ; 6 T-states
    LD A, B             ; 4 T-states
    OR C                ; 4 T-states
    JR NZ, INNER_LOOP   ; 12 T-states (7 on last)
    
    DEC D               ; 4 T-states
    JR NZ, OUTER_LOOP   ; 12 T-states (7 on last)

    POP AF              ; 10 T-states
    POP DE              ; 10 T-states
    POP BC              ; 10 T-states
    


	ld a, 0x00      ; Disable Channel 0
    out (0x23), a

	ld a, 0x00      ; Disable Channel 1
    out (0x27), a

	ld a, 0x00      ; Disable Channel 2
    out (0x2B), a

    JP $003B
