; Z80 Test Program for Custom VDP
; Target: CP/M (.COM file, ORG 0x0100)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; 1. Switch to Video Mode 2 (220x144, 8-bit color)
        LD A, 2
        OUT (VDP_MODE_PORT), A

        ; 2. Reset VRAM Pointer to 0x0000
        ; We send 0 to Port 0x41 (Low Byte) and 0x42 (High Byte)
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; 3. Fill VRAM with a test pattern
        ; Mode 2 resolution is 220x144 = 31,680 bytes (0x7BC0)
        LD BC, 31680
        LD E, 0         ; E will act as our color value counter

DRAW_LOOP:
        ; Output the current color to VRAM
        ; Your emulator auto-increments the VRAM pointer here!
        LD A, E
        OUT (VDP_DATA), A

        ; Increment E to create a gradient effect across the screen
        INC E

        ; Standard Z80 16-bit loop countdown (BC = BC - 1)
        DEC BC
        LD A, B
        OR C
        JR NZ, DRAW_LOOP

        ; 4. Wait for a keypress
WAIT_KEY:
        ; Your emulator returns 0xFF if a key is ready, 0x00 if not
        IN A, (CON_STAT_PORT)
        OR A            
        JR Z, WAIT_KEY  ; Loop back if A is 0

        ; Consume the keypress from the console data port
        IN A, (CON_DATA_PORT) 

        ; 5. Restore Text Mode (Mode 0)
        XOR A
        OUT (VDP_MODE_PORT), A

        ; Exit back to the OS
        JP  $003B