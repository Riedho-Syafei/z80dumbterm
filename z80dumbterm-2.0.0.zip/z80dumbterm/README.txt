What's new:
Emulator now supports Graphics modes!
Mode 1: 24-bit True Color 120x90
Mode 2: 8-bit 256 Color 220x144
Mode 3: 4-bit 16 Color 320x200
Mode 4: 1-bit Monochrome 640x400

Mode 0 is the default text mode!
OUT to port 0x40 to change mode

CCP Version 1.0.0

CCP supported commands:

internal commands:
DIR
TYPE <filename>
EXIT
CREATE <filename>
DEL <filename>
REN <old filename> <new filename>

transient commands:
DISKSPACE [drive letter]
COPYTO [src drive letter, dest drive letter] [src filename] [dest filename]
