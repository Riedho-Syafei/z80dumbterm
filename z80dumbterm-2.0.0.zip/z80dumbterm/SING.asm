		ORG 0100h       ; Standard CP/M .COM origin

START:  
        LD HL, TUNE_DATA    ; HL points to the start of our sheet music

READ_NOTE:
        ; 1. Read Pitch Delay into BC
        LD E, (HL)
        INC HL
        LD D, (HL)
        INC HL
        PUSH DE
        POP BC

        ; Check if Pitch Delay is 0000h (End of tune marker)
        LD A, B
        OR C
        JR Z, DONE

        ; 2. Read Cycle Count (Duration) into DE
        LD E, (HL)
        INC HL
        LD D, (HL)
        INC HL

        ; Save our position in the sheet music
        PUSH HL

PLAY_NOTE:
        ; Check if the note is finished (Cycle Count DE == 0)
        LD A, D
        OR E
        JR Z, NOTE_DONE 

        ; --- GENERATE ONE FULL WAVE ---
        
        ; Speaker HIGH
        LD A, 01h
        OUT (20h), A
        PUSH BC
        CALL DELAY_16
        POP BC

        ; Speaker LOW
        LD A, 00h
        OUT (20h), A
        PUSH BC
        CALL DELAY_16
        POP BC

        ; Decrement cycle count and loop
        DEC DE
        JR PLAY_NOTE

NOTE_DONE:
        ; Insert a tiny silent pause (staccato) so consecutive 
        ; notes of the same pitch don't blend into one long beep.
        LD BC, 1500     
        CALL DELAY_16

        ; Restore our sheet music pointer and grab the next note
        POP HL
        JR READ_NOTE

DONE:
        ; Exit cleanly to CP/M
        JP $003B

; ---------------------------------------------------------
; 16-bit Delay Subroutine
; Input: BC = delay count
; ---------------------------------------------------------
DELAY_16:
        DEC BC
        LD A, B
        OR C
        JR NZ, DELAY_16
        RET

; ---------------------------------------------------------
; Sheet Music Data
; Format: DW PitchDelay, DW CycleCount
; Quarter Notes are ~400ms, Half Notes are ~800ms
; ---------------------------------------------------------
TUNE_DATA:
        ; C4 Quarter
        DW 295, 104
        DW 295, 104
        ; G4 Quarter
        DW 196, 157
        DW 196, 157
        ; A4 Quarter
        DW 175, 176
        DW 175, 176
        ; G4 Half
        DW 196, 314
        
        ; F4 Quarter
        DW 220, 140
        DW 220, 140
        ; E4 Quarter
        DW 234, 132
        DW 234, 132
        ; D4 Quarter
        DW 263, 117
        DW 263, 117
        ; C4 Half
        DW 295, 208

        ; G4 Quarter
        DW 196, 157
        DW 196, 157
        ; F4 Quarter
        DW 220, 140
        DW 220, 140
        ; E4 Quarter
        DW 234, 132
        DW 234, 132
        ; D4 Half
        DW 263, 234

        ; End Marker
        DW 0000, 0000