#include <SDL3/SDL.h>
#include <stdint.h>

#define VRAM_SIZE 32768 // 32KB

extern uint8_t vram[VRAM_SIZE];
extern uint16_t vram_ptr;
extern uint8_t video_mode; // 0=Text, 1=24bpp, 2=8bpp, 3=4bpp, 4=1bpp

// GPU Textures for each mode (Index 1 to 4)
extern SDL_Texture* mode_textures[5];

// CPU Pixel Buffer: Big enough to hold our largest resolution (640x400)
// Format is ARGB8888 (32 bits per pixel)
extern uint32_t frame_pixels[640 * 400];

extern void graphics_render(SDL_Renderer *r);