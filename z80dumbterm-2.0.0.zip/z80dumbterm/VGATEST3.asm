; Z80 Test Program for Custom VDP
; Target: CP/M (.COM file, ORG 0x0100)
; Mode 3 Test: 4-bit color (16 colors, packed 2 pixels/byte)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; 1. Switch to Video Mode 3
        LD A, 3
        OUT (VDP_MODE_PORT), A

        ; 2. Reset VRAM Pointer to 0x0000
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; 3. Setup the Packed Pixel Loop
        ; Assuming 320x200 resolution = 64,000 pixels.
        ; At 2 pixels per byte, we write 32,000 bytes (0x7D00).
        LD BC, 32000
        LD E, 0         ; Color seed counter

DRAW_LOOP:
        ; Pack two colors into one byte: (Color1 << 4) | Color2
        
        ; Calculate High Nibble (Left Pixel)
        LD A, E
        ADD A, A        ; Shift left 1
        ADD A, A        ; Shift left 2
        ADD A, A        ; Shift left 3
        ADD A, A        ; Shift left 4
        LD D, A         ; Store upper nibble in D
        
        ; Calculate Low Nibble (Right Pixel)
        LD A, E
        INC A           ; Make the second pixel a different color
        AND 0FH         ; Mask out upper bits just in case
        
        ; Combine them
        OR D            
        
        ; Output the packed byte (2 pixels) to VRAM
        OUT (VDP_DATA), A

        ; Increment the color seed. 
        ; Masking it with 0x0F isn't strictly necessary since we 
        ; shift it or mask it in the loop, but it keeps E predictable.
        INC E
        LD A, E
        AND 0FH
        LD E, A

        ; 16-bit countdown
        DEC BC
        LD A, B
        OR C
        JR NZ, DRAW_LOOP

        ; 4. Wait for a keypress
WAIT_KEY:
        IN A, (CON_STAT_PORT)
        OR A            
        JR Z, WAIT_KEY

        ; Consume the keypress
        IN A, (CON_DATA_PORT) 

        ; 5. Restore Text Mode (Mode 0)
        XOR A
        OUT (VDP_MODE_PORT), A

        JP  $003B