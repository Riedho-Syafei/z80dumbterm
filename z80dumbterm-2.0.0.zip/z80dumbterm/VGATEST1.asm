; Z80 Test Program for Custom VDP
; Target: CP/M (.COM file, ORG 0x0100)
; Mode 1 Test: 120x90, 24-bit color (RGB)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; 1. Switch to Video Mode 1 (120x90, 24-bit color)
        LD A, 1
        OUT (VDP_MODE_PORT), A

        ; 2. Reset VRAM Pointer to 0x0000
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; 3. Setup the 24-bit Pixel Loop
        ; 120 * 90 = 10,800 pixels to draw.
        LD BC, 10800    ; 16-bit pixel counter

        ; Initialize our RGB starting values
        LD D, 0         ; Red channel
        LD E, 85        ; Green channel (offset)
        LD H, 170       ; Blue channel (offset)

PIXEL_LOOP:
        ; Output 1 Pixel (3 bytes: R, G, B)
        LD A, D
        OUT (VDP_DATA), A   ; Write Red
        
        LD A, E
        OUT (VDP_DATA), A   ; Write Green
        
        LD A, H
        OUT (VDP_DATA), A   ; Write Blue

        ; Shift the colors at different rates for a cool pattern
        INC D           ; Red increases by 1
        
        LD A, E
        ADD A, 2
        LD E, A         ; Green increases by 2
        
        LD A, H
        ADD A, 3
        LD H, A         ; Blue increases by 3

        ; Decrement 16-bit pixel counter
        ; (DEC BC doesn't set the Zero flag, so we manually check it)
        DEC BC
        LD A, B
        OR C
        JR NZ, PIXEL_LOOP

        ; 4. Wait for a keypress
WAIT_KEY:
        IN A, (CON_STAT_PORT)
        OR A            
        JR Z, WAIT_KEY  ; Loop back if no key is ready

        ; Consume the keypress from the console data port
        IN A, (CON_DATA_PORT) 

        ; 5. Restore Text Mode (Mode 0)
        XOR A
        OUT (VDP_MODE_PORT), A

        ; Exit back to the OS
        JP  $003B