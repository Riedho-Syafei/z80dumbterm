; SYSCALL entry: CALL 0005h

; Input:
;   C  = syscall number
;   B  = arg0 (small value)
;   DE = arg1 (pointer / size)
;   HL = arg2 (secondary pointer)

; Returns:
;   A  = status / value
;   HL = pointer / value
;   B  = optional secondary value

; Preserved across syscall:
;   DE

; Clobbered:
;   AF, BC, HL

        ORG $0000
		JP BOOT

		BLOCK $0005 - $, 0
		ORG $0005
        JP  SYSCALL

		BLOCK $003B - $, 0
		ORG $003B
		JP WBOOT				; CALL $003B when program finished

		BLOCK $0080 - $, 0
		ORG $0080				; CCP's arguments
ARG0:	DS 16, 0
ARG1:	DS 16, 0
ARG2:	DS 16, 0
ARG3:	DS 16, 0
		
		BLOCK $0100 - $, 0
		ORG $0100

PROGRAM:

; ================================================================
; BOOT ROUTINE (OS)
; ================================================================

		BLOCK $E000 - $, 0
		ORG $E000

BOOT:
		LD   SP, $FFF0
		
		CALL k_init_disk

		CALL k_fs_load_map

WBOOT:
        LD   SP, $FFF0

		LD   B, 0				; Select drive A:
		LD   C, 18
		CALL $0005

        ; -----------------------------
        ; OPEN file "CCP.COM"
        ; -----------------------------
        LD   C, 33
        LD   DE, CCP_FILENAME
        CALL $0005
        OR   A
        JR   NZ, error           ; Open failed

        ; -----------------------------
        ; Get exact file size in bytes
        ; -----------------------------
        ; SYS_FS_OPEN loads the FEB into FEB01.
        ; Byte 17 is LSB, Byte 18 is MSB of the file size.
        LD   HL, (FEB01 + 17)    ; HL = 16-bit file size
        
        LD   A, H
        OR   L
        JR   Z, read_done        ; If size is 0 bytes, nothing to load

        ; -----------------------------
        ; READ entire file in one call
        ; -----------------------------
        LD   DE, $C000           ; DE = Destination buffer
        LD   C, 34               ; C  = SYS_FS_READ syscall
        CALL $0005
        
        ; A = 0 (Success) or 1 (EOF). Both are completely fine here.
        CP   $FF
        JR   Z, error            ; Real read error

read_done:
        ; -----------------------------
        ; CLOSE file
        ; -----------------------------
        LD   C, 35
        CALL $0005

        ; -----------------------------
        ; EXECUTE CCP
        ; -----------------------------
        CALL $C000

        ; exit (fallback if CCP returns)
        LD   C, 0
        CALL $0005

error:
        ; handle error (e.g., halt)
        DI
        HALT

CCP_FILENAME:
        DB "CCP.COM",0

; ================================================================
; SYSCALLS (OS) AREA
; ================================================================

SYSCALL:
        PUSH DE            ; preserved by ABI
        PUSH BC            ; syscall number lives here
		
		LD   A, C

        CP   0
        JP   Z, SYS_EXIT

        CP   1
        JP   Z, SYS_PUTCHAR

        CP   2
        JP   Z, SYS_GETCHAR

        CP   3
        JP   Z, SYS_PUTS

        CP   4
        JP   Z, SYS_VERSION

        CP   5
        JP   Z, SYS_IDLE

		CP   6
		JP   Z, SYS_GET_TICKS

		CP   7
		JP   Z, SYS_GET_MEMINFO

		CP   8
		JP   Z, SYS_MALLOC

		CP   9
		JP   Z, SYS_IN_PORT

		CP   10
		JP   Z, SYS_OUT_PORT

		CP   11
		JP   Z, SYS_GETS

		CP   12
		JP   Z, SYS_COMPARE_STRINGS

		CP   13
		JP   Z, SYS_PRINT_CHAR

		CP   16
		JP   Z, SYS_DISK_READ

		CP   17
		JP   Z, SYS_DISK_WRITE

		CP   18
		JP   Z, SYS_DISK_SELECT

		; ================================
		; File System Calls
		; ================================

		CP   32
		JP   Z, SYS_FS_LIST

		CP   33
		JP   Z, SYS_FS_OPEN

		CP   34
		JP   Z, SYS_FS_READ

		CP   35
		JP   Z, SYS_FS_CLOSE

		CP   36
		JP   Z, SYS_FS_SEEK

		CP   37
        JP   Z, SYS_FS_CREATE

		CP   38
        JP   Z, SYS_FS_DELETE

		CP   39
        JP   Z, SYS_FS_RENAME

		CP   40
		JP   Z, SYS_FS_WRITE

		CP   41
		JP   Z, SYS_FS_TELL

		CP   42
		JP   Z, SYS_FS_FILE_SIZE

		CP   43
		JP   Z, SYS_FS_DISK_REMAINING

        ; unknown syscall
        LD   A, $FF
        JP   SYSCALL_RETURN

SYSCALL_RETURN:
		POP  BC
        POP  DE
        RET

SYS_EXIT:
        POP  BC
        POP  DE
        
		JP   WBOOT

SYS_PUTCHAR:
        CALL k_putchar
        JP   SYSCALL_RETURN

SYS_GETCHAR:
		CALL k_getchar
        JP   SYSCALL_RETURN

SYS_PUTS:
        CALL k_puts
        JP   SYSCALL_RETURN

SYS_VERSION:
        LD   A, 0          ; major
        LD   B, 1          ; minor
        JP   SYSCALL_RETURN

SYS_IDLE:
.wait:
        IN   A, ($01)
        OR   A
        JR   Z, .wait
        XOR  A
        JP   SYSCALL_RETURN

SYS_GET_TICKS:
        IN   A, ($08)			; read from port 08 (cpu clock)
		LD   H, 0
		LD   L, A				; move it to L
		XOR  A					; success
        JP   SYSCALL_RETURN

SYS_GET_MEMINFO:
        XOR  A
        LD   HL, 0
        JP   SYSCALL_RETURN

SYS_MALLOC:
        XOR  A
        LD   HL, 0
        INC  A             ; A = error
        JP   SYSCALL_RETURN

; B = Port Number
SYS_IN_PORT:
        LD   C, B
        IN   A, (C)
        JP   SYSCALL_RETURN

; B = Port Number. E = 8-bit data
SYS_OUT_PORT:
        LD   C, B
        LD   A, E
        OUT  (C), A
        XOR  A
        JP   SYSCALL_RETURN

SYS_DISK_READ:
		CALL k_disk_read
		JP   SYSCALL_RETURN

SYS_DISK_WRITE:
		CALL k_disk_write
		JP   SYSCALL_RETURN

SYS_DISK_SELECT:
		
		PUSH BC
		CALL k_disk_ready				; We need B for k_disk_select
		POP  BC

		OR   A
		JR   NZ, .err_disk_not_ready
		
		CALL k_disk_select

		CALL k_init_disk
		CALL k_fs_load_map

		XOR  A

		JP   SYSCALL_RETURN

.err_disk_not_ready:
		LD   A, $FF
		JP   SYSCALL_RETURN

SYS_GETS:
		CALL k_gets
		JP   SYSCALL_RETURN

SYS_COMPARE_STRINGS:
		CALL k_compare_strings
		JP   SYSCALL_RETURN

SYS_PRINT_CHAR:
		CALL k_print_char
		JP   SYSCALL_RETURN

; ==================================================================
; File system calls (OS)
; ==================================================================

; ------------------------------------------------------------------
; SYS_FS_LIST
; Iterates through the Superblock, reads File Entry Blocks (FEB),
; and prints the filenames found within them.
; ------------------------------------------------------------------
SYS_FS_LIST:
    LD   A, (SUPERBLOCK+1)      ; Byte 1: Number of files
    LD   B, A                   ; B = Loop Counter
    OR   A
    JP   Z, SYSCALL_RETURN      ; Return if 0 files

    LD   HL, SUPERBLOCK+2       ; Byte 2: Start of FEB pointers

.list_loop:
    PUSH BC                     ; Save loop counter
    
    ; --- Read the FEB Pointer ---
    LD   E, (HL)                ; Low byte (Sector)
    INC  HL
    LD   D, (HL)                ; High byte (Track)
    INC  HL
    PUSH HL                     ; Save Superblock array pointer

    ; --- Read the FEB ---
    LD   L, E
    LD   H, D                   ; HL = Sector/Track of FEB
    LD   DE, IEB_BUFFER         ; Load FEB into buffer (using IEB_BUFFER)
    CALL k_disk_read

    ; --- Print Filename ---
    ; Filename is at Byte 0-14 of the FEB (FEB01)
    LD   DE, IEB_BUFFER			; (using IEB_BUFFER)
    CALL k_puts
    CALL k_newline

    POP  HL                     ; Restore Superblock array pointer
    POP  BC                     ; Restore loop counter
    DJNZ .list_loop             ; Dec B, Jump if NZ

    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_OPEN
; Input: DE = Pointer to filename string
; Output: A = 0 (Success), FF (Fail)
; Logic: Finds FEB, loads it into FEB01, resets read cursor.
; ------------------------------------------------------------------
SYS_FS_OPEN:
    ; --- Prevent overwriting an open file's state ---
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JP   NZ, .open_fail         ; Exit if a file is currently open
	
	LD   (SCRATCH1), DE         ; Save requested filename pointer

    LD   A, (SUPERBLOCK+1)      ; Get total file count from Superblock
    LD   B, A                   ; B = Loop Counter
    OR   A
    JP   Z, .open_fail          ; No files exist to open

    LD   HL, SUPERBLOCK+2       ; Point to first FEB pointer in Superblock

.open_loop:
    PUSH BC                     ; Save loop counter
    
    ; --- Get FEB location ---
    LD   E, (HL)                ; E = Sector
    INC  HL
    LD   D, (HL)                ; D = Track
    INC  HL
    LD   (FILE_POINTER), HL     ; Save current Superblock array position

    PUSH DE                     ; [Stack: Sector/Track] - Save for potential success

    ; --- Read the FEB into the FEB01 buffer ---
    LD   L, E                   ; L = Sector
    LD   H, D                   ; H = Track
    LD   DE, FEB01              ; DMA destination
    CALL k_disk_read            ; Load the FEB metadata

    ; --- Compare Filename ---
    LD   HL, FEB01              ; Filename field in the FEB (Bytes 0-14)
    LD   DE, (SCRATCH1)         ; Target filename string
    CALL k_compare_strings      ; Returns Z if identical
    
    JR   Z, .open_success       ; Match found!

    ; --- No match: Clean up and continue loop ---
    POP  DE                     ; Remove unused Sector/Track from stack
    POP  BC                     ; Restore loop counter
    LD   HL, (FILE_POINTER)     ; Restore Superblock pointer for next iteration
    DJNZ .open_loop             ; Repeat until all files checked

.open_fail:
    LD   A, $FF                 ; Return failure code
    JP   SYSCALL_RETURN         ; Exit via standard return

.open_success:
    ; --- Finalize Meta Data ---
    POP  DE                     ; [Stack: Sector/Track] - Pop the correct FEB address
    POP  BC                     ; Clean up the loop counter from the stack
    
    ; Save physical location for later write-backs (SYS_FS_CLOSE)
    LD   A, E                   ; Sector
    LD   (OPEN_FILE_SECTOR), A  ;
    LD   A, D                   ; Track
    LD   (OPEN_FILE_TRACK), A   ;

    ; Set active state
    LD   A, 1                   ;
    LD   (OPEN_FILE_FLAG), A    ; File is now officially open

    ; --- Reset File Cursor ---
    XOR  A                      ;
    LD   (FILE_CURSOR_BYTE), A   ; Reset 32-bit byte offset to 0 (low byte)
    LD   (FILE_CURSOR_BYTE+1), A ; -- repeat --
	LD   (FILE_CURSOR_BYTE+2), A ; -- repeat --
	LD   (FILE_CURSOR_BYTE+3), A ; Reset 32-bit byte offset to 0 (high byte)

    XOR  A                      ; Return 0 for success
    JP   SYSCALL_RETURN         ;

;
; Close the file opened by SYS_FS_OPEN
; Writes back the modified FEB (in FEB01) to disk
;
; Returns:
;   A  = 0 on success, $FF on failure
; Preserved: DE
; Clobbered: AF, BC, HL
;
SYS_FS_CLOSE:
        ; Check if a file is currently open
        LD   A, (OPEN_FILE_FLAG)
        OR   A
        JR   Z, .no_file_open       ; If flag is 0, no file is open

        ; Get the sector/track where FEB is stored (as separate bytes)
        LD   A, (OPEN_FILE_SECTOR)
        LD   L, A                    ; L = sector number
        LD   A, (OPEN_FILE_TRACK)
        LD   H, A                    ; H = track number

        ; Write FEB01 back to disk
        LD   DE, FEB01               ; DE = DMA address (FEB buffer)
        CALL k_disk_write

        ; Check write status
        OR   A
        JR   NZ, .write_failed       ; If A != 0, write failed

        ; Clear the open file flag
        XOR  A
        LD   (OPEN_FILE_FLAG), A

        ; Success - return 0
        JP   SYSCALL_RETURN

.write_failed:
        LD   A, $FF                  ; Error code
        JP   SYSCALL_RETURN

.no_file_open:
        LD   A, $FF                  ; No file was open
        JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_READ (Byte-Based)
; Input:  DE = Destination Buffer
;         HL = Number of bytes to read
; Output: A  = 0 (Success), 1 (EOF reached), FF (Fail)
; ------------------------------------------------------------------
SYS_FS_READ:
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JP   Z, .read_fail          ; Error if no file is open

    LD   (SCRATCH1), DE         ; Save User Buffer pointer
    LD   (SCRATCH2), HL         ; Save Bytes Remaining counter

.read_loop:
    ; Check if 0 bytes remaining to read
    LD   HL, (SCRATCH2)
    LD   A, H
    OR   L
    JP   Z, .read_success       ; Done reading!

    ; ----------------------------------------------------------
    ; STEP 1: Calculate Offset & Default Chunk Size
    ; ----------------------------------------------------------
    LD   A, (FILE_CURSOR_BYTE)
    AND  $7F                    ; A = Cursor % 128
    LD   (SYS_FS_READ_OFFSET), A
    
    ; Space Left in Block = 128 - Offset
    LD   B, A
    LD   A, 128
    SUB  B
    LD   C, A                   ; C = Space left in block

    ; Default Chunk = min(Bytes Remaining, Space Left)
    LD   HL, (SCRATCH2)
    LD   A, H
    OR   A
    JR   NZ, .chunk_is_space_left    ; Jump to the new label
    LD   A, C
    CP   L
    JR   C, .chunk_is_space_left     ; Space Left < Remaining
    LD   A, L                        ; Space Left >= Remaining
    JR   .store_chunk                ; Skip over the C load

.chunk_is_space_left:
    LD   A, C                        ; Grab the Space Left value!

.store_chunk:
    LD   (SYS_FS_READ_CHUNK), A

    ; ----------------------------------------------------------
    ; STEP 2: EOF Bounds Check (Clamp chunk to file size)
    ; ----------------------------------------------------------
    ; 32-bit subtraction: Diff (DE:BC) = Size (FEB01[17:20]) - Cursor
    LD   A, (FEB01 + 17)
    LD   HL, FILE_CURSOR_BYTE
    SUB  (HL)
    LD   C, A                   ; LSB

    LD   A, (FEB01 + 18)
    INC  HL
    SBC  A, (HL)
    LD   B, A

    LD   A, (FEB01 + 19)
    INC  HL
    SBC  A, (HL)
    LD   E, A

    LD   A, (FEB01 + 20)
    INC  HL
    SBC  A, (HL)
    LD   D, A                   ; MSB

    ; Check results of subtraction
    JP   C, .eof_reached        ; Carry set: Cursor > Size (EOF)
    
    LD   A, D
    OR   E
    OR   B
    JR   NZ, .size_ok           ; Diff >= 256 bytes (chunk is safe)
    
    LD   A, C
    OR   A
    JP   Z, .eof_reached        ; Diff == 0: Cursor == Size (EOF)

    ; Diff < 256. If Diff < Chunk, clamp Chunk = Diff
    LD   HL, SYS_FS_READ_CHUNK
    CP   (HL)
    JR   NC, .size_ok           ; Diff >= Chunk Size
    LD   (HL), A                ; Clamp chunk to remaining file bytes

.size_ok:
    ; ----------------------------------------------------------
    ; STEP 3: Calculate Logical Block (Cursor / 128)
    ; ----------------------------------------------------------
    LD   HL, FILE_CURSOR_BYTE
    CALL k_load32_dehl          ; Load 32-bit cursor into DE:HL
    CALL k_div128_32bit         ; Divide by 128. HL now holds Logical Block Index.

    ; ----------------------------------------------------------
    ; STEP 4: Locate IEB
    ; IEB Index = Logical Block / 64
    ; ----------------------------------------------------------
    PUSH HL                     ; Save Logical Block
    LD   B, 6
.ieb_div_loop:
    SRL  H
    RR   L
    DJNZ .ieb_div_loop          ; L = IEB Index
    
    ; Address = FEB01 + 21 + (IEB Index * 2)
    LD   H, 0
    ADD  HL, HL
    LD   DE, 21                 ; FEB Offset
    ADD  HL, DE
    LD   DE, FEB01
    ADD  HL, DE                 ; HL = IEB Pointer Address
    
    LD   E, (HL)
    INC  HL
    LD   D, (HL)
    
    LD   A, E
    OR   D
    JR   Z, .sparse_block       ; IEB is 0000 (unallocated)

    ; Read IEB into IEB_BUFFER
    LD   L, E
    LD   H, D
    PUSH HL                     ; Save IEB Location
    LD   DE, IEB_BUFFER
    CALL k_disk_read
    POP  HL
    JR   .ieb_ready

.sparse_block:
    POP  HL                     ; Clean Stack (Logical Block)
    JR   .fill_zeros            ; Return zeros for unallocated space

.ieb_ready:
    ; ----------------------------------------------------------
    ; STEP 5: Locate Data Block
    ; Data Index = Logical Block % 64
    ; ----------------------------------------------------------
    POP  HL                     ; HL = Logical Block
    LD   A, L
    AND  $3F                    ; A = Index
    RLCA                        ; A = Index * 2 (Pointers are 2 bytes)
    
    LD   E, A
    LD   D, 0
    LD   HL, IEB_BUFFER
    ADD  HL, DE                 ; HL = Data Pointer Address
    
    LD   C, (HL)
    INC  HL
    LD   B, (HL)

    LD   A, C
    OR   B
    JR   Z, .fill_zeros         ; Data pointer is 0000 (unallocated)

    ; Read Data Block into DATA_BUFFER
    LD   L, C
    LD   H, B
    PUSH HL
    LD   DE, DATA_BUFFER
    CALL k_disk_read
    POP  HL

    ; ----------------------------------------------------------
    ; STEP 6: Copy Sector Data to User Buffer
    ; ----------------------------------------------------------
    LD   A, (SYS_FS_READ_OFFSET)
    LD   E, A
    LD   D, 0
    LD   HL, DATA_BUFFER
    ADD  HL, DE                 ; HL = Source (DATA_BUFFER + Offset)

    LD   DE, (SCRATCH1)         ; DE = Destination (User Buffer)
    
    LD   A, (SYS_FS_READ_CHUNK)
    LD   C, A
    LD   B, 0                   ; BC = Chunk Size
    
    PUSH BC                     ; Save Chunk Size
    LDIR                        ; Memory copy
    JR   .update_pointers

.fill_zeros:
    ; ----------------------------------------------------------
    ; STEP 6b: Fill User Buffer with Zeros (Sparse Blocks)
    ; ----------------------------------------------------------
    LD   HL, (SCRATCH1)         ; HL = Start of User Buffer
    LD   A, (SYS_FS_READ_CHUNK)
    LD   C, A
    LD   B, 0                   ; BC = Chunk Size
    
    PUSH BC                     ; Save Chunk Size
    CALL k_mem_clear            ; Fills HL to HL+BC with 0. Returns HL = End.
    LD   DE, HL                 ; Set DE to new buffer position

.update_pointers:
    ; ----------------------------------------------------------
    ; STEP 7: Advance Pointers & Counters
    ; ----------------------------------------------------------
    LD   (SCRATCH1), DE         ; Update User Buffer Pointer

    POP  BC                     ; Retrieve Chunk Size
    LD   HL, (SCRATCH2)
    OR   A
    SBC  HL, BC
    LD   (SCRATCH2), HL         ; Decrement Bytes Remaining

    ; Advance 32-bit Cursor by Chunk Size
    LD   HL, FILE_CURSOR_BYTE
    ; C already holds the Chunk Size. We just need to zero out B, D, and E.
    LD   B, 0
    LD   DE, 0
    CALL k_add32_mem            ; Adds DE:BC to the 32-bit value at HL

    JP   .read_loop             ; Loop for next chunk

.read_success:
    XOR  A                      ; A = 0 (Success)
    JP   SYSCALL_RETURN

.eof_reached:
    LD   A, 1                   ; A = 1 (EOF)
    JP   SYSCALL_RETURN

.read_fail:
    LD   A, $FF
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_SEEK
; Input:  DE = Lower 16-bits of the target byte offset
;         HL = Upper 16-bits of the target byte offset
; Set the 32-bit FILE_CURSOR_BYTE
; It uses the exact 32-bit file size from FEB01 to check for out-of-bounds
; Output: A = 0 (Success), FF (Fail/Out-of-bounds)
; ------------------------------------------------------------------
SYS_FS_SEEK:
    ; 1. Check if a file is currently open
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JR   Z, .seek_err

    ; 2. 32-bit Bounds Check (Target <= Size)
    LD   B, D                       ; Move lower 16 bits (DE) to BC
    LD   C, E
    EX   DE, HL                     ; Move upper 16 bits (HL) to DE
    
    LD   HL, FEB01 + 17             ; Pointer to 32-bit File Size
    CALL k_cmp32_mem                ; Compares Size (HL) with Target (DE:BC)
    
    JR   C, .seek_err               ; Carry set means Size < Target (Bad)

    ; 3. Success - Update 32-bit Cursor
    LD   (FILE_CURSOR_BYTE), BC     ; Store lower 16-bits (now in BC)
    LD   (FILE_CURSOR_BYTE + 2), DE ; Store upper 16-bits (now in DE)
    
    XOR  A                          ; A = 0 (Success)
    JP   SYSCALL_RETURN

.seek_err:
    LD   A, $FF                     ; A = FF (Error)
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_WRITE (Byte-Based Redesign)
; Input:  DE = Source Buffer
;         HL = Number of bytes to write
; Output: A  = 0 (Success), FF (Fail/Disk Full)
; ------------------------------------------------------------------
SYS_FS_WRITE:
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JP   Z, .write_fail

    LD   (SCRATCH1), DE         ; Save User Buffer pointer
    LD   (SCRATCH2), HL         ; Save Bytes Remaining counter

.write_loop:
    ; Check if 0 bytes remaining
    LD   HL, (SCRATCH2)
    LD   A, H
    OR   L
    JP   Z, .write_done         ; Done writing!

    ; ----------------------------------------------------------
    ; STEP 1: Calculate Offset & Chunk Size
    ; ----------------------------------------------------------
    LD   A, (FILE_CURSOR_BYTE)
    AND  $7F                    ; A = Cursor % 128 (Byte offset in block)
    LD   (SYS_FS_WRITE_OFFSET), A
    
    ; Space Left in Block = 128 - Offset
    LD   B, A
    LD   A, 128
    SUB  B
    LD   C, A                   ; C = Space left in block

    ; Calculate Chunk = min(Bytes Remaining, Space Left)
    LD   A, H                   ; Check high byte of Bytes Remaining (HL)
    OR   A
    JR   NZ, .chunk_is_space_left ; If H > 0, Bytes Remaining is > 255. So, the chunk size will be limited by Space Left (C).

    ; If H = 0, Bytes Remaining (L) is <= 255.
    ; Compare Space Left (C) with Bytes Remaining (L).
    LD   A, C                   ; Load Space Left (C) into A for comparison
    CP   L                      ; Compare Space Left (A) with Bytes Remaining (L)
    JR   C, .chunk_is_space_left ; If Space Left (A) < Bytes Remaining (L), use Space Left (A).
    LD   A, L                   ; Else (Space Left >= Bytes Remaining), use Bytes Remaining (L).
    JR   .store_chunk           ; Jump to store the calculated chunk size

.chunk_is_space_left:
    LD   A, C                   ; Chunk is Space Left (C).

.store_chunk:
    LD   (SYS_FS_WRITE_CHUNK), A

    ; ----------------------------------------------------------
    ; STEP 2: Calculate Logical Block (Cursor / 128)
    ; ----------------------------------------------------------
    LD   HL, FILE_CURSOR_BYTE
    CALL k_load32_dehl          ; Load 32-bit cursor into DE:HL
    CALL k_div128_32bit         ; Divide by 128. HL now holds Logical Block Index.

    ; ----------------------------------------------------------
    ; STEP 3: Locate/Allocate IEB
    ; IEB Index = Logical Block / 64
    ; ----------------------------------------------------------
    PUSH HL                     ; Save Logical Block
    LD   B, 6
.ieb_div_loop:
    SRL  H
    RR   L
    DJNZ .ieb_div_loop          ; L = IEB Index
    
    ; Max IEBs with new FEB is 53 (107 bytes / 2)
    LD   A, L
    CP   53
    JP   NC, .err_disk_full_pop

    ; Calculate pointer address in FEB01 (Offset 21)
    LD   H, 0
    ADD  HL, HL                 ; Index * 2
    LD   DE, 21                 ; NEW FEB OFFSET
    ADD  HL, DE
    LD   DE, FEB01
    ADD  HL, DE                 ; HL = Address of IEB Pointer
    
    LD   E, (HL)
    INC  HL
    LD   D, (HL)
    
    LD   A, E
    OR   D
    JR   NZ, .ieb_exists

.ieb_alloc:
    DEC  HL
    PUSH HL                     ; Save FEB pointer
    CALL k_fs_allocate_block
    OR   A
    JP   NZ, .err_disk_full_pop2
    POP  IX
    LD   (IX+0), L
    LD   (IX+1), H
    
    ; Increment IEB count at Byte 16
    LD   A, (FEB01 + 16)
    INC  A
    LD   (FEB01 + 16), A
    
    ; Clear IEB buffer
    PUSH HL
    LD   HL, IEB_BUFFER
    LD   BC, 128
    CALL k_mem_clear
    POP  HL
    JR   .ieb_ready

.ieb_exists:
    LD   L, E
    LD   H, D
    PUSH HL
    LD   DE, IEB_BUFFER
    CALL k_disk_read
    POP  HL

.ieb_ready:
    PUSH HL                     ; [Stack: IEB Loc, Logical Block]

    ; ----------------------------------------------------------
    ; STEP 4: Locate/Allocate Data Block
    ; Data Index = Logical Block % 64
    ; ----------------------------------------------------------
    POP  DE                     ; DE = IEB Loc
    POP  HL                     ; HL = Logical Block
    PUSH HL
    PUSH DE

    LD   A, L
    AND  $3F                    ; A = Logical Block % 64
    RLCA                        ; A = A * 2 (2 bytes per pointer)
    
    LD   E, A
    LD   D, 0
    LD   HL, IEB_BUFFER
    ADD  HL, DE                 ; HL points to Data pointer
    
    LD   C, (HL)
    INC  HL
    LD   B, (HL)

    LD   A, C
    OR   B
    JR   NZ, .data_exists

.data_alloc:
    DEC  HL
    PUSH HL                     ; Save Data pointer address
    CALL k_fs_allocate_block
    OR   A
    JR   NZ, .err_disk_full_pop3
    POP  IX
    LD   (IX+0), L
    LD   (IX+1), H

    ; Flush modified IEB to disk
    POP  DE                     ; IEB Loc
    PUSH DE
    PUSH HL
    LD   L, E
    LD   H, D
    LD   DE, IEB_BUFFER
    CALL k_disk_write
    POP  HL

    ; Clear DATA_BUFFER to prevent random data at EOF
    PUSH HL
    LD   HL, DATA_BUFFER
    LD   BC, 128
    CALL k_mem_clear
    POP  HL
    JR   .data_ready

.data_exists:
    LD   L, C
    LD   H, B                   ; HL = Target Sector/Track

    ; READ-MODIFY-WRITE: Load existing data first
    PUSH HL
    LD   DE, DATA_BUFFER
    CALL k_disk_read
    POP  HL

.data_ready:
    POP  BC                     ; Clean stack
    POP  BC

    ; ----------------------------------------------------------
    ; STEP 5: Modify the Sector Buffer
    ; ----------------------------------------------------------
    PUSH HL                     ; Save Target Sector/Track

    ; Setup Destination: DATA_BUFFER + Offset
    LD   A, (SYS_FS_WRITE_OFFSET)
    LD   E, A
    LD   D, 0
    LD   HL, DATA_BUFFER
    ADD  HL, DE
    EX   DE, HL                 ; DE = Destination

    ; Setup Source: User Buffer
    LD   HL, (SCRATCH1)

    ; Setup Byte Count
    LD   A, (SYS_FS_WRITE_CHUNK)
    LD   C, A
    LD   B, 0                   ; BC = Chunk Size
    
    PUSH BC                     ; Save Chunk Size for math

    ; Perform the memory copy
    LDIR

    ; Advance User Buffer pointer (SCRATCH1)
    LD   (SCRATCH1), HL

    ; Decrement Bytes Remaining (SCRATCH2)
    POP  BC                     ; BC = Chunk Size
    LD   HL, (SCRATCH2)
    OR   A
    SBC  HL, BC
    LD   (SCRATCH2), HL

    ; ----------------------------------------------------------
    ; STEP 6: Write Modified Buffer to Disk
    ; ----------------------------------------------------------
    POP  HL                     ; Restore Target Sector/Track
    LD   DE, DATA_BUFFER
    CALL k_disk_write

    ; ----------------------------------------------------------
    ; STEP 7: Advance 32-bit Cursor & Update File Size
    ; ----------------------------------------------------------
    LD   HL, FILE_CURSOR_BYTE
    ; C already holds the Chunk Size. We just need to zero out B, D, and E.
    LD   B, 0
    LD   DE, 0
    CALL k_add32_mem            ; Adds DE:BC to the 32-bit value at HL

    ; Local routine to update FEB01[17:20] if Cursor > Size
    CALL .update_size

    JP   .write_loop

.write_done:
    XOR  A                      ; Success
    JP   SYSCALL_RETURN

.err_disk_full_pop3:
    POP  HL
.err_disk_full_pop2:
    POP  HL
.err_disk_full_pop:
    POP  HL
.write_fail:
    LD   A, $FF
    JP   SYSCALL_RETURN

; --- Local Helper ---
.update_size:
    ; Load Cursor into DE:BC
    LD   HL, FILE_CURSOR_BYTE
    CALL k_load32_dehl          ; DE:HL = Cursor
    LD   B, H                   ; Move low word to BC for comparison
    LD   C, L
    
    ; Compare against Size
    LD   HL, FEB01 + 17         ; Pointer to Size
    CALL k_cmp32_mem            ; Compare Size (HL) with Cursor (DE:BC)
    
    JR   NC, .ok                ; If Size >= Cursor (No Carry), we are fine.

.update:
    ; Cursor > Size. Copy Cursor to FEB01[17:20]
    LD   HL, FILE_CURSOR_BYTE
    LD   DE, FEB01 + 17
    LD   BC, 4
    LDIR
.ok:
    RET

; ------------------------------------------------------------------
; SYS_FS_CREATE
; Creates a new file.
; Input:  DE = Pointer to filename (ASCII, null-terminated)
; Output: A  = 0 (Success), 1 (same filename), 2 (dir full), 3 (disk full)
; ------------------------------------------------------------------
SYS_FS_CREATE:
    LD   (SCRATCH1), DE         ; Save filename pointer

    ; 1. Check if Superblock directory is full
    LD   A, (SUPERBLOCK+1)          ; Get file count
    CP   63                         ; Max files ( (128 bytes - 2) / 2 pointers )
    JP   NC, .create_err_dir_full   ; Directory full

    ; 2. Check if file already exists
    ; We must iterate through the Superblock to ensure unique filenames.
    ; We use SCRATCH_BUFFER1 for reading FEBs to avoid clobbering FEB01
    ; (in case a file is currently open).
    LD   HL, SUPERBLOCK+2       ; Point to first file pointer
    LD   B, A                   ; Loop counter = current file count
    OR   A                      ; Check if count is 0
    JR   Z, .create_do_alloc    ; If 0 files, skip check and allocate

.create_check_loop:
    PUSH BC                     ; Save loop counter
    PUSH HL                     ; Save Superblock pointer

    ; Read FEB of existing file
    LD   E, (HL)                ; Sector
    INC  HL
    LD   D, (HL)                ; Track
    
    LD   L, E
    LD   H, D
    LD   DE, SCRATCH_BUFFER1     ; Use Scratch Buffer
    CALL k_disk_read

    ; Compare filenames
    LD   HL, SCRATCH_BUFFER1     ; Filename in FEB just read
    LD   DE, (SCRATCH1)          ; New Filename
    CALL k_compare_strings
    JR   Z, .create_err_exists  ; Match found!

    POP  HL                     ; Restore Superblock pointer
    INC  HL
    INC  HL                     ; Advance to next pointer (2 bytes)
    POP  BC                     ; Restore loop counter
    DJNZ .create_check_loop     ; Loop

    ; 3. Allocate a new sector for the FEB
.create_do_alloc:
    CALL k_fs_allocate_block    ; Returns L=Sector, H=Track
    OR   A
    JR   NZ, .create_err_disk_full ; Disk full

    PUSH HL                     ; Save New FEB Location (L=Sec, H=Trk)

    ; 4. Create FEB content in memory
    ; Clear the buffer first
    LD   HL, SCRATCH_BUFFER1
    LD   BC, 128
    CALL k_mem_clear

    ; Copy filename into SCRATCH_BUFFER1 (Bytes 0-14)
    LD   DE, SCRATCH_BUFFER1
    LD   HL, (SCRATCH1)
    LD   B, 15                  ; Max length
.create_copy_name:
    LD   A, (HL)
    OR   A
    JR   Z, .create_write_feb   ; Null terminator reached
    LD   (DE), A
    INC  HL
    INC  DE
    DJNZ .create_copy_name

.create_write_feb:
    ; 5. Write the new FEB to disk
    POP  HL                     ; Restore New FEB Location (L=Sec, H=Trk)
    PUSH HL                     ; Save it again (need it for Superblock update)
    LD   DE, SCRATCH_BUFFER1
    CALL k_disk_write
    
    ; Check write success (A=0) usually, but k_disk_write returns 0 hardcoded currently.

    ; 6. Update Superblock in RAM
    ; We need to append the new pointer to the list.
    ; Address = SUPERBLOCK + 2 + (FileCount * 2)
    LD   A, (SUPERBLOCK+1)      ; Load File Count
    LD   C, A
    LD   B, 0
    
    LD   HL, SUPERBLOCK+2
    ADD  HL, BC
    ADD  HL, BC                 ; HL now points to the free slot
    
    POP  DE                     ; Restore New FEB Location (D=Track?? No, stack was HL)
                                ; Wait: PUSH HL pushed H then L. POP DE pops E=L, D=H.
                                ; So E = Sector, D = Track.
    
    LD   (HL), E                ; Store Sector
    INC  HL
    LD   (HL), D                ; Store Track

    ; Increment File Count
    LD   HL, SUPERBLOCK+1
    INC  (HL)

    ; 7. Save Superblock to Disk
    ; Superblock is at Track 0, Sector 2
    LD   L, 2
    LD   H, 0
    LD   DE, SUPERBLOCK
    CALL k_disk_write

    ; Success
    XOR  A
    JP   SYSCALL_RETURN

.create_err_exists:
    POP  HL                     ; Clean Stack (SB Pointer)
    POP  BC                     ; Clean Stack (Loop Counter)
    LD   A, $01
    JP   SYSCALL_RETURN

.create_err_dir_full:
	LD   A, $02
    JP   SYSCALL_RETURN
    
.create_err_disk_full:
	LD   A, $03
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_DELETE
; Deletes a file and frees all associated blocks (FEB, IEBs, Data).
; Input:  DE = Pointer to filename (Null-terminated)
; Output: A  = 0 (Success), 1 (File Open), FF (Not Found / Fail)
; ------------------------------------------------------------------
SYS_FS_DELETE:
    ; 0. Check if file is open
    LD   A, (OPEN_FILE_FLAG)
    DEC  A
	OR   A
    JR   Z, .del_file_open
	
	LD   (SCRATCH1), DE         ; Save filename pointer

    ; 1. Find the file in the Superblock
    LD   A, (SUPERBLOCK+1)      ; Get file count
    LD   B, A                   ; B = Loop Counter
    OR   A
    JP   Z, .del_not_found      ; No files to delete

    LD   HL, SUPERBLOCK+2       ; Start of pointers
    
    ; We need to track our index to compact the array later
.del_find_loop:
    PUSH BC                     ; Save Loop Counter
    PUSH HL                     ; Save Current Pointer Address

    ; Read FEB to check filename
    LD   E, (HL)                ; Sector
    INC  HL
    LD   D, (HL)                ; Track

    PUSH DE                     ; Save FEB Location (Sec/Trk) for later
    
    LD   L, E
    LD   H, D
    LD   DE, FEB01              ; Load into FEB01 (Safe if we are deleting)
    CALL k_disk_read

    ; Compare Filename
    LD   HL, FEB01              ; Filename in FEB
    LD   DE, (SCRATCH1)         ; Target Filename
    CALL k_compare_strings
    JR   Z, .del_found_it       ; Match!

    POP  DE                     ; Discard Saved FEB Location
    POP  HL                     ; Restore Pointer Address
    INC  HL
    INC  HL                     ; Advance to next entry (2 bytes)
    POP  BC                     ; Restore Loop
    DJNZ .del_find_loop

.del_not_found:
    LD   A, $FF
    JP   SYSCALL_RETURN

.del_file_open:
	LD   A, $01
	JP   SYSCALL_RETURN

.del_found_it:
    ; Stack currently has: [Saved FEB Location], [Pointer Address], [Loop Counter]
    
    ; 2. Free all Data Blocks and IEBs
    ; The FEB is currently loaded in FEB01.
    CALL .del_free_chain        ; Helper to walk FEB and free blocks
    
    ; 3. Free the FEB itself
    POP  HL                     ; Restore FEB Location (L=Sec, H=Trk)
    CALL k_fs_free_block        ; Mark FEB sector as free in Map

    ; 4. Remove from Superblock (Compact the list)
    ; We need to shift all subsequent pointers UP by 2 bytes.
    POP  HL                     ; Restore Address of the pointer we just deleted
    POP  BC                     ; Recover Loop Counter (Files remaining after this one)
    
    DEC  B                      ; Adjust B. If B was 1, it was the last file.
    LD   A, B
    OR   A
    JR   Z, .del_update_count   ; Last file? No shift needed.

    LD   D, H
    LD   E, L                   ; DE = Destination (Current Slot)
    INC  HL
    INC  HL                     ; HL = Source (Next Slot)

.del_compact_loop:
    ; Move 2 bytes (Pointer)
    LD   A, (HL)
    LD   (DE), A
    INC  HL
    INC  DE
    LD   A, (HL)
    LD   (DE), A
    INC  HL
    INC  DE
    DJNZ .del_compact_loop

.del_update_count:
    ; Decrement File Count in RAM
    LD   HL, SUPERBLOCK+1
    DEC  (HL)

    ; Save Superblock to Disk
    LD   L, 2
    LD   H, 0
    LD   DE, SUPERBLOCK
    CALL k_disk_write
    
    ; Save Disk Map to Disk (Critical to prevent lost space)
    CALL k_fs_save_map

    XOR  A                      ; Success
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; Helper: .del_free_chain
; Scans FEB01 (loaded in RAM) and frees all IEBs and Data Blocks.
; Clobbers: A, BC, DE, HL, IX
; ------------------------------------------------------------------
.del_free_chain:
    LD   IX, FEB01 + 21         ; Start of IEB pointers in FEB
    LD   B, 53                  ; Max IEBs in FEB

.df_feb_loop:
    ; Read IEB Pointer from FEB
    LD   L, (IX+0)              ; Sector
    LD   H, (IX+1)              ; Track
    
    LD   A, L
    OR   H
    JR   Z, .df_next_feb_ptr    ; Skip if empty pointer (0000)

    ; We have a valid IEB at HL.
    PUSH HL                     ; Save IEB Location
    PUSH BC                     ; Save FEB Loop Counter

    ; Read IEB into IEB_BUFFER
    LD   DE, IEB_BUFFER
    CALL k_disk_read

    ; Scan IEB for Data Blocks
    LD   IY, IEB_BUFFER
    LD   B, 64                  ; 64 pointers per IEB

.df_ieb_loop:
    LD   L, (IY+0)
    LD   H, (IY+1)
    LD   A, L
    OR   H
    JR   Z, .df_next_data_ptr

    ; Free Data Block
    PUSH BC
    CALL k_fs_free_block        ; Free data sector HL
    POP  BC

.df_next_data_ptr:
    INC  IY
    INC  IY
    DJNZ .df_ieb_loop

    ; Now Free the IEB itself
    POP  BC                     ; Restore FEB Loop
    POP  HL                     ; Restore IEB Location
    PUSH BC
    CALL k_fs_free_block        ; Free IEB sector
    POP  BC

.df_next_feb_ptr:
    INC  IX
    INC  IX
    DEC  B
    JR   NZ, .df_feb_loop
    RET

; ------------------------------------------------------------------
; SYS_FS_RENAME
; Renames an existing file.
; Input:  DE = Pointer to New Filename
;         HL = Pointer to Old Filename
; Output: A  = 0  (Success), 
;         A  = 1  (Fail: New name already taken)
;         A  = 2  (Fail: Old file not found)
;         A  = 3  (Fail: Can't rename open file)
;         A  = FF (Fail: Empty directory)
; ------------------------------------------------------------------
SYS_FS_RENAME:
    ; 0. Check if file is open
    LD   A, (OPEN_FILE_FLAG)
    DEC  A
	OR   A
    JP   Z, .ren_err_file_open
	
	LD   (SCRATCH1), DE         ; Save New Filename Pointer
    LD   (SCRATCH2), HL         ; Save Old Filename Pointer
    
    ; 1. Check if NEW Filename already exists
    ; We must scan all files to ensure uniqueness.
    LD   A, (SUPERBLOCK+1)      ; Get file count
    LD   B, A                   ; Loop Counter
    OR   A
    JP   Z, .ren_err           ; No files at all? Then Old file definitely doesn't exist.

    LD   HL, SUPERBLOCK+2       ; Start of pointers
.ren_check_new_loop:
    PUSH BC
    PUSH HL

    ; Read FEB
    LD   E, (HL)                ; Sector
    INC  HL
    LD   D, (HL)                ; Track
    
    LD   L, E
    LD   H, D
    LD   DE, SCRATCH_BUFFER1     ; Read into scratch buffer (don't disturb FEB01 yet)
    CALL k_disk_read

    ; Compare with NEW Filename
    LD   HL, SCRATCH_BUFFER1     ; Filename in FEB
    LD   DE, (SCRATCH1)         ; New Filename
    CALL k_compare_strings
    JR   Z, .ren_err_file_exists    ; Error: New name already taken

    POP  HL
    INC  HL
    INC  HL
    POP  BC
    DJNZ .ren_check_new_loop

    ; 2. Find the OLD File
    ; We restart the loop to find the file we want to rename.
    LD   A, (SUPERBLOCK+1)
    LD   B, A
    LD   HL, SUPERBLOCK+2
    
.ren_find_old_loop:
    PUSH BC
    PUSH HL                     ; Save Superblock Pointer

    ; Read FEB
    LD   E, (HL)
    INC  HL
    LD   D, (HL)
    
    PUSH DE                     ; Save FEB Location (Sec/Trk)
    
    LD   L, E
    LD   H, D
    LD   DE, SCRATCH_BUFFER1    ; Load into Scratch buffer1 (We will modify this)
    CALL k_disk_read

    ; Compare with OLD Filename
    LD   HL, SCRATCH_BUFFER1    ; Filename in Scratch buffer1
    LD   DE, (SCRATCH2)         ; Old Filename (from scratch)
    CALL k_compare_strings
    JR   Z, .ren_perform_rename ; Found it!

    POP  DE                     ; Discard FEB Location
    POP  HL                     ; Restore Superblock Pointer
    INC  HL
    INC  HL
    POP  BC
    DJNZ .ren_find_old_loop

    ; If we fall through, Old file was not found.
    JP   .ren_err_not_found

.ren_perform_rename:
    ; Stack has: [FEB Location (Sec/Trk)], [Superblock Pointer], [Loop Counter]
    ; We have the correct FEB in FEB01.
    
    ; 3. Update Filename in FEB01
    ; First, clear the name field (first 15 bytes) to 0 to be clean
    PUSH HL                     ; Save registers before call
    PUSH DE
    PUSH BC
    LD   HL, SCRATCH_BUFFER1
    LD   BC, 15
    CALL k_mem_clear
    POP  BC
    POP  DE
    POP  HL

    LD   DE, SCRATCH_BUFFER1    ; Dest: Start of Scratch buffer1
    LD   HL, (SCRATCH1)         ; Src: New Filename
    LD   B, 15                  ; Max Length

.ren_copy_name:
    LD   A, (HL)
    OR   A
    JR   Z, .ren_write_back
    LD   (DE), A
    INC  HL
    INC  DE
    DJNZ .ren_copy_name

.ren_write_back:
    ; 4. Write modified SCRATCH_BUFFER1 back to disk
    ; We need the Sector/Track. It's on the stack.
    ; Stack order: [FEB Location], [SB Ptr], [Loop Cnt]
    POP  DE                     ; Get FEB Location (D=Track, E=Sector)
    
    LD   L, E
    LD   H, D                   ; L=Sec, H=Trk
    LD   DE, SCRATCH_BUFFER1
    CALL k_disk_write
    
    ; Cleanup Stack
    POP  HL                     ; SB Ptr
    POP  BC                     ; Loop Cnt

    XOR  A                      ; Success
    JP   SYSCALL_RETURN

.ren_err_file_exists:
    POP  HL                     ; Clean Stack (SB Ptr)
    POP  BC                     ; Clean Stack (Loop Cnt)
	LD   A, $01
	JP   SYSCALL_RETURN
.ren_err_not_found:
	LD   A, $02
    JP   SYSCALL_RETURN
.ren_err_file_open:
	LD   A, $03
    JP   SYSCALL_RETURN
.ren_err:
    LD   A, $FF
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_TELL
; Input:  DE = Pointer to a 4-byte buffer (to be filled with file size)
; Output: A  = 0 (Success), FF (Fail/No file open)
; ------------------------------------------------------------------
SYS_FS_TELL:
    ; 1. Check if a file is open
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JR   Z, .tell_err

    ; 2. Return the 32-bit cursor value (DE = Lower 16, HL = Upper 16)
    LD   HL, FILE_CURSOR_BYTE   ; Source: File cursor
    LD   BC, 4                  ; 4 bytes
    LDIR                        ; Memory copy from HL to DE
    
    XOR  A                      ; A = 0 (Success)
    JP   SYSCALL_RETURN

.tell_err:
    LD   HL, 0
    LD   DE, 0
    LD   A, $FF                 ; A = FF (Error)
    JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_FILE_SIZE
; Input:  DE = Pointer to a 4-byte buffer (to be filled with file size)
; Output: A  = 0 (Success), FF (Fail/No file open)
; ------------------------------------------------------------------
SYS_FS_FILE_SIZE:
	; 1. Check if a file is open
    LD   A, (OPEN_FILE_FLAG)
    OR   A
    JR   Z, .file_size_err

	; 2. Copy the 32-bit file size directly to the user's buffer in DE
    LD   HL, FEB01 + 17         ; Source: File size in FEB
    LD   BC, 4                  ; 4 bytes
    LDIR                        ; Memory copy from HL to DE

	XOR  A                      ; A = 0 (Success)
    JP   SYSCALL_RETURN

.file_size_err:
	LD   HL, 0
    LD   DE, 0
    LD   A, $FF                 ; A = FF (Error)
	JP   SYSCALL_RETURN

; ------------------------------------------------------------------
; SYS_FS_DISK_REMAINING
; Computes how many bytes are remaining (free) on the floppy disk.
; Input:  DE = Pointer to a 4-byte buffer (to be filled with result)
; Output: A  = 0 (Success)
; ------------------------------------------------------------------
SYS_FS_DISK_REMAINING:
    LD   (SCRATCH1), DE     ; Save user buffer pointer

    ; 1. Count free sectors (0-bits in DISK_MAP)
    LD   IX, 0              ; Initialize free sector counter to 0
    LD   HL, DISK_MAP       ; Start of bitmap buffer
    LD   BC, 2002           ; Total valid sectors on disk (77 tracks * 26 sectors)

.count_byte_loop:
    LD   A, (HL)            ; Read current map byte
    LD   D, 8               ; 8 bits to check in this byte

.count_bit_loop:
    RRC  A                  ; Rotate bit 0 into Carry flag
    JR   C, .bit_used       ; If carry=1, sector is used

    INC  IX                 ; Sector is free (carry=0), increment counter

.bit_used:
    DEC  BC                 ; Decrement blocks remaining to check
    
    ; Manual Z-flag check for BC without clobbering HL
    LD   E, A               ; Save A temporarily
    LD   A, B
    OR   C
    JR   Z, .count_done     ; If BC == 0, we've checked all 2002 blocks
    LD   A, E               ; Restore A

    DEC  D                  ; Decrement bit counter
    JR   NZ, .count_bit_loop; Check next bit in the byte

    INC  HL                 ; Move to next byte in DISK_MAP
    JR   .count_byte_loop

.count_done:
    ; 2. Convert free sectors to bytes (Sectors * 128)
    ; Transfer free sector count from IX to HL
    PUSH IX
    POP  HL

    ; Calculate the 32-bit result (Bytes 0 to 3)
    ; Mathematical trick: HL * 128 is equal to (HL * 256) / 2
    LD   A, H
    SRL  A                  ; A = H >> 1, Carry = H & 1
    LD   D, A               ; Byte 2

    LD   A, L
    RR   A                  ; A = L >> 1 with carry from H. Carry = L & 1
    LD   E, A               ; Byte 1

    LD   A, 0
    RR   A                  ; A = 0 >> 1 with carry from L
    LD   C, A               ; Byte 0 (LSB)

    LD   B, 0               ; Byte 3 (MSB is always 0 for floppies maxing at 256KB)

    ; 3. Write 32-bit result to user's 4-byte buffer (Little-Endian)
    LD   HL, (SCRATCH1)     ; Restore buffer pointer
    LD   (HL), C            ; LSB (Byte 0)
    INC  HL
    LD   (HL), E            ; Byte 1
    INC  HL
    LD   (HL), D            ; Byte 2
    INC  HL
    LD   (HL), B            ; MSB (Byte 3)

    XOR  A                  ; Return 0 (Success)
    JP   SYSCALL_RETURN

; =====================================================================
; OS DATA SECTION
; =====================================================================

; SUPERBLOCK sector (info block: folder)
SUPERBLOCK:
		DS 128, 0

; FEB sector (File Entry Block)
FEB01:
		DS 128, 0

SCRATCH1:
		DW 0

SCRATCH2:
    	DW 0

FILE_POINTER:
		DW 0

OPEN_FILE_FLAG:
        DB 0                         ; 0 = no file open, 1 = file open

OPEN_FILE_SECTOR:
        DB 0                         ; Sector number of open file's FEB

OPEN_FILE_TRACK:
        DB 0                         ; Track number of open file's FEB

IEB_BUFFER:     					; Used to hold Indirect Entry Blocks
    DS 128, 0						

SCRATCH_BUFFER1:						; Used as temp buffer for some file syscalls
	DS 128, 0

; 32-bit Logical Byte Offset (Little-Endian: LSB, Byte 1, Byte 2, MSB)
FILE_CURSOR_BYTE:
    DS 4, 0

; Holds the allocation map in RAM (256 bytes)
; We load this from Track 0, Sectors 3 & 4 on boot.
DISK_MAP:
    DS 256, 0

; Byte-based SYS_FS_WRITE
SYS_FS_WRITE_OFFSET: DB 0
SYS_FS_WRITE_CHUNK:  DB 0
DATA_BUFFER:         DS 128, 0    ; Crucial 128-byte sector buffer for RMW

; Byte-based SYS_FS_READ
SYS_FS_READ_OFFSET:  DB 0
SYS_FS_READ_CHUNK:   DB 0

; =====================================================================
; kernel helpers (OS)
; =====================================================================

; L = Sector number, H = Track number
k_disk_read:
		LD A, L
		OUT ($12), A			; Select sector
		LD A, H
		OUT ($10), A			; Select track
		LD A, E
		OUT ($13), A			; Select DMA low
		LD A, D
		OUT ($14), A			; Select DMA high
		LD A, $01
		OUT ($15),A				; Execute READ
		LD A, $00				; Success
		RET

k_disk_write:
		LD A, L
		OUT ($12), A			; Select sector
		LD A, H
		OUT ($10), A			; Select track
		LD A, E
		OUT ($13), A			; Select DMA low
		LD A, D
		OUT ($14), A			; Select DMA high
		LD A, $02
		OUT ($15),A				; Execute WRITE
		LD A, $00				; Success
		RET

k_newline:
		LD A, $0D
		OUT ($01), A
		
		LD A, $0A
		OUT ($01), A

		RET

k_puts:
		LD   HL, DE

.puts_loop:
        LD   A, (HL)
        OR   A
        JR   Z, .done

        OUT  ($01), A
        INC  HL
        JR   .puts_loop

.done:
        XOR  A
		RET

; Load the Superblock from disk into RAM
k_init_disk:
		LD C, 16
		LD DE, SUPERBLOCK
		LD L, 2				; Sector number
		LD H, 0				; Track number
		CALL k_disk_read	; Read from disk

		RET

; ------------------------------------------------------------------
; k_compare_strings
; input:  HL = pointer to string 1.
;         DE = pointer to string 2.
; output: Z flag set if identical, reset if different.
;         A contains the difference (0 if identical).
; clobbers: C
; ------------------------------------------------------------------
k_compare_strings:
		LD A, (HL)
		LD C, A
		LD A, (DE)
		
		; Compare character from String 1 (C) with String 2 (A)
		CP C
		RET NZ							; If they differ, return immediately (NZ set)

		; If they are the same, check if we've reached the end of the string
    	; Since A == C, we only need to check if A is 0.
		OR A
		RET Z							; If A is 0, both strings ended simultaneously (Z set)

		; Neither string has ended and current chars match; move to next
		INC HL
		INC DE
		JR k_compare_strings

; ------------------------------------------------------------------
; k_fs_allocate_block
; Scans the DISK_MAP for a free bit (0).
; Marks it as used (1) and returns the physical disk address.
;
; Output:
;   L = Sector (1-26)
;   H = Track (0-76)
;   A = 0 (Success), $FF (Disk Full)
;
; Clobbers: AF, BC, DE, HL
; ------------------------------------------------------------------
k_fs_allocate_block:
    LD   HL, DISK_MAP       ; Start of map buffer
    LD   B, 0               ; Byte Counter (0 to 255)

; ---------------------------------------------------------------
; Phase 1 – Find a free byte, then a free bit within it
; ---------------------------------------------------------------
.find_free_byte:
    LD   A, (HL)
    CP   $FF                ; Is this byte fully used?
    JR   NZ, .find_free_bit ; At least one 0-bit in here

    INC  HL                 ; Next byte
    INC  B                  ; Increment byte counter
    JR   NZ, .find_free_byte ; Loop: B wraps to 0 after 256 iterations

    ; Entire 256-byte map is $FF — disk logically full
    LD   A, $FF
    RET

.find_free_bit:
    ; A = map byte (has at least one 0-bit)
    ; B = Byte Index (0-255)
    ; HL = address of that byte in DISK_MAP
    LD   C, 0               ; Bit Counter (0-7)

.bit_scan_loop:
    RRC  A                  ; Rotate bit 0 into Carry
    JR   NC, .found_bit     ; Carry = 0 means this bit is free
    INC  C
    JR   .bit_scan_loop     ; We know there is a 0, so no bounds check needed

; ---------------------------------------------------------------
; Phase 2 – Bounds check BEFORE touching the bitmap          (FIX 1)
;
; The DISK_MAP is 256 bytes = 2048 bits, but the physical disk
; only has 77 tracks × 26 sectors = 2002 valid blocks (indices
; 0-2001). Bits 2002-2047 are phantom: mapping them would
; produce an invalid track/sector and corrupt the bitmap.
;
; Original code marked the bit first, then checked the track.
; If the block was phantom, it returned $FF but the bit was
; already set in RAM — silently consuming phantom bits one by
; one across successive calls.
;
; Fix: compute Global Index and validate it BEFORE any write.
; ---------------------------------------------------------------
.found_bit:
    ; B = Byte Index (0-255), C = Bit Index (0-7)

    ; --- Compute Global Index = (Byte_Index * 8) + Bit_Index ---
    LD   H, 0
    LD   L, B               ; HL = Byte Index
    ADD  HL, HL
    ADD  HL, HL
    ADD  HL, HL             ; HL = Byte * 8
    LD   D, 0
    LD   E, C
    ADD  HL, DE             ; HL = Global Bit Index

    ; --- Bounds check: Global Index must be < 2002 (77 * 26) ---
    PUSH HL                 ; Save Global Index across comparison
    LD   DE, 2002
    OR   A                  ; Clear carry
    SBC  HL, DE             ; HL = Global - 2002
    POP  HL                 ; Restore Global Index
    JR   NC, .err_disk_full ; If Global >= 2002: no valid physical block exists.
                            ; Bitmap is untouched — no corruption.

; ---------------------------------------------------------------
; Phase 3 – Mark the bit as USED in the RAM bitmap
;           (Only reached when the block is proven valid)
; ---------------------------------------------------------------
    PUSH HL                 ; [1] Save Global Index
    PUSH BC                 ; [2] Save Byte/Bit indices

    ; Recompute address of the map byte: DISK_MAP + Byte_Index
    LD   H, 0
    LD   L, B               ; HL = Byte Index
    LD   DE, DISK_MAP
    ADD  HL, DE             ; HL = &DISK_MAP[B]

    ; Build a mask with bit C set: A = 1 << C
    LD   A, 1
    INC  C                  ; Loop trick so DEC C hits 0 on the first check when C was 0
.shift_mask:
    DEC  C
    JR   Z, .mask_ready
    SLA  A
    JR   .shift_mask
.mask_ready:
    OR   (HL)               ; Set the bit in the byte
    LD   (HL), A            ; Write back to DISK_MAP

    POP  BC                 ; [2] Restore Byte(B) and Bit(C) indices
    POP  HL                 ; [1] Restore Global Index

; ---------------------------------------------------------------
; Phase 4 – Convert Global Index to Track / Sector
;
; Track  = Global / 26   (quotient)
; Sector = Global % 26 + 1   (remainder, made 1-based)
;
; Bounds-check above guarantees Global <= 2001, so Track <= 76.
; The original CP 77 guard is therefore redundant and removed.
;
; FIX 2: The original loop used AND A inside every iteration to
; clear the carry flag before SBC HL, BC.  Carry is already 0
; after any non-underflowing SBC, so AND A was only needed once,
; before the first iteration.  Moved outside the loop.
; ---------------------------------------------------------------
    LD   E, 0               ; E = Track counter (quotient)
    LD   BC, 26             ; Divisor

    OR   A                  ; Clear carry once, before the loop
.div_loop:
    SBC  HL, BC             ; HL -= 26
    JR   C, .div_underflow  ; Went negative: quotient and remainder are final
    INC  E                  ; Count another full track
    JR   .div_loop          ; Carry is already 0 — no need to reset it

.div_underflow:
    ADD  HL, BC             ; Restore true remainder (0..25)

    ; E = Track (0-76), L = Sector-1 (0-25)
    LD   A, L
    INC  A                  ; Make Sector 1-based (1-26)

    LD   L, A               ; L = Sector
    LD   H, E               ; H = Track

; ---------------------------------------------------------------
; Phase 5 – Persist the modified bitmap to disk
; ---------------------------------------------------------------
    PUSH HL                 ; Save return value (L=Sector, H=Track)
    CALL k_fs_save_map
    POP  HL                 ; Restore return value

    XOR  A                  ; A = 0 (Success)
    RET

.err_disk_full:
    LD   A, $FF             ; A = $FF (Disk Full)
    RET                     ; Bitmap is clean — no phantom bits set

; ------------------------------------------------------------------
; k_fs_save_map
; Writes the 256-byte DISK_MAP buffer to Track 0, Sectors 3 & 4
; ------------------------------------------------------------------
k_fs_save_map:
    ; Write First Half (Bytes 0-127) to Sector 3
    LD   L, 3               ; Sector 3
    LD   H, 0               ; Track 0
    LD   DE, DISK_MAP
    CALL k_disk_write

    ; Write Second Half (Bytes 128-255) to Sector 4
    LD   L, 4               ; Sector 4
    LD   H, 0               ; Track 0
    LD   DE, DISK_MAP + 128
    CALL k_disk_write

    RET

; ------------------------------------------------------------------
; k_fs_load_map
; Reads Track 0, Sectors 3 & 4 into DISK_MAP
; ------------------------------------------------------------------
k_fs_load_map:
    ; Read Sector 3
    LD   L, 3
    LD   H, 0
    LD   DE, DISK_MAP
    CALL k_disk_read

    ; Read Sector 4
    LD   L, 4
    LD   H, 0
    LD   DE, DISK_MAP + 128
    CALL k_disk_read
    RET

; Mark System Sectors as Used
; We have 4 reserved sectors: Boot, Super, Map1, Map2.
k_fs_format_init:
    ; 1. Clear Map Buffer
    LD   HL, DISK_MAP
    LD   BC, 256
    CALL k_mem_clear      ; (Fill with 0)

    ; 2. Mark System Sectors as Used
    ; We have 4 reserved sectors: Boot, Super, Map1, Map2.
    ; This corresponds to Bits 0, 1, 2, 3.
    ; So Byte 0 should be binary 00001111 -> $0F.
    ; (Assuming Bit 0 = Sector 1)
    
    LD   A, $0F
    LD   (DISK_MAP), A

    ; 3. Save
    CALL k_fs_save_map
    RET

; ------------------------------------------------------------------
; k_mem_clear
; Clears a block of memory to 0.
; Input:  HL = Start Address
;         BC = Length (in bytes)
; Returns: HL = End Address + 1
;          BC = 0
; Clobbers: AF, BC, HL
; ------------------------------------------------------------------
k_mem_clear:
    ; 1. Safety Check: If BC is 0, exit immediately
    LD   A, B
    OR   C
    RET  Z              ; Return if BC == 0

.clear_loop:
    LD   (HL), 0        ; Set current byte to zero
    INC  HL             ; Move to next memory location
    DEC  BC             ; Decrement counter

    ; 2. Check if we are done
    LD   A, B
    OR   C
    JR   NZ, .clear_loop ; If BC is not 0, keep clearing
    RET

; ------------------------------------------------------------------
; k_fs_free_block
; Marks the block at L=Sector, H=Track as FREE (0) in DISK_MAP.
; Input: L=Sector (1-26), H=Track (0-76)
; ------------------------------------------------------------------
k_fs_free_block:
    PUSH AF
    PUSH BC
    PUSH DE
    PUSH HL                     ; Save original Sec/Trk for the caller

    ; 1. Calculate Global Bit Index = (Track * 26) + (Sector - 1)
    LD   E, L                   ; E = Sector
    LD   L, H                   ; L = Track
    LD   H, 0
    
    ; HL = Track. Calculate HL * 26.
    LD   B, L
    LD   C, 26

	PUSH DE						; Save E (Sector) before multiply
    CALL .mul_8bit              ; Helper: HL = B * C
	POP  DE
    
    LD   A, E                   ; Sector
    DEC  A                      ; Make 0-based
    LD   E, A
    LD   D, 0
    ADD  HL, DE                 ; HL = Global Bit Index

	; --- PHANTOM BIT FIX: Bounds Check ---
    ; Ensure Global Index < 2002 (77 * 26)
    LD   DE, 2002
    PUSH HL                     ; Save Global Index for later
    OR   A                      ; Clear carry
    SBC  HL, DE                 ; HL = Index - 2002
    POP  HL                     ; Restore Global Index
    JR   NC, .invalid_block     ; If Index >= 2002, do nothing (abort)
    ; -------------------------------------
    
    ; 2. Separate into Byte Index and Bit Index
    ; Byte Index = Global / 8
    ; Bit Index  = Global % 8
    
    LD   A, L
    AND  7                      ; A = Bit Index (Remainder)
    PUSH AF                     ; Save Bit Index
    
    ; Divide Global Index by 8 to get Byte Index
	SRL  H
    RR   L
    SRL  H
    RR   L
    SRL  H
    RR   L                      ; HL = Byte Index
    
    ; 3. Clear the Bit in DISK_MAP
    LD   DE, DISK_MAP
    ADD  HL, DE                 ; HL = Address of Byte in Map
    
    POP  AF                     ; Restore Bit Index (in A)
    LD   B, A                   ; B = Bit Index
    
    ; Create AND Mask (Inverse of OR mask). E.g., Bit 2 -> 11111011
    LD   A, 1
    INC  B
.shift_bit_free:
    DEC  B
    JR   Z, .bit_ready_free
    SLA  A
    JR   .shift_bit_free
.bit_ready_free:
    CPL                         ; Invert bits to create AND mask (e.g., 11111011)
    
    AND  (HL)                   ; Clear only the target bit
    LD   (HL), A                ; Store updated byte back to DISK_MAP
    
.invalid_block:
    POP  HL                     ; Restore original Sec/Trk
    POP  DE
    POP  BC
    POP  AF
    RET

; Helper: Simple Multiply HL = B * C
.mul_8bit:
    LD   HL, 0
    LD   A, B
    OR   A
    RET  Z
    
    ; Separate the multiplicand (C) from the counter (B)
    LD   D, 0
    LD   E, C       ; DE now safely holds the value to add
    
.mul_loop:
    ADD  HL, DE     ; Add DE instead of BC
    DEC  B
    JR   NZ, .mul_loop
    RET

; -----------------------------------------------------------
; k_gets
; Inputs:  DE = Pointer to buffer (Preserved)
;          B  = Buffer size (including null terminator)
; Modifies: AF, BC, HL (DE is saved and restored)
; -----------------------------------------------------------
k_gets:
        PUSH    DE              ; Preserve original DE for caller
        LD      H, D            ; HL = working pointer
        LD      L, E
        
        LD      C, 0            ; C = current length counter
        DEC     B               ; Room for null terminator

.input_loop:
        ; 1. Get character
        CALL    k_getchar       ; Character returned in A
        
        ; 2. Check for termination (CR or LF)
        CP      13              ; Carriage Return
        JR      Z, .terminate
        CP      10              ; Line Feed
        JR      Z, .terminate

		; Check for backspace
		CP      8
		JR      Z, .backspace

        ; 3. Check Buffer Limit
        LD      D, A
		LD      A, C
        CP      B               ; Is buffer full?
		LD      A, D
        JR      NC, .input_loop ; If full, ignore and loop (don't echo/store)       
        
        LD      (HL), A         ; Store char in buffer
        INC     HL              ; Advance pointer
        INC     C               ; Increment count
        
        LD      E, A            ; Move to E for echo
        CALL    k_putchar
        JR      .input_loop

.backspace:
        LD      A, C            ; Check current length
        OR      A
        JR      Z, .input_loop  ; If length is zero, ignore backspace

        DEC     C               ; Decrement length counter
        DEC     HL              ; Move pointer back to last character
        
		; Optionally erase character on screen
        LD      E, 8            ; Backspace
        CALL    k_putchar
        LD      E, ' '          ; Space to overwrite
        CALL    k_putchar
        LD      E, 8            ; Backspace again
        CALL    k_putchar

        JR      .input_loop     ; Go back to get next character

.terminate:
        LD      (HL), 0         ; Null-terminate string
        
        ; Optional: Echo Newline to clean up terminal state
        CALL    k_newline

        POP     DE              ; Restore DE to original state
        RET

k_putchar:
		LD   A, E			; Input char in E
		OUT  ($01), A
    	XOR  A             ; A = 0 (OK)
		RET

k_getchar:
.wait:
        IN   A, ($01)		; A will be filled with non-NULL char
        OR   A
        JR   Z, .wait
		RET

; Input: Drive number in B
k_disk_select:
		LD   A, B
		OUT  ($17), A
		XOR  A
		RET

; Input: Drive number in B
k_disk_ready:
        IN   A, ($16)       ; Read disk status from port 0x16
        
        ; We need to check the bit corresponding to the drive number in B
        ; (e.g., if B=0, check bit 0; if B=1, check bit 1)
        LD   C, A           ; Store the status in C temporarily
        LD   A, B           ; Load drive number to A to check if it's 0
        OR   A              ; Is drive number 0?
        JR   Z, .check_bit  ; If so, no shifting needed
        
.shift_loop:
        RRC  C              ; Rotate right to bring target drive bit to position 0
        DJNZ .shift_loop    ; Decrement B and loop until B is 0
        
.check_bit:
        LD   A, C           ; Bring the shifted status back to A
        AND  $01            ; Isolate bit 0
        JR   NZ, .not_ready ; If bit is 1, the drive is NOT ready (active low)
        
        XOR  A              ; Drive is ready: Set A = 0
        RET

.not_ready:
        LD   A, $FF         ; Drive is not ready: Set A = 0xFF
        RET

; Sends char in E to printer
k_print_char:
		LD   A, E
		OUT  ($02), A
		XOR  A
		RET

; ==================================================================
; 32-bit byte-based Filesystem helpers (previously was block-based)
; ==================================================================

; ------------------------------------------------------------------
; k_add32_mem
; Adds a 32-bit value to a 32-bit variable in memory.
; Input:  HL = Pointer to 32-bit variable (e.g., FILE_CURSOR_BYTE)
;         DE = High 16 bits to add
;         BC = Low 16 bits to add
; Modifies: A, HL
; ------------------------------------------------------------------
k_add32_mem:
    ; Add Low 16 bits (BC)
    LD   A, (HL)
    ADD  A, C
    LD   (HL), A
    INC  HL
    
    LD   A, (HL)
    ADC  A, B           ; Add with Carry
    LD   (HL), A
    INC  HL
    
    ; Add High 16 bits (DE)
    LD   A, (HL)
    ADC  A, E           ; Add with Carry
    LD   (HL), A
    INC  HL
    
    LD   A, (HL)
    ADC  A, D           ; Add with Carry
    LD   (HL), A
    
    ; Reset HL back to the start of the 32-bit variable
    DEC  HL
    DEC  HL
    DEC  HL
    RET

; ------------------------------------------------------------------
; k_cmp32_mem
; Compares a 32-bit memory variable with DE:BC.
; Input:  HL = Pointer to 32-bit variable in memory
;         DE = High 16 bits to compare against
;         BC = Low 16 bits to compare against
; Output: Z flag set if (HL) == DE:BC
;         C flag set if (HL) < DE:BC
; Modifies: A
; ------------------------------------------------------------------
k_cmp32_mem:
    PUSH HL
    INC  HL 
    INC  HL 
    INC  HL             ; Point to MSB (Byte 3)
    
    LD   A, (HL)
    CP   D
    JR   NZ, .cmp_done
    DEC  HL
    
    LD   A, (HL)
    CP   E
    JR   NZ, .cmp_done
    DEC  HL
    
    LD   A, (HL)
    CP   B
    JR   NZ, .cmp_done
    DEC  HL
    
    LD   A, (HL)
    CP   C              ; LSB (Byte 0)

.cmp_done:
    POP  HL             ; Restore original pointer
    RET

; ------------------------------------------------------------------
; k_div128_32bit
; Divides a 32-bit value by 128 (Logical Shift Right 7 times).
; Input:  DE = High 16 bits, HL = Low 16 bits
; Output: DE:HL = Block Index (Quotient)
; Modifies: A, B, DE, HL
; ------------------------------------------------------------------
k_div128_32bit:
    LD   B, 7           ; Shift 7 times
.shift_loop:
    SRL  D              ; Shift Right Logical MSB, bit 0 goes into Carry
    RR   E              ; Rotate Right through Carry
    RR   H
    RR   L              ; Lowest bit drops out
    DJNZ .shift_loop
    RET

; ------------------------------------------------------------------
; k_load32_dehl
; Helper to quickly load a 32-bit memory variable into DE:HL
; Input:  HL = Pointer to 32-bit variable
; Output: DE = High 16 bits, HL = Low 16 bits
; Modifies: A, DE, HL
; ------------------------------------------------------------------
k_load32_dehl:
    LD   E, (HL)        ; LSB
    INC  HL
    LD   D, (HL)
    INC  HL
    LD   A, (HL)        ; Store Byte 2 in A temporarily
    INC  HL
    LD   H, (HL)        ; MSB into H
    LD   L, A           ; Byte 2 into L
    EX   DE, HL         ; Swap so DE has High word, HL has Low word
    RET
