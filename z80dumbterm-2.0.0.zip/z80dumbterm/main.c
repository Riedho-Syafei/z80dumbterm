#include <SDL3/SDL.h>
#include "z80.h"
#include "memory.h"
#include "terminal.h"
#include "keyboard.h"
#include "disk.h"
#include "cpm_hexdump.h"
#include "printer.h"
#include "speaker.h"
#include <string.h>
#include <stdio.h>
#include "graphics.h"

SDL_Window* window;
SDL_Renderer* renderer;
FILE* logfile;

static uint8_t translate_key(SDL_Keycode key, bool shift, bool caps)
{
    // Letters
    if (key >= SDLK_A && key <= SDLK_Z) {
        // Shift and Caps Lock reverse each other for alphabetical characters
        bool is_upper = shift ^ caps;
        return is_upper ? ('A' + (key - SDLK_A))
                        : ('a' + (key - SDLK_A));
    }

    // Numbers + shifted symbols (Caps Lock does not affect these)
    if (key >= SDLK_0 && key <= SDLK_9) {
        if (!shift)
            return '0' + (key - SDLK_0);

        static const char shifted_nums[] = {
            ')', '!', '@', '#', '$', '%', '^', '&', '*', '('
        };
        return shifted_nums[key - SDLK_0];
    }

    // Punctuation
    switch (key) {
        case SDLK_MINUS:        return shift ? '_' : '-';
        case SDLK_EQUALS:       return shift ? '+' : '=';
        case SDLK_LEFTBRACKET:  return shift ? '{' : '[';
        case SDLK_RIGHTBRACKET: return shift ? '}' : ']';
        case SDLK_BACKSLASH:    return shift ? '|' : '\\';
        case SDLK_SEMICOLON:    return shift ? ':' : ';';
        case SDLK_APOSTROPHE:   return shift ? '"' : '\'';
        case SDLK_COMMA:        return shift ? '<' : ',';
        case SDLK_PERIOD:       return shift ? '>' : '.';
        case SDLK_SLASH:        return shift ? '?' : '/';
        case SDLK_GRAVE:        return shift ? '~' : '`';

        case SDLK_SPACE:        return ' ';
        case SDLK_TAB:          return '\t';
        case SDLK_RETURN:       return '\n';
        case SDLK_BACKSPACE:    return '\b';
        case SDLK_ESCAPE:       return 27;
    }

    return 0;
}



int main(void) {
    Z80 cpu;
	memset(memory, 0, 65536);

    // Initialize the Z80 clock (3.5 MHz standard Z80)
    z80_init_clock(&cpu, Z80_CLOCK_FREQ_HZ);

    // Reset CPU
    memset(&cpu, 0, sizeof(cpu));
    z80_reset(&cpu);  // Use the clock-aware reset

	
	cpu.sp = 0xFFF0;

	/* ================================================
		Load the disk files
	   ================================================ */
	disk_file_A = fopen("disk_a.img", "r+b");
	if (disk_file_A == NULL) {
    	printf("Error: Could not open disk_a.img\n");
    	exit(1);
	} else {
		printf("Disk loaded: disk_a.img\n");
	}

	disk_file_B = fopen("disk_b.img", "r+b");
	if (disk_file_B == NULL) {
    	printf("Warning: Could not open disk_b.img\n");
	} else {
		printf("Disk loaded: disk_b.img\n");
	}

	disk_file_C = fopen("disk_c.img", "r+b");
	if (disk_file_C == NULL) {
    	printf("Warning: Could not open disk_c.img\n");
	} else {
		printf("Disk loaded: disk_c.img\n");
	}

	disk_file_D = fopen("disk_d.img", "r+b");
	if (disk_file_D == NULL) {
    	printf("Warning: Could not open disk_d.img\n");
	} else {
		printf("Disk loaded: disk_d.img\n");
	}

	logfile = fopen("CPULOG.txt", "w");

	printer_file = fopen("TTY_printer.txt", "w");
	
	//load_minimal_cpm(memory);
	
	load_cpm_binary("cpmlike.bin", memory);
	


    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

	// Audio Setup
    SDL_AudioSpec audio_spec;
    SDL_zero(audio_spec);
    audio_spec.freq = 44100;
    audio_spec.format = SDL_AUDIO_F32; // 32-bit float
    audio_spec.channels = 1;           // Mono

    // Create a push-based audio stream
    SDL_AudioStream* audio_stream = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &audio_spec, NULL, NULL);
    if (audio_stream) {
        SDL_ResumeAudioDevice(SDL_GetAudioStreamDevice(audio_stream));
    } else {
        printf("Warning: Failed to initialize audio: %s\n", SDL_GetError());
    }
    // ------------------------

    window = SDL_CreateWindow(
        "Z80 Terminal",
        TERM_COLS * CHAR_W * 2,
        TERM_ROWS * CHAR_H * 3,
        0
    );

	//SDL_StartTextInput(window);

    renderer = SDL_CreateRenderer(window, NULL);
	SDL_SetRenderLogicalPresentation(
    	renderer,
    	TERM_COLS * CHAR_W,
    	TERM_ROWS * CHAR_H,
    	SDL_LOGICAL_PRESENTATION_STRETCH
	);

	terminal_init();
	
	// In main.c, right after you create your SDL_Renderer:
    
    // Mode 1: 120x90 (24-bit)
    mode_textures[1] = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 120, 90);
    // Mode 2: 220x144 (8-bit)
    mode_textures[2] = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 220, 144);
    // Mode 3: 320x200 (4-bit)
    mode_textures[3] = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 320, 200);
    // Mode 4: 640x400 (1-bit)
    mode_textures[4] = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, 640, 400);


    bool running = true;

    while (running)
    {	
		SDL_Event e;
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_EVENT_QUIT)
                running = false;
			

			if (e.type == SDL_EVENT_KEY_DOWN) {

				// 1. Check if ANY Ctrl key is held
        		if (e.key.mod & SDL_KMOD_CTRL) {
            
            		// 2. Now identify which key was paired with Ctrl
            		switch (e.key.key) {
                		case SDLK_A:
							keyboard_push(1);
							break;
						case SDLK_B:
							keyboard_push(2);
							break;
						case SDLK_C:
                    		keyboard_push(3);
                    		break;
						case SDLK_D:
							keyboard_push(4);
							break;
						case SDLK_E:
							keyboard_push(5);
							break;
						case SDLK_F:
                    		keyboard_push(6);
                    		break;
						case SDLK_G:
							keyboard_push(7);
							break;
						case SDLK_H:
							keyboard_push(8);
							break;
						case SDLK_I:
                    		keyboard_push(9);
                    		break;
						case SDLK_J:
							keyboard_push(10);
							break;
						case SDLK_K:
							keyboard_push(11);
							break;
						case SDLK_L:
                    		keyboard_push(12);
                    		break;
						case SDLK_M:
							keyboard_push(13);
							break;
						case SDLK_N:
							keyboard_push(14);
							break;
						case SDLK_O:
                    		keyboard_push(15);
                    		break;
						case SDLK_P:
							keyboard_push(16);
							break;
						case SDLK_Q:
							keyboard_push(17);
							break;
						case SDLK_R:
                    		keyboard_push(18);
                    		break;
						case SDLK_S:
							keyboard_push(19);
							break;
						case SDLK_T:
							keyboard_push(20);
							break;
						case SDLK_U:
                    		keyboard_push(21);
                    		break;
						case SDLK_V:
							keyboard_push(22);
							break;
						case SDLK_W:
							keyboard_push(23);
							break;
						case SDLK_X:
                    		keyboard_push(24);
                    		break;
						case SDLK_Y:
							keyboard_push(25);
							break;
						case SDLK_Z:
							keyboard_push(26);
							break;
                		default:
                    		// This catches every other Ctrl + [Key] combo
                    		printf("Ctrl + Key (ID: %" PRIu32 ") pressed\n", e.key.key);
                    		break;
            		}
        		}
				else
				{
					
					bool shift = (e.key.mod & SDL_KMOD_SHIFT);
					bool caps = (e.key.mod & SDL_KMOD_CAPS) != 0; // Capture Caps Lock
    				uint8_t ch = translate_key(e.key.key, shift, caps);

    				if (ch != 0)
        				keyboard_push(ch);
				}
				
			}



        }

		/* Cycle-accurate emulation: run for one frame's worth of cycles */
        uint64_t target_cycles = cpu.cycles_per_frame;
        uint64_t cycles_start = cpu.total_cycles;
        
        // Calculate how many CPU cycles make up one audio sample
        static double audio_cycle_counter = 0.0;
        double cycles_per_sample = (double)cpu.clock_freq_hz / 44100.0;

        while ((cpu.total_cycles - cycles_start < target_cycles) && running) {
            uint64_t old_cycles = cpu.total_cycles;
            
            z80_step(&cpu);
            
            uint64_t cycles_taken = cpu.total_cycles - old_cycles;
            audio_cycle_counter += cycles_taken;

            // Static variables to remember the previous state across loop iterations
            static float dc_offset = 0.0f; 
            static float lp_filter = 0.0f; // Tracks the state of our low-pass filter
            
            while (audio_cycle_counter >= cycles_per_sample) {
                audio_cycle_counter -= cycles_per_sample;
                
                // Convert 0/1 state to a raw square wave float
                float raw_sample = speaker_state ? 0.50f : -0.50f; 
                
                // 1. Apply Low-Pass Filter (Smooths the harsh edges)
                // The factor 0.85f controls the cutoff frequency. 
                // Higher (e.g., 0.95f) = more muffled. Lower (e.g., 0.50f) = brighter/harsher.
				// Total must be equal to 1.0f
                lp_filter = (lp_filter * 0.70f) + (raw_sample * 0.30f);
                
                // 2. Apply High-Pass Filter (DC Blocker) to the smoothed signal
                dc_offset = (dc_offset * 0.995f) + (lp_filter * 0.005f);
                
                // 3. Final Output
                float sample = lp_filter - dc_offset;
                
                if (audio_stream) {
                    SDL_PutAudioStreamData(audio_stream, &sample, sizeof(sample));
                }
            }

            if (cpu.halted) running = false;
        }

		/* Prevent audio buffer bloat by syncing emulator speed to the audio stream */
        if (audio_stream) {
            // Threshold: 2048 samples * 4 bytes (float) = 8192 bytes (~46ms of audio)
            // If the queue has more than this, pause the CPU so the audio hardware can catch up.
			// Increased threshold to 4096 samples (~92ms) to survive OS scheduler jitter
            while (SDL_GetAudioStreamAvailable(audio_stream) > 4096 * sizeof(float)) {
                SDL_Delay(1);
            }
        } else {
            /* Fallback to your coarse timer if audio isn't initialized */
            z80_sync_to_frame(&cpu, 60);
        }

        if (video_mode == 0) {
            terminal_render(renderer);
        } else {
            graphics_render(renderer);
			SDL_RenderPresent(renderer); // This tells SDL to actually swap the buffers
        }
        
        
    
        // SDL_Delay(16); // ~60fps
    }
	
	if (audio_stream) {
        SDL_DestroyAudioStream(audio_stream);
    }

	for (int i = 1; i <= 4; i++) {
        if (mode_textures[i]) SDL_DestroyTexture(mode_textures[i]);
    }

	SDL_Delay(2000);	// 2 second delay before closes
	SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
