#include "graphics.h"

uint8_t vram[VRAM_SIZE];
uint16_t vram_ptr = 0;
uint8_t video_mode = 0; // 0=Text, 1=24bpp, 2=8bpp, 3=4bpp, 4=1bpp

// GPU Textures for each mode (Index 1 to 4)
SDL_Texture* mode_textures[5] = {NULL};

// CPU Pixel Buffer: Big enough to hold our largest resolution (640x400)
// Format is ARGB8888 (32 bits per pixel)
uint32_t frame_pixels[640 * 400];

static const uint32_t palette_16[16] = {
    0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAA5500, 0xAAAAAA,
    0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
};

void graphics_render(SDL_Renderer *r) {
    if (video_mode == 0 || video_mode > 4) return;

    int width = 0, height = 0;

    // ---------------------------------------------------------
    // 1. Build the Frame Buffer in CPU RAM
    // ---------------------------------------------------------
    if (video_mode == 1) {
        width = 120; height = 90;
        for (int i = 0; i < width * height; i++) {
            uint8_t red   = vram[i * 3];
            uint8_t green = vram[i * 3 + 1];
            uint8_t blue  = vram[i * 3 + 2];
            // Format: Alpha (0xFF), Red, Green, Blue
            frame_pixels[i] = (0xFF << 24) | (red << 16) | (green << 8) | blue;
        }
    } 
    else if (video_mode == 2) {
        width = 220; height = 144;
        for (int i = 0; i < width * height; i++) {
            uint8_t pixel = vram[i];
            uint8_t red   = (pixel >> 5) * 36;
            uint8_t green = ((pixel >> 2) & 7) * 36;
            uint8_t blue  = (pixel & 3) * 85;
            frame_pixels[i] = (0xFF << 24) | (red << 16) | (green << 8) | blue;
        }
    }
    else if (video_mode == 3) {
        width = 320; height = 200;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x += 2) {
                uint8_t pair = vram[(y * width / 2) + (x / 2)];
                
                uint32_t c1 = palette_16[pair >> 4];
                frame_pixels[y * width + x]     = (0xFF << 24) | c1;
                
                uint32_t c2 = palette_16[pair & 0x0F];
                frame_pixels[y * width + x + 1] = (0xFF << 24) | c2;
            }
        }
    }
    else if (video_mode == 4) {
        width = 640; height = 400;
        uint32_t fg = 0xFFC0C0C0; // Silver
        uint32_t bg = 0xFF353839; // Onyx
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x += 8) {
                uint8_t pixels = vram[(y * width / 8) + (x / 8)];
                for (int bit = 0; bit < 8; bit++) {
                    frame_pixels[y * width + x + bit] = (pixels & (0x80 >> bit)) ? fg : bg;
                }
            }
        }
    }

    // ---------------------------------------------------------
    // 2. Push Buffer to GPU & Render (SDL3 Syntax)
    // ---------------------------------------------------------
    SDL_Texture* active_texture = mode_textures[video_mode];
    
    // Update the texture with our CPU array (Pitch is width * 4 bytes per pixel)
    SDL_UpdateTexture(active_texture, NULL, frame_pixels, width * sizeof(uint32_t));
    
    // Clear the screen and draw the full texture
    SDL_SetRenderDrawColor(r, 0, 0, 0, 255);
    SDL_RenderClear(r);
    SDL_RenderTexture(r, active_texture, NULL, NULL);
}
