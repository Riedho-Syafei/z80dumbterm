; Z80 Test Program for Custom VDP
; Target: CP/M (.COM file, ORG 0x0100)
; Mode 4 Test: 640x400, 1-bit monochrome (8 pixels/byte)

; --- Port Definitions ---
VDP_MODE_PORT   EQU 40H
VDP_PTR_LO      EQU 41H
VDP_PTR_HI      EQU 42H
VDP_DATA        EQU 43H
CON_STAT_PORT   EQU 00H
CON_DATA_PORT   EQU 01H

        ORG 0100H

START:
        ; Switch to Video Mode 4
        LD A, 4
        OUT (VDP_MODE_PORT), A

        ; Reset VRAM Pointer to 0x0000
        XOR A
        OUT (VDP_PTR_LO), A
        OUT (VDP_PTR_HI), A

        ; Initial pattern
        LD E, 11100000B

        ; 400 rows
        LD B, 400 / 2        ; B is 8-bit, so use 200 * 2 rows

ROW_LOOP_OUTER:
        PUSH BC

        ; First row
        LD C, 80
ROW_LOOP1:
        LD A, E
        OUT (VDP_DATA), A
        DEC C
        JR NZ, ROW_LOOP1

        ; Shift pattern for next row
        LD A, E
        RRCA
        LD E, A

        ; Second row
        LD C, 80
ROW_LOOP2:
        LD A, E
        OUT (VDP_DATA), A
        DEC C
        JR NZ, ROW_LOOP2

        ; Shift pattern again
        LD A, E
        RRCA
        LD E, A

        POP BC
        DJNZ ROW_LOOP_OUTER

        ; 4. Wait for a keypress
WAIT_KEY:
        IN A, (CON_STAT_PORT)
        OR A            
        JR Z, WAIT_KEY

        ; Consume the keypress
        IN A, (CON_DATA_PORT) 

        ; 5. Restore Text Mode (Mode 0)
        XOR A
        OUT (VDP_MODE_PORT), A

        JP  $003B