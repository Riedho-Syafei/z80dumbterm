		ORG 0100h       ; Standard CP/M .COM origin

START:  LD DE, 440     ; Duration counter (number of full sound waves)

LOOP:   
        ; 1. Set speaker HIGH
        LD A, 01h
        OUT (20h), A

        ; 2. Delay for the first half of the waveform
        CALL DELAY_440

        ; 3. Set speaker LOW
        LD A, 00h
        OUT (20h), A

        ; 4. Delay for the second half of the waveform
        CALL DELAY_440

        ; 5. Decrement duration counter and loop if not zero
        DEC DE
        LD A, D
        OR E            ; Logical OR to check if DE is 0000h
        JR NZ, LOOP     ; If not zero, jump back to LOOP

        ; 6. Exit cleanly to CP/M
        JP $003B             

; ---------------------------------------------------------
; Delay Subroutine
; The value in register B controls the pitch.
; A smaller value = shorter delay = higher frequency tone.
; ---------------------------------------------------------
DELAY:  
        LD B, 255       ; Pitch control (150 is approx 1kHz at 4MHz)
WAIT:   DJNZ WAIT       ; Decrement B, jump to WAIT if not zero
        RET

; ---------------------------------------------------------

DELAY_1:
		LD B, 255
		PUSH BC
    	IN A, ($08)		; GET_TICKS
    	LD C, A         ; C = Start Time
.loop:
    	IN A, ($08)
    	SUB C           ; A = Current - Start (Calculates elapsed)
    	CP B            ; Compare elapsed with desired delay (B)
    	JR C, .loop     ; If elapsed < B, carry flag is set, keep looping
    	POP BC
    	RET

; ---------------------------------------------------------

; ---------------------------------------------------------
; 3.5 MHz Timing Loop for 440Hz
; Total target: 3977 T-states
; ---------------------------------------------------------
DELAY_440:
        PUSH BC             ; 11 T-states
        LD B, 230           ; 7  T-states
INNER_LOOP:
        DEC B               ; 4  T-states
        JP NZ, INNER_LOOP   ; 10 T-states if jump (14 total per loop)
                            ; Note: Z80 JP NZ is 10T, JR NZ is 12T.
                            ; 230 * 14 = 3220 T-states.

        ; Extra padding to hit the ~3977 mark
        PUSH AF             ; 11
        POP AF              ; 10
        PUSH AF             ; 11
        POP AF              ; 10
        
        POP BC              ; 10
        RET                 ; 10
