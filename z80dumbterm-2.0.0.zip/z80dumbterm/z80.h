#ifndef Z80_H
#define Z80_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

/* Z80 clock configuration */
#define Z80_CLOCK_FREQ_HZ 3500000  /* 3.5 MHz standard Z80 */
#define CYCLES_PER_MS (Z80_CLOCK_FREQ_HZ / 1000)

typedef struct {
    /* Register file */
    uint16_t pc;
	uint16_t sp;
    uint8_t  a;
    uint8_t  f;
	uint8_t b;
	uint8_t c;
	uint8_t d;
	uint8_t e;
	uint8_t h;
	uint8_t l;
	uint8_t a2;
	uint8_t f2;
	uint8_t b2, c2;
	uint8_t d2, e2;
	uint8_t h2, l2;
    bool     halted;
	uint16_t ix;
	uint16_t iy;

    /* Internal clock */
    uint64_t total_cycles;      /* Total cycles executed since reset */
    uint32_t clock_freq_hz;     /* Clock frequency in Hz (default: 3.5MHz) */
    uint64_t cycles_per_frame;  /* Target cycles per frame for timing */
} Z80;

/* function declarations */
void z80_step(Z80 *cpu);
void handle_ED_prefix(Z80 *cpu);
void handle_DD_prefix(Z80 *cpu);
void handle_FD_prefix(Z80 *cpu);

/* Clock management functions */
void z80_init_clock(Z80 *cpu, uint32_t freq_hz);
void z80_reset(Z80 *cpu);
void z80_add_cycles(Z80 *cpu, uint32_t cycles);
uint64_t z80_get_total_cycles(Z80 *cpu);
uint64_t z80_get_elapsed_time_us(Z80 *cpu);
void z80_sync_to_frame(Z80 *cpu, uint32_t target_fps);
void z80_set_clock_freq(Z80 *cpu, uint32_t freq_hz);
uint32_t z80_get_clock_freq(Z80 *cpu);
double z80_get_current_speed_mhz(Z80 *cpu);

static inline uint16_t get_hl(Z80 *cpu) {
    return (cpu->h << 8) | cpu->l;
}

static int parity(uint8_t v);

#define FLAG_S  0x80
#define FLAG_Z  0x40
#define FLAG_H  0x10
#define FLAG_PV 0x04
#define FLAG_N  0x02
#define FLAG_C  0x01
#define FLAG_3  0x04
#define FLAG_5  0x20

#define GET_FLAG(cpu, flag) (cpu.f & (flag))
#define SET_FLAG(cpu, flag) (cpu.f |= (flag))
#define CLR_FLAG(cpu, flag) (cpu.f &= ~(flag))

#define GET_HL(cpu) (((cpu)->h << 8) | (cpu)->l)
#define SET_HL(cpu, v) do { (cpu)->h = (v) >> 8; (cpu)->l = (v); } while (0)

#define GET_DE(cpu) (((cpu)->d << 8) | (cpu)->e)
#define SET_DE(cpu, v) do { (cpu)->d = (v) >> 8; (cpu)->e = (v); } while (0)

#define GET_BC(cpu) (((cpu)->b << 8) | (cpu)->c)
#define SET_BC(cpu, v) do { (cpu)->b = (v) >> 8; (cpu)->c = (v); } while (0)

static inline void push16(Z80 *cpu, uint16_t value);
static inline uint16_t pop16(Z80 *cpu);

uint8_t io_read(uint8_t port, Z80 *cpu);
void io_write(uint8_t port, uint8_t value, Z80 *cpu);

extern FILE* logfile;

#endif