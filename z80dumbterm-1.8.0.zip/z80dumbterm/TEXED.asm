; ==============================================================================
; TEXED.ASM - A Simple Text Editor for PERTIWI-OS
; Uses 16KB Gap Buffer
; Controls:
; Ctrl + WASD = Cursor navigation
; Ctrl + E    = Save
; Ctrl + C    = Exit
; ==============================================================================
        ORG $0100

; --- Syscall Definitions (OS) ---
SYSCALL     EQU $0005
WBOOT       EQU $003B

SYS_GETCHAR EQU 2
SYS_PUTS    EQU 3
SYS_OPEN    EQU 33
SYS_READ    EQU 34
SYS_CLOSE   EQU 35
SYS_CREATE  EQU 37
SYS_DELETE  EQU 38
SYS_WRITE   EQU 40
SYS_FSIZE   EQU 42

; --- PERTIWI.LIB Jump Table (Loaded at $C000) ---
TERM_PUTC   EQU $C000
TERM_PUTS   EQU $C003
TERM_CUP    EQU $C006
TERM_CLEFT  EQU $C009
TERM_CDOWN  EQU $C00C
TERM_CRIGHT EQU $C00F
TERM_SETPOS EQU $C012
TERM_CLEAR  EQU $C015
TERM_GETPOS EQU $C018

; --- Configuration ---
BUFFER_START EQU $6000
BUFFER_SIZE  EQU $4000
BUFFER_END   EQU $A000

; --- OS Argument Memory Map ---
ARG0        EQU $0080
ARG1        EQU $0090

; ==============================================================================
; MAIN ENTRY POINT
; ==============================================================================
START:
        ; 1. Load PERTIWI.LIB
        LD   C, SYS_OPEN
        LD   DE, LIB_FILENAME
        CALL SYSCALL
        OR   A
        JP   NZ, error_lib_missing

        LD   DE, SCRATCH
        LD   C, SYS_FSIZE
        CALL SYSCALL

        LD   HL, (SCRATCH)
        LD   A, H
        OR   L
        JR   Z, load_pertiwi_done

        ; HL contains length, DE contains buffer address
        LD   DE, $C000
        LD   C, SYS_READ
        CALL SYSCALL

load_pertiwi_done:
        LD   C, SYS_CLOSE
        CALL SYSCALL

        ; 2. Parse Arguments
        CALL parse_arguments
        LD   A, H
        OR   L
        JP   Z, error_no_filename
        LD   (FILENAME_PTR), HL

        ; 3. Initialize Gap Buffer
        LD   HL, BUFFER_START
        LD   (GAP_START), HL
        LD   HL, BUFFER_END
        LD   (GAP_END), HL
        LD   HL, BUFFER_START
        LD   (SCREEN_TOP_PTR), HL

        ; 4. Load File (if exists)
        LD   C, SYS_OPEN
        LD   DE, (FILENAME_PTR)
        CALL SYSCALL
        OR   A
        JR   NZ, start_editing

        LD   DE, SCRATCH
        LD   C, SYS_FSIZE
        CALL SYSCALL

        LD   HL, (SCRATCH)
        LD   A, H
        OR   L
        JR   Z, close_and_start

        LD   DE, BUFFER_START
        LD   C, SYS_READ
        CALL SYSCALL

        ; Apply file length to GAP_START
        LD   HL, (SCRATCH)
        LD   DE, BUFFER_START
        ADD  HL, DE
        LD   (GAP_START), HL

close_and_start:
        LD   C, SYS_CLOSE
        CALL SYSCALL

start_editing:
        CALL TERM_CLEAR
        CALL RENDER

; ==============================================================================
; MAIN LOOP
; ==============================================================================
MAIN_LOOP:
        LD   C, SYS_GETCHAR
        CALL SYSCALL           ; A = Key

        ; --- Control Keys ---
        CP   1                 ; Ctrl-A Left
        JR   Z, do_left
        CP   4                 ; Ctrl-D Right
        JR   Z, do_right
        CP   23                ; Ctrl-W Up
        JR   Z, do_up
        CP   19                ; Ctrl-S Down
        JR   Z, do_down
        CP   5                 ; Ctrl-E Save
        JR   Z, do_save
        CP   3                 ; Ctrl-C Exit
        JP   Z, WBOOT

        CP   8                 ; Backspace
        JR   Z, do_backspace
        CP   127               ; Delete
        JR   Z, do_delete

        ; === Enter ===
        CP   13
        JR   Z, .insert_nl
        CP   10
        JR   Z, .insert_nl

        ; Printable characters
        CP   32
        JR   C, MAIN_LOOP      ; ignore < 32

        JR   .do_insert

.insert_nl:
        LD   A, 10             ; normalize to LF

.do_insert:
        CALL INSERT_CHAR
        JR   render_update

do_backspace:                  
        LD   HL, (GAP_START)
        LD   DE, BUFFER_START
        OR   A
        SBC  HL, DE
        JR   Z, render_update  ; at start
        LD   HL, (GAP_START)   ; RESTORE HL BEFORE MODIFYING
        DEC  HL
        LD   (GAP_START), HL
        JR   render_update

do_delete:                     
        LD   HL, (GAP_END)
        LD   DE, BUFFER_END
        OR   A
        SBC  HL, DE
        JR   Z, render_update  ; at end
        LD   HL, (GAP_END)     ; RESTORE HL BEFORE MODIFYING
        INC  HL
        LD   (GAP_END), HL
        JR   render_update

do_left:
        CALL MOVE_LEFT
        JR   render_update
do_right:
        CALL MOVE_RIGHT
        JR   render_update
do_up:
        CALL MOVE_UP
        JR   render_update
do_down:
        CALL MOVE_DOWN
        JR   render_update
do_save:
        CALL SAVE_FILE
        JR   render_update

render_update:
        CALL RENDER
        JP   MAIN_LOOP

; ==============================================================================
; GAP BUFFER CORE
; ==============================================================================
INSERT_CHAR:
        PUSH AF
        LD   HL, (GAP_END)
        LD   DE, (GAP_START)
        OR   A
        SBC  HL, DE
        JR   Z, .full          ; buffer full

        LD   HL, (GAP_START)
        LD   (HL), A
        INC  HL
        LD   (GAP_START), HL
.full:
        POP  AF
        RET

MOVE_LEFT:
        LD   HL, (GAP_START)
        LD   DE, BUFFER_START
        OR   A
        SBC  HL, DE
        RET  Z
        LD   HL, (GAP_START)
        DEC  HL
        LD   D, (HL)
        LD   HL, (GAP_END)
        DEC  HL
        LD   (HL), D
        LD   (GAP_END), HL
        LD   HL, (GAP_START)
        DEC  HL
        LD   (GAP_START), HL
        RET

MOVE_RIGHT:
        LD   HL, (GAP_END)
        LD   DE, BUFFER_END
        OR   A
        SBC  HL, DE
        RET  Z
        LD   HL, (GAP_END)
        LD   D, (HL)
        INC  HL
        LD   (GAP_END), HL
        LD   HL, (GAP_START)
        LD   (HL), D
        INC  HL
        LD   (GAP_START), HL
        RET

; ==============================================================================
; VERTICAL MOVEMENT 
; ==============================================================================
MOVE_UP:                       
        CALL GET_COL           ; B = current column
        LD   HL, (GAP_START)
        CALL FIND_LINE_START   ; HL = start of CURRENT line

        LD   DE, BUFFER_START
        OR   A
        SBC  HL, DE
        RET  Z                 ; already first line
        ADD  HL, DE

        DEC  HL                ; point at newline
        CALL FIND_LINE_START   ; HL = start of PREVIOUS line
        CALL MOVE_TO_COL       ; target logically defined
        
.shift_gap_left:               ; physically shift gap backward
        LD   A, (GAP_START)
        CP   L
        JR   NZ, .do_shift_l
        LD   A, (GAP_START+1)
        CP   H
        RET  Z
.do_shift_l:
        PUSH HL
        CALL MOVE_LEFT
        POP  HL
        JR   .shift_gap_left

MOVE_DOWN:
        CALL GET_COL           ; B = current column
        LD   HL, (GAP_END)     ; start after gap

.find_nl_down:
        PUSH DE
        LD   DE, BUFFER_END
        OR   A
        PUSH HL                
        SBC  HL, DE
        POP  HL
        POP  DE
        RET  Z

        LD   A, (HL)
        INC  HL
        CP   10
        JR   Z, .found_nl_down
        CP   13
        JR   Z, .found_nl_down
        JR   .find_nl_down

.found_nl_down:
        ; Handle CRLF or standalone CR/LF cleanly
        CP   13
        JR   NZ, .got_line_down  ; was LF, HL already advanced
        
        ; Verify safety before checking for paired LF
        PUSH DE
        LD   DE, BUFFER_END
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   Z, .got_line_down
        
        LD   A, (HL)
        CP   10
        JR   NZ, .got_line_down  ; just CR
        INC  HL                  ; consume paired LF
        
.got_line_down:
        CALL MOVE_TO_COL
        
.shift_gap_right:              ; physically shift gap forward
        LD   A, (GAP_END)
        CP   L
        JR   NZ, .do_shift_r
        LD   A, (GAP_END+1)
        CP   H
        RET  Z
.do_shift_r:
        PUSH HL
        CALL MOVE_RIGHT
        POP  HL
        JR   .shift_gap_right

; ==============================================================================
; CURSOR HELPERS
; ==============================================================================
MOVE_TO_COL:
.move_col_loop:
        LD   A, B
        OR   A
        RET  Z

        PUSH DE
        LD   DE, (GAP_START)
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   NZ, .not_gap
        LD   HL, (GAP_END)
.not_gap:

        ; Safely stop at end of buffer
        PUSH DE
        LD   DE, BUFFER_END
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        RET  Z

        LD   A, (HL)
        CP   10
        RET  Z
        CP   13
        RET  Z

        INC  HL
        DEC  B
        JR   .move_col_loop

GET_COL:
        LD   HL, (GAP_START)
        LD   B, 0
.scan_back:
        LD   DE, BUFFER_START
        OR   A
        SBC  HL, DE
        ADD  HL, DE
        RET  Z

        DEC  HL
        LD   A, (HL)
        CP   10
        RET  Z
        CP   13
        RET  Z
        INC  B
        JR   .scan_back

FIND_LINE_START:
        PUSH DE
        LD   DE, BUFFER_START
.loop:
        OR   A
        SBC  HL, DE
        ADD  HL, DE
        JR   Z, .done_fls

        DEC  HL
        LD   A, (HL)
        CP   10
        JR   Z, .found_nl_fls
        CP   13
        JR   Z, .found_nl_fls
        JR   .loop
.found_nl_fls:
        INC  HL
.done_fls:
        POP  DE
        RET

; ==============================================================================
; RENDERING (with gap handling)
; ==============================================================================
RENDER:
        CALL TERM_CLEAR

        LD   HL, (SCREEN_TOP_PTR)
        LD   C, 0              ; line counter

.draw_loop:
        LD   A, C
        CP   23
        JR   NC, .draw_status

        PUSH DE
        LD   DE, (GAP_START)
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   NZ, .no_gap_cross
        LD   HL, (GAP_END)
.no_gap_cross:

        PUSH DE
        LD   DE, BUFFER_END
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   NC, .draw_status

        LD   A, (HL)
        OR   A
        JR   Z, .draw_status

        CP   10
        JR   Z, .handle_newline
        CP   13
        JR   Z, .handle_newline

        CALL TERM_PUTC
        INC  HL
        JR   .draw_loop

.handle_newline:
        LD   A, 10
        CALL TERM_PUTC
        INC  HL
        INC  C
        JR   .draw_loop

.draw_status:
        LD   B, 1
        LD   C, 24
        CALL TERM_SETPOS

        LD   HL, MSG_STATUS
        CALL TERM_PUTS
        LD   HL, (FILENAME_PTR)
        CALL TERM_PUTS

        CALL CALC_CURSOR_Y
        LD   C, A
        INC  C                 ; VT100 rows start at 1

        CALL GET_COL
        INC  B                 ; 1-based X

        CALL TERM_SETPOS
        RET

CALC_CURSOR_Y:
        LD   HL, (SCREEN_TOP_PTR)
        LD   DE, (GAP_START)
        LD   C, 0
.count_loop:
        PUSH DE
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   Z, .found_y

        PUSH DE
        LD   DE, (GAP_START)
        OR   A
        PUSH HL
        SBC  HL, DE
        POP  HL
        POP  DE
        JR   NZ, .no_gap_skip
        LD   HL, (GAP_END)
.no_gap_skip:

        LD   A, (HL)
        CP   10
        JR   NZ, .not_nl_cnt
        INC  C
.not_nl_cnt:
        INC  HL
        JR   .count_loop

.found_y:
        LD   A, C
        CP   24
        RET  C
        LD   A, 23
        RET

; ==============================================================================
; FILE I/O
; ==============================================================================
SAVE_FILE:
        LD   C, SYS_DELETE
        LD   DE, (FILENAME_PTR)
        CALL SYSCALL

        LD   C, SYS_CREATE
        LD   DE, (FILENAME_PTR)
        CALL SYSCALL
        OR   A
        JR   NZ, .save_err

        LD   C, SYS_OPEN
        CALL SYSCALL
        OR   A
        JR   NZ, .save_err

        ; Write pre-gap
        LD   HL, (GAP_START)
        LD   DE, BUFFER_START
        OR   A
        SBC  HL, DE
        LD   C, SYS_WRITE
        LD   DE, BUFFER_START
        CALL SYSCALL

        ; Write post-gap
        LD   HL, BUFFER_END
        LD   DE, (GAP_END)
        OR   A
        SBC  HL, DE
        LD   C, SYS_WRITE
        LD   DE, (GAP_END)
        CALL SYSCALL

        LD   C, SYS_CLOSE
        CALL SYSCALL
        RET

.save_err:
        RET

; ==============================================================================
; HELPERS
; ==============================================================================
parse_arguments:
        LD   HL, ARG1
        LD   A, (HL)
        OR   A
        JR   Z, .no_arg
        PUSH HL
        LD   DE, 15
        ADD  HL, DE
        LD   (HL), 0
        POP  HL
        RET
.no_arg:
        LD   HL, 0
        RET

error_lib_missing:
        LD   C, SYS_PUTS
        LD   DE, MSG_ERR_LIB
        CALL SYSCALL
        JP   WBOOT

error_no_filename:
        LD   C, SYS_PUTS
        LD   DE, MSG_ERR_ARG
        CALL SYSCALL
        JP   WBOOT

; ==============================================================================
; DATA
; ==============================================================================
LIB_FILENAME:   DB "PERTIWI.LIB", 0
MSG_STATUS:     DB "-- TEXED: ", 0
MSG_ERR_LIB:    DB "ERROR: PERTIWI.LIB not found!", 13, 10, 0
MSG_ERR_ARG:    DB "Usage: TEXED <filename>", 13, 10, 0

FILENAME_PTR:   DW 0
GAP_START:      DW 0
GAP_END:        DW 0
SCREEN_TOP_PTR: DW 0
SCRATCH:        DS 4, 0