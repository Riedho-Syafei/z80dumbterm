#ifndef CPM_HEXDUMP_H
#define CPM_HEXDUMP_H

#include <stdint.h>

void load_minimal_cpm(uint8_t *memory);

#endif