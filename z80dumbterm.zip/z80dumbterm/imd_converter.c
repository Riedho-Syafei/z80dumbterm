/*
 * ImageDisk (IMD) File Parser
 * Converts IMD disk images to raw disk format for CP/M emulator
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define MAX_DISK_SIZE (77 * 26 * 128)  // Standard CP/M disk size

// Sector data type flags in IMD format
#define SECTOR_UNAVAILABLE  0
#define SECTOR_NORMAL       1
#define SECTOR_COMPRESSED   2
#define SECTOR_DELETED      3
#define SECTOR_COMPRESSED_DELETED 4
#define SECTOR_ERROR        5
#define SECTOR_COMPRESSED_ERROR 6
#define SECTOR_DELETED_ERROR 7
#define SECTOR_COMPRESSED_DELETED_ERROR 8

typedef struct {
    uint8_t mode;           // Transfer mode
    uint8_t cylinder;       // Cylinder number
    uint8_t head;           // Head number (0 or 1)
    uint8_t num_sectors;    // Number of sectors
    uint8_t sector_size;    // Sector size code (0=128, 1=256, 2=512, etc.)
} IMDTrackHeader;

// Convert IMD file to raw disk image
int convert_imd_to_raw(const char *imd_filename, const char *raw_filename) {
    FILE *imd_file = fopen(imd_filename, "rb");
    if (!imd_file) {
        fprintf(stderr, "Error: Cannot open %s\n", imd_filename);
        return -1;
    }
    
    // Allocate output buffer
    uint8_t *disk_image = calloc(MAX_DISK_SIZE, 1);
    if (!disk_image) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        fclose(imd_file);
        return -1;
    }
    
    // Read and skip IMD header (ASCII text ending with 0x1A)
    int c;
    printf("IMD Header:\n");
    while ((c = fgetc(imd_file)) != EOF && c != 0x1A) {
        putchar(c);
    }
    printf("\n\n");
    
    if (c != 0x1A) {
        fprintf(stderr, "Error: Invalid IMD file (no header terminator)\n");
        free(disk_image);
        fclose(imd_file);
        return -1;
    }
    
    // Parse track data
    int track_num = 0;
    while (!feof(imd_file)) {
        IMDTrackHeader header;
        
        // Read track header
        if (fread(&header, 1, 5, imd_file) != 5) {
            break;  // End of file
        }
        
        int sector_size = 128 << header.sector_size;  // Calculate actual sector size
        
        printf("Track %d: Cylinder=%d Head=%d Sectors=%d Size=%d bytes\n",
               track_num, header.cylinder, header.head, 
               header.num_sectors, sector_size);
        
        // Read sector numbering map
        uint8_t *sector_map = malloc(header.num_sectors);
        if (fread(sector_map, 1, header.num_sectors, imd_file) != header.num_sectors) {
            fprintf(stderr, "Error reading sector map\n");
            free(sector_map);
            break;
        }
        
        // Read cylinder map if present (bit 7 of head set)
        if (header.head & 0x80) {
            uint8_t *cyl_map = malloc(header.num_sectors);
            fread(cyl_map, 1, header.num_sectors, imd_file);
            free(cyl_map);
        }
        
        // Read head map if present (bit 6 of head set)
        if (header.head & 0x40) {
            uint8_t *head_map = malloc(header.num_sectors);
            fread(head_map, 1, header.num_sectors, imd_file);
            free(head_map);
        }
        
        header.head &= 0x3F;  // Clear flag bits
        
        // Read sector data
        for (int i = 0; i < header.num_sectors; i++) {
            uint8_t sector_type = fgetc(imd_file);
            
            // Calculate position in output disk image
            // For CP/M: track * sectors_per_track * sector_size
            int logical_sector = sector_map[i] - 1;  // Convert to 0-based
            int offset = (track_num * 26 + logical_sector) * 128;
            
            if (offset + sector_size > MAX_DISK_SIZE) {
                fprintf(stderr, "Warning: Sector %d exceeds disk size\n", i);
                continue;
            }
            
            switch (sector_type) {
                case SECTOR_UNAVAILABLE:
                    // Sector not available, skip
                    break;
                    
                case SECTOR_NORMAL:
                case SECTOR_DELETED:
                case SECTOR_ERROR:
                case SECTOR_DELETED_ERROR:
                    // Normal sector - read full data
                    fread(&disk_image[offset], 1, sector_size, imd_file);
                    break;
                    
                case SECTOR_COMPRESSED:
                case SECTOR_COMPRESSED_DELETED:
                case SECTOR_COMPRESSED_ERROR:
                case SECTOR_COMPRESSED_DELETED_ERROR:
                    // Compressed sector - single byte repeated
                    {
                        uint8_t fill_byte = fgetc(imd_file);
                        memset(&disk_image[offset], fill_byte, sector_size);
                    }
                    break;
                    
                default:
                    fprintf(stderr, "Warning: Unknown sector type %d\n", sector_type);
                    break;
            }
        }
        
        free(sector_map);
        track_num++;
    }
    
    fclose(imd_file);
    
    printf("\nConverted %d tracks\n", track_num);
    
    // Write raw disk image
    FILE *raw_file = fopen(raw_filename, "wb");
    if (!raw_file) {
        fprintf(stderr, "Error: Cannot create %s\n", raw_filename);
        free(disk_image);
        return -1;
    }
    
    // Write the used portion of the disk
    size_t disk_size = track_num * 26 * 128;
    fwrite(disk_image, 1, disk_size, raw_file);
    fclose(raw_file);
    
    printf("Written %zu bytes to %s\n", disk_size, raw_filename);
    
    free(disk_image);
    return 0;
}

// Load converted disk as drive A
int load_cpm_disk_from_imd(const char *imd_filename, uint8_t *disk_image_array) {
    // First convert to temporary raw file
    const char *temp_raw = "temp_cpm.dsk";
    
    if (convert_imd_to_raw(imd_filename, temp_raw) != 0) {
        return -1;
    }
    
    // Load the raw disk image
    FILE *f = fopen(temp_raw, "rb");
    if (!f) {
        fprintf(stderr, "Error: Cannot open converted disk\n");
        return -1;
    }
    
    size_t bytes_read = fread(disk_image_array, 1, MAX_DISK_SIZE, f);
    fclose(f);
    
    printf("Loaded %zu bytes into drive A\n", bytes_read);
    
    // Clean up temp file (optional)
    // remove(temp_raw);
    
    return 0;
}

/*
 * Usage in your emulator initialization:
 *
 * // In cpm_disk_init() or similar:
 * if (load_cpm_disk_from_imd("CPM22RED.IMD", disk_state.disk_images[0]) == 0) {
 *     printf("CP/M system disk loaded in drive A:\n");
 *     
 *     // The disk image now contains CP/M in the boot tracks
 *     // You still need to load it into memory for execution
 *     
 *     // Copy boot tracks (first 2 tracks) to high memory
 *     // Tracks 0-1 = 52 sectors * 128 bytes = 6656 bytes
 *     memcpy(&memory[0xE000], disk_state.disk_images[0], 6656);
 *     
 *     printf("CP/M loaded into memory at 0xE000\n");
 * }
 */

// Standalone converter program
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <input.imd> <output.dsk>\n", argv[0]);
        printf("Example: %s CPM22RED.IMD cpm_system.dsk\n", argv[0]);
        return 1;
    }
    
    printf("Converting IMD file to raw disk image...\n");
    printf("Input:  %s\n", argv[1]);
    printf("Output: %s\n\n", argv[2]);
    
    if (convert_imd_to_raw(argv[1], argv[2]) != 0) {
        fprintf(stderr, "\nConversion failed!\n");
        return 1;
    }
    
    printf("\nConversion successful!\n");
    printf("You can now use %s as a CP/M disk image.\n", argv[2]);
    return 0;
}