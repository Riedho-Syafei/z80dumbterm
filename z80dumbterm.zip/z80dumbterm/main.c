#include <SDL3/SDL.h>
#include "z80.h"
#include "memory.h"
#include "terminal.h"
#include "keyboard.h"
#include "disk.h"
#include "cpm_hexdump.h"
#include <string.h>
#include <stdio.h>

SDL_Window* window;
SDL_Renderer* renderer;


static uint8_t translate_key(SDL_Keycode key, bool shift)
{
    // Letters
    if (key >= SDLK_A && key <= SDLK_Z) {
        return shift ? ('A' + (key - SDLK_A))
                     : ('a' + (key - SDLK_A));
    }

    // Numbers + shifted symbols
    if (key >= SDLK_0 && key <= SDLK_9) {
        if (!shift)
            return '0' + (key - SDLK_0);

        static const char shifted_nums[] = {
            ')', '!', '@', '#', '$', '%', '^', '&', '*', '('
        };
        return shifted_nums[key - SDLK_0];
    }

    // Punctuation
    switch (key) {
        case SDLK_MINUS:        return shift ? '_' : '-';
        case SDLK_EQUALS:       return shift ? '+' : '=';
        case SDLK_LEFTBRACKET:  return shift ? '{' : '[';
        case SDLK_RIGHTBRACKET: return shift ? '}' : ']';
        case SDLK_BACKSLASH:    return shift ? '|' : '\\';
        case SDLK_SEMICOLON:    return shift ? ':' : ';';
        case SDLK_APOSTROPHE:   return shift ? '"' : '\'';
        case SDLK_COMMA:        return shift ? '<' : ',';
        case SDLK_PERIOD:       return shift ? '>' : '.';
        case SDLK_SLASH:        return shift ? '?' : '/';
        case SDLK_GRAVE:        return shift ? '~' : '`';

        case SDLK_SPACE:        return ' ';
        case SDLK_TAB:          return '\t';
        case SDLK_RETURN:       return '\n';
        case SDLK_BACKSPACE:    return '\b';
        case SDLK_ESCAPE:       return 27;
    }

    return 0;
}



int main(void) {
    Z80 cpu;
	memset(memory, 0, 65536);

    // Reset CPU
    memset(&cpu, 0, sizeof(cpu));
    cpu.pc = 0x0000;

	
	
	//cpu.pc = 0xAA00;
	// Load CP/M system
	// cpu.pc = 0xF600;
	cpu.sp = 0xFFF0;
	
	load_minimal_cpm(memory);
	
	



    SDL_Init(SDL_INIT_VIDEO);

    window = SDL_CreateWindow(
        "Z80 Terminal",
        TERM_COLS * CHAR_W * 2,
        TERM_ROWS * CHAR_H * 3,
        0
    );

	//SDL_StartTextInput(window);

    renderer = SDL_CreateRenderer(window, NULL);
	SDL_SetRenderLogicalPresentation(
    	renderer,
    	TERM_COLS * CHAR_W,
    	TERM_ROWS * CHAR_H,
    	SDL_LOGICAL_PRESENTATION_STRETCH
	);


	terminal_init();
	

    bool running = true;

    while (running)
    {
        if (cpu.halted) running = false;
		
		SDL_Event e;
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_EVENT_QUIT)
                running = false;
			

			if (e.type == SDL_EVENT_KEY_DOWN) {
    			bool shift = (e.key.mod & SDL_KMOD_SHIFT);
    			uint8_t ch = translate_key(e.key.key, shift);

    			if (ch != 0)
        			keyboard_push(ch);
			}



        }

		uint32_t start = SDL_GetTicks();

		while (SDL_GetTicks() - start < 16) {
    		z80_step(&cpu);
		}


        terminal_render(renderer);
        //SDL_Delay(16); // ~60fps
    }
	
	
	SDL_Delay(2000);	// 1 second delay before closes
	SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
