		ORG $0100

        ; ---------------------------------------------------------
        ; 1. OPEN the file to be printed
        ; The filename is passed in ARG0 ($0090) by the CCP
        ; ---------------------------------------------------------
        LD   C, 33               ; SYS_FS_OPEN
        LD   DE, $0090           ; Filename pointer
        CALL $0005
        OR   A
        JR   NZ, err_open        ; If A != 0, open failed

        ; ---------------------------------------------------------
        ; 2. Get exact file size in bytes
        ; ---------------------------------------------------------
        LD   DE, FILE_SIZE
        LD   C, 42               ; SYS_FS_FILE_SIZE
        CALL $0005

        LD   HL, (FILE_SIZE)     ; Load the 16-bit size
        LD   A, H
        OR   L
        JR   Z, read_done        ; Skip reading if size is 0

        ; ---------------------------------------------------------
        ; 3. READ entire file into memory
        ; ---------------------------------------------------------
        LD   DE, FILE_BUFFER     ; Destination address
        LD   C, 34               ; SYS_FS_READ
        CALL $0005
        
        CP   $FF                 ; Check for read error
        JR   Z, err_read

read_done:
        ; ---------------------------------------------------------
        ; 4. CLOSE the file
        ; ---------------------------------------------------------
        LD   C, 35               ; SYS_FS_CLOSE
        CALL $0005

        ; ---------------------------------------------------------
        ; 5. PRINTING LOOP WITH 80-COLUMN WRAPPING
        ; ---------------------------------------------------------
START:
        LD   HL, (FILE_SIZE)     ; Total bytes to process
        LD   A, H
        OR   L
        JR   Z, .done            ; Nothing to print

        LD   B, H                ; BC = Total count for the loop
        LD   C, L
        LD   HL, FILE_BUFFER     ; HL = Current character pointer
        LD   E, 0                ; E = Column counter (0-79)

.print_loop:
        PUSH BC                  ; Save remaining byte count
        PUSH HL                  ; Save current buffer pointer

        LD   A, (HL)             ; Load current character from buffer

        ; Check if the character is a newline (CR or LF)
        CP   13                  ; Carriage Return?
        JR   Z, .reset_col
        CP   10                  ; Line Feed?
        JR   Z, .reset_col
        
        ; --- Handle printable character ---
        LD   B, A                ; Put char in B for syscall
        LD   C, 13               ; SYS_PRINT_CHAR
        CALL $0005
        
        INC  E                   ; Column++
        LD   A, E
        CP   80                  ; Check if we reached column 80
        JR   C, .next_iter       ; If < 80, continue

        ; --- Wrap Triggered (Column 80) ---
        LD   B, 13               ; Print CR
        LD   C, 13
        CALL $0005
        LD   B, 10               ; Print LF
        LD   C, 13
        CALL $0005
        LD   E, 0                ; Reset column counter
        JR   .next_iter

.reset_col:
        ; --- Handle existing newline in file ---
        LD   B, A                ; Print the CR or LF as-is
        LD   C, 13               ; SYS_PRINT_CHAR
        CALL $0005
        LD   E, 0                ; Reset column counter on any newline char

.next_iter:
        POP  HL                  ; Restore pointers and count
        POP  BC
        INC  HL                  ; Point to next byte
        DEC  BC                  ; Decrement remaining count
        
        LD   A, B
        OR   C
        JR   NZ, .print_loop     ; Loop until BC == 0

.done:
        LD   C, 3                ; SYS_PUTS
        LD   DE, MSG_DONE
        CALL $0005
        JP   $003B               ; Return to OS

err_open:
        LD   C, 3
        LD   DE, MSG_ERR_OPEN
        CALL $0005
        JP   $0000

err_read:
        LD   C, 3
        LD   DE, MSG_ERR_READ
        CALL $0005
        JP   $0000

; --- Data Area ---
MSG_DONE:     DB "Done printing file.", 13, 10, 0
MSG_ERR_OPEN: DB "Error: Could not open file.", 13, 10, 0
MSG_ERR_READ: DB "Error: Could not read file.", 13, 10, 0

FILE_SIZE:    DW 0, 0             ; Buffer for 32-bit size result
FILE_BUFFER:  EQU $2000           ; Buffer starts at 8KB mark