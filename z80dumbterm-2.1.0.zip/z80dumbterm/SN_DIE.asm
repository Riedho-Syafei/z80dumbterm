		ORG 0100h       ; Standard CP/M .COM origin

SNDFX_DIE:  
        ; E acts as the master duration counter.
        ; 30 iterations of the tremble loop = ~2 seconds at 4MHz.
        LD E, 20        

.tremble_loop:
        ; --- 1. Play Tone A (Lower Pitch) ---
        LD C, 255       ; Delay value for Tone A (longest delay = lowest pitch)
        LD D, 20        ; Play Tone A for 20 sound waves (~33ms)
.tone_a_loop:
        CALL .play_wave
        DEC D
        JR NZ, .tone_a_loop

        ; --- 2. Play Tone B (Slightly Higher Pitch) ---
        LD C, 200       ; Delay value for Tone B (shorter delay = higher pitch)
        LD D, 25        ; Play Tone B for 25 sound waves (~33ms)
.tone_b_loop:
        CALL .play_wave
        DEC D
        JR NZ, .tone_b_loop

        ; --- 3. End of one tremble cycle ---
        DEC E           ; Decrement master duration counter
        JR NZ, .tremble_loop ; Keep trembling until 2 seconds are up

        ; 4. Exit cleanly 
        JP 003Bh        ; Standard CP/M warm boot exit

; ---------------------------------------------------------
; .play_wave Subroutine
; Generates a single full square wave at the pitch in C
; ---------------------------------------------------------
.play_wave:
        ; Set speaker HIGH
        LD A, 01h
        OUT (20h), A
        CALL .pitch_delay

        ; Set speaker LOW
        LD A, 00h
        OUT (20h), A
        CALL .pitch_delay
        RET

; ---------------------------------------------------------
; Dynamic Delay Subroutine
; The value in register C determines the delay length.
; ---------------------------------------------------------
.pitch_delay:  
        LD B, C         ; Load the current pitch value into the loop counter B
.wait:   
        PUSH AF
		POP  AF
		DJNZ .wait       ; Decrement B, jump to .wait if not zero
        RET