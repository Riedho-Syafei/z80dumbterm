		ORG 0100h       ; Standard CP/M .COM origin

SNDFX_EAT:  
        LD C, 255      ; C is our Pitch/Delay value. 255 = longest delay (lowest pitch).

.pitch_loop:
        ; D controls how many sound waves to generate at the current pitch.
        ; Setting this to 5 makes the total sound effect roughly 1 second on a 4MHz Z80.
        LD D, 2        

.cycle_loop:   
        ; 1. Set speaker HIGH
        LD A, 01h
        OUT (20h), A

        ; 2. Delay for the first half of the waveform
        CALL .pitch_delay

        ; 3. Set speaker LOW
        LD A, 00h
        OUT (20h), A

        ; 4. Delay for the second half of the waveform
        CALL .pitch_delay

        ; 5. Decrement the cycle counter and loop if not zero
        DEC D
        JR NZ, .cycle_loop 

        ; 6. Step the pitch up!
        ; Decreasing C makes the delay shorter, which makes the pitch higher.
        DEC C
        JR NZ, .pitch_loop ; Keep ascending until C wraps down to 0

        ; 7. Exit cleanly 
        JP 003Bh          ; Standard CP/M warm boot exit

; ---------------------------------------------------------
; Dynamic Delay Subroutine
; The value in register C determines the delay length.
; ---------------------------------------------------------
.pitch_delay:  
        LD B, C         ; Load the current pitch value into the loop counter B
.wait:   
        DJNZ .wait       ; Decrement B, jump to .wait if not zero
        RET