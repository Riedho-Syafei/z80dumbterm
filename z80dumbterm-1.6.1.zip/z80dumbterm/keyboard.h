#pragma once
#include <stdint.h>

void keyboard_init(void);
void keyboard_push(uint8_t ch);
uint8_t keyboard_pop(void);
uint8_t keyboard_peek(void);
int keyboard_has_data(void);
