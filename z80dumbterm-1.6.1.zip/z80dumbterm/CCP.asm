ARG0	EQU		$0080
ARG1	EQU		$0090
ARG2	EQU		$00A0
ARG3	EQU		$00B0

		ORG $C000

START:
        CALL CLEAR_ARGS
		
		CALL PRINT_PROMPT
        
		CALL READ_LINE
		
		CALL PARSE_BUF_INTO_ARGS

		CALL DISPATCH_INTERNAL_COMMANDS

		LD   A, (LAST_INTERNAL_CMD_SUCCESS)
		CP   1
		JR   Z, SKIP_TRANSIENT_COMMANDS

		CALL DISPATCH_TRANSIENT_COMMANDS

SKIP_TRANSIENT_COMMANDS:

		LD   A, 0
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

        JP START

; ====================================================================
; CCP main subroutines
; ====================================================================

PRINT_PROMPT:

		LD C, 3
		LD DE, PROMPT
		CALL $0005

		RET

READ_LINE:

		LD C, 11
		LD B, 64
		LD DE, BUFFER
		CALL $0005

		RET

PRINT_LINE:

		LD C, 3
		LD DE, BUFFER
		CALL $0005

		RET

PARSE_BUF_INTO_ARGS:

		LD   DE, BUFFER
		
		LD   HL, ARG0
		CALL COPY_WORD

		LD   HL, ARG1
		CALL COPY_WORD

		LD   HL, ARG2
		CALL COPY_WORD

		LD   HL, ARG3
		CALL COPY_WORD

		RET

CLEAR_ARGS:
		
		LD   HL, ARG0
		CALL CLEAR_ARG

		LD   HL, ARG1
		CALL CLEAR_ARG

		LD   HL, ARG2
		CALL CLEAR_ARG

		LD   HL, ARG3
		CALL CLEAR_ARG

		RET

DISPATCH_INTERNAL_COMMANDS:

		LD   DE, ARG0

		; ==============================
		; 1. DIR
		; ==============================
		
		LD   HL, CMD_NAME_DIR
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_dir

		; ==============================
		; 2. EXIT
		; ==============================

		LD   HL, CMD_NAME_EXIT
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_exit

		; ==============================
		; 3. TYPE
		; ==============================

		LD   HL, CMD_NAME_TYPE
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_type

		; ==============================
		; 4. DELETE
		; ==============================

		LD   HL, CMD_NAME_DELETE
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_delete

		; ==============================
		; 5. CREATE
		; ==============================

		LD   HL, CMD_NAME_CREATE
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_create

		; ==============================
		; 6. RENAME
		; ==============================

		LD   HL, CMD_NAME_RENAME
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_rename

		; ==============================
		; 6. A: (select drive A)
		; ==============================

		LD   HL, CMD_NAME_A
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_select_A

		; ==============================
		; 6. B: (select drive B)
		; ==============================

		LD   HL, CMD_NAME_B
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_select_B

		; ==============================
		; 6. C: (select drive C)
		; ==============================

		LD   HL, CMD_NAME_C
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_select_C

		; ==============================
		; 6. D: (select drive D)
		; ==============================

		LD   HL, CMD_NAME_D
		LD   C, 12						; Compare string
		CALL $0005

		JP   Z, .do_select_D

		; ==============================

		RET

.do_dir:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A
		
		LD   C, 32
		CALL $0005

		RET

.do_exit:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		LD   C, 0
		CALL $0005

		RET

; ------------------------------------------------------------------
; TYPE IMPLEMENTATION
; ------------------------------------------------------------------

.do_type:
		
		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		; Get filename from ARG1
		LD   DE, ARG1
		LD   A, (DE)
		OR   A
		JP   Z, .type_missing_arg

		; Open file
		LD   C, 33
		CALL $0005
		OR   A
		JP   NZ, .type_open_fail

		; Get exact 32-bit file size
    	LD   DE, SCRATCH_4_BYTE      ; Pass destination pointer
    	LD   C, 42                   ; SYS_FS_FILE_SIZE
    	CALL $0005
    	OR   A
    	JR   NZ, .type_read_error    ; Failsafe

		; Read loop
.type_read_loop:
		; Check if remaining size is 0
		LD   HL, (SCRATCH_4_BYTE)
		LD   DE, (SCRATCH_4_BYTE+2)
		LD   A, H
		OR   L
		OR   D
		OR   E
		JR   Z, .type_close          ; Done if all 4 bytes are 0

		; Calculate chunk size = min(128, SCRATCH_4_BYTE)
		LD   A, D
		OR   E
		JR   NZ, .read_128           ; If Upper 16-bit > 0, chunk = 128
		LD   A, H
		OR   A
		JR   NZ, .read_128           ; If high byte of Lower 16-bit > 0, chunk = 128
		LD   A, L
		CP   128
		JR   NC, .read_128           ; If low byte >= 128, chunk = 128
		
		; Otherwise, chunk size is the remaining low byte
		LD   B, A                 
		JR   .do_read

.read_128:
		LD   B, 128

.do_read:
		; Save chunk size (in B) for printing & subtraction
		PUSH BC                   

		; Read 'B' bytes
		LD   L, B
		LD   H, 0
		LD   DE, SCRATCH_BUF1
		LD   C, 34                   ; SYS_FS_READ
		CALL $0005
		
		CP   $FF
		JR   Z, .type_read_error_pop ; Hard read error

		CP   1                        ; Check for EOF
        JR   Z, .type_eof              ; No more data, exit cleanly
		
		; Output exactly 'B' bytes (No NULL checks)
		POP  BC                      ; Restore chunk size into B
		PUSH BC                      ; Save again for the subtraction phase
		
		LD   HL, SCRATCH_BUF1
.type_output_loop:
		LD   A, (HL)
		PUSH HL
		PUSH BC
		LD   E, A
		LD   C, 1                    ; PUTCHAR
		CALL $0005
		POP  BC
		POP  HL
		INC  HL
		DJNZ .type_output_loop

		; Subtract chunk size from SCRATCH_4_BYTE
		POP  BC                      ; B = chunk size
		LD   C, B                    ; Move chunk size to C
		LD   B, 0                    ; BC = chunk size (0 to 128)
		
		LD   HL, (SCRATCH_4_BYTE)
		OR   A                       ; Clear carry flag
		SBC  HL, BC
		LD   (SCRATCH_4_BYTE), HL
		
		; If carry is set, borrow from upper 16-bit
		JR   NC, .type_read_loop
		LD   HL, (SCRATCH_4_BYTE+2)
		DEC  HL
		LD   (SCRATCH_4_BYTE+2), HL
		
		JR   .type_read_loop

.type_close:
		LD   C, 35
		CALL $0005
		RET

.type_read_error_pop:
		POP  BC                      ; Clean up stack before error exit
.type_read_error:
		LD   DE, MSG_READ_ERROR
		LD   C, 3
		CALL $0005
		; Attempt to close the file (if open)
		LD   C, 35
		CALL $0005
		RET

.type_missing_arg:
		LD   DE, MSG_MISSING
		LD   C, 3
		CALL $0005
		RET

.type_open_fail:
		LD   DE, MSG_OPEN_FAIL
		LD   C, 3
		CALL $0005
		RET

.type_eof:
        ; EOF reached – no bytes were read in this call, so just close the file
        POP  BC                        ; Clean up stack (discard saved chunk size)
        JR   .type_close

; ------------------------------------------------------------------
; DELETE (file) IMPLEMENTATION
; ------------------------------------------------------------------

.do_delete
		
		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		; Get filename from ARG1
		LD   DE, ARG1
		LD   A, (DE)
		OR   A
		JR   Z, .type_missing_arg				; Used TYPE's snippet to reduce redundancy

		; Call SYS_FS_DELETE
		LD   C, 38
		CALL $0005

		; Check for errors
		OR   A
		JR   Z, .del_success
		CP   $01
		JR   Z, .del_err_file_open
		CP   $FF
		JR   Z, .del_err_not_found

.del_success:
		LD   DE, MSG_DEL_SUCCESS
		LD   C, 3
		CALL $0005
		RET

.del_err_file_open:
		LD   DE, MSG_DEL_OPEN_FILE
		LD   C, 3
		CALL $0005
		RET

.del_err_not_found:
		LD   DE, MSG_OPEN_FAIL
		LD   C, 3
		CALL $0005
		RET

; ------------------------------------------------------------------
; CREATE (file) IMPLEMENTATION
; ------------------------------------------------------------------

.do_create:
		
		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		; Get filename from ARG1
		LD   DE, ARG1
		LD   A, (DE)
		OR   A
		JR   Z, .type_missing_arg				; Used TYPE's snippet to reduce redundancy

		; Call SYS_FS_CREATE
		LD   C, 37
		CALL $0005

		; Check for errors
		OR   A
		JR   Z, .create_success
		CP   $01
		JR   Z, .create_err_same_filename
		CP   $02
		JR   Z, .create_err_dir_full
		CP   $03
		JR   Z, .create_err_disk_full

.create_success:
		LD   DE, MSG_CREATE_SUCCESS
		LD   C, 3
		CALL $0005
		RET

.create_err_same_filename:
		LD   DE, MSG_CREATE_ERR_FILENAME
		LD   C, 3
		CALL $0005
		RET

.create_err_dir_full:
		LD   DE, MSG_CREATE_ERR_DIR_FULL
		LD   C, 3
		CALL $0005
		RET

.create_err_disk_full:
		LD   DE, MSG_CREATE_ERR_DISK_FULL
		LD   C, 3
		CALL $0005
		RET

; ------------------------------------------------------------------
; RENAME (file) IMPLEMENTATION
; RENAME <oldname> <newname>
; ------------------------------------------------------------------
.do_rename:
		
		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A
		
		; Get old filename from ARG1
		LD   HL, ARG1
		LD   A, (HL)
		OR   A
		JR   Z, .rename_missing_oldname

		; Get new filename from ARG2
		LD   DE, ARG2
		LD   A, (DE)
		OR   A
		JR   Z, .rename_missing_newname

		; Call SYS_FS_RENAME
		LD   C, 39
		CALL $0005

		; Check for errors
		OR   A
		JR   Z, .rename_success
		CP   $01
		JR   Z, .rename_err_new_name_exists
		CP   $02
		JR   Z, .rename_err_old_file_not_found
		CP   $03
		JR   Z, .rename_err_open_file
		CP   $FF
		JR   Z, .rename_err_empty_dir

.rename_success:
		LD   DE, MSG_RENAME_SUCCESS
		LD   C, 3
		CALL $0005
		RET

.rename_err_new_name_exists:
		LD   DE, MSG_RENAME_ERR_NEW_NAME_EXIST
		LD   C, 3
		CALL $0005
		RET

.rename_err_old_file_not_found:
		LD   DE, MSG_RENAME_ERR_OLD_FILE_NOT_FOUND
		LD   C, 3
		CALL $0005
		RET

.rename_err_open_file:
		LD   DE, MSG_RENAME_ERR_OPEN_FILE
		LD   C, 3
		CALL $0005
		RET

.rename_err_empty_dir:
		LD   DE, MSG_RENAME_EMPTY_DIR
		LD   C, 3
		CALL $0005
		RET

.rename_missing_oldname:
		LD   DE, MSG_RENAME_ERR_MISSING_OLD_FILENAME
		LD   C, 3
		CALL $0005
		RET

.rename_missing_newname:
		LD   DE, MSG_RENAME_ERR_MISSING_NEW_FILENAME
		LD   C, 3
		CALL $0005
		RET

; =====================================================================
; Select Drive commands
; =====================================================================

.do_select_A:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		LD   B, 0
		LD   C, 18
		CALL $0005

		OR   A
		JR   NZ, .err_select_drive      ; if failed, don't change the prompt

		LD   A, $41
		LD   HL, PROMPT					; change the prompt
		LD   (HL), A

		RET

.do_select_B:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		LD   B, 1
		LD   C, 18
		CALL $0005

		OR   A
		JR   NZ, .err_select_drive      ; if failed, don't change the prompt

		LD   A, $42
		LD   HL, PROMPT					; change the prompt
		LD   (HL), A
		
		RET

.do_select_C:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		LD   B, 2
		LD   C, 18
		CALL $0005

		OR   A
		JR   NZ, .err_select_drive      ; if failed, don't change the prompt

		LD   A, $43
		LD   HL, PROMPT					; change the prompt
		LD   (HL), A
		
		RET

.do_select_D:

		LD   A, 1
		LD   (LAST_INTERNAL_CMD_SUCCESS), A

		LD   B, 3
		LD   C, 18
		CALL $0005

		OR   A
		JR   NZ, .err_select_drive      ; if failed, don't change the prompt

		LD   A, $44
		LD   HL, PROMPT					; change the prompt
		LD   (HL), A
		
		RET

.err_select_drive:

		RET

; =====================================================================
;
;  Dispatch Transient Commands
;
; =====================================================================
DISPATCH_TRANSIENT_COMMANDS:
		
		; Check if Arg0 is a valid .COM command
		LD   HL, ARG0
		CALL IS_DOT_COM

		OR   A
		JR   NZ, .err_opening_file

		; ------------------------------------------------------------
		; Process the command here
		; ------------------------------------------------------------
.process:
		; Open the .COM file
		LD   DE, ARG0
		LD   C, 33
		CALL $0005
		OR   A
		JR   NZ, .bad_command

		; ------------------------------------------------------------
		; READ it into $0100
		; ------------------------------------------------------------

		; Get the exact file size (up to 64KB, which is enough)
		
		LD   DE, SCRATCH_4_BYTE  
		LD   C, 42               ; Obtain file size by calling
		CALL $0005               ; SYS_FS_FILE_SIZE
		
		LD   HL, (SCRATCH_4_BYTE) ; HL = 16-bit file size
        LD   A, H
        OR   L
        JR   Z, .read_done       ; If size is 0 bytes, nothing to load

		LD   DE, $0100           ; DE = Destination buffer
        LD   C, 34               ; C  = SYS_FS_READ syscall
        CALL $0005

		; A = 0 (Success) or 1 (EOF). Both are completely fine here.
        CP   $FF
        JR   Z, .err_reading_file  ; Real read error

.read_done:
		; -----------------------------
        ; CLOSE file
        ; -----------------------------
        LD   C, 35
        CALL $0005

		; Reset stack pointer first
		LD   SP, $FFF0

		; -----------------------------
		; Execute it!
		; -----------------------------
		JP   $0100

.bad_command:
		LD   DE, MSG_BAD_CMD_OR_PROGRAM
		LD   C, 3
		CALL $0005
		RET

.err_opening_file:
		
		; Try to append .COM into Arg0
		LD   HL, ARG0
		CALL STR_SEEK_END
		LD   (HL), $2E					; period
		INC  HL
		LD   (HL), $43					; C
		INC  HL
		LD   (HL), $4F					; O
		INC  HL					
		LD   (HL), $4D					; M
		INC  HL
		LD   (HL), 0					; NULL

		; CALL IS_DOT_COM
		LD   HL, ARG0
		CALL IS_DOT_COM

		; If yes, open it, then proceed
		OR   A
		JR   NZ, .bad_command
		JR   .process

.err_reading_file:
		LD   DE, MSG_CMD_READ_FAIL
		LD   C, 3
		CALL $0005
		RET

; =====================================================================
; CCP Data Section
; =====================================================================

BUFFER:
		DS 64, 0
PROMPT:
		DB "A>",0
MSG_BAD_CMD_OR_PROGRAM:
		DB "Unknown command or program",13,10,0
MSG_CMD_OPEN_FAIL:
		DB "Can't open the .COM file",13,10,0
MSG_CMD_READ_FAIL:
		DB "Can't read the .COM file",13,10,0
LAST_INTERNAL_CMD_SUCCESS:							; Does last internal command executed successfully?
		DB 0


CMD_NAME_DIR:
		DB "DIR",0
CMD_NAME_EXIT:
		DB  "EXIT",0
CMD_NAME_TYPE:
		DB  "TYPE",0
CMD_NAME_DELETE:
		DB  "DEL",0
CMD_NAME_CREATE:
		DB   "CREATE",0
CMD_NAME_RENAME:
		DB   "REN",0


CMD_NAME_A:
		DB "A:",0
CMD_NAME_B:
		DB "B:",0
CMD_NAME_C:
		DB "C:",0
CMD_NAME_D:
		DB "D:",0


SCRATCH_BUF1:
		DS 128, 0                     	; Used by: TYPE
SCRATCH_4_BYTE:
		DS 4, 0                         ; 32-bit counter used by TYPE


MSG_MISSING:
		DB "Missing filename",13,10,0	; Used by: TYPE
MSG_OPEN_FAIL:
		DB "File not found",13,10,0		; Used by: TYPE, DEL
MSG_READ_ERROR:
		DB "Read error",13,10,0			; Used by: TYPE


MSG_DEL_SUCCESS:
		DB "File deleted",13,10,0
MSG_DEL_OPEN_FILE:
		DB "Can't delete open file",13,10,0


MSG_CREATE_SUCCESS:
		DB "File created",13,10,0
MSG_CREATE_ERR_FILENAME:
		DB "File with same name already exists",13,10,0
MSG_CREATE_ERR_DIR_FULL:
		DB "Too many files!",13,10,0
MSG_CREATE_ERR_DISK_FULL:
		DB "Storage full!",13,10,0


MSG_RENAME_ERR_MISSING_OLD_FILENAME:
		DB "Missing old filename",13,10,0
MSG_RENAME_ERR_MISSING_NEW_FILENAME:
		DB "Missing new filename",13,10,0
MSG_RENAME_SUCCESS:
		DB "File renamed",13,10,0
MSG_RENAME_ERR_NEW_NAME_EXIST:
		DB "New file name already exists",13,10,0
MSG_RENAME_ERR_OLD_FILE_NOT_FOUND:
		DB "Old file not found",13,10,0
MSG_RENAME_ERR_OPEN_FILE:
		DB "Can't rename open file",13,10,0
MSG_RENAME_EMPTY_DIR:
		DB "Directory empty! Where's CCP.COM?!",13,10,0


; ===============================================
; CCP Helper subroutines
; ===============================================

; ---------------------------------------------------------
; COPY_WORD
; Input:  DE = Source address (NULL-terminated string)
;         HL = Destination address
; Output: HL = Points to the character after the copied word 
;              in the destination.
;         DE = Points to the start of the next word in source.
; ---------------------------------------------------------

COPY_WORD:
    ; --- Phase 1: Skip leading spaces ---
.skip_leading:
    LD   A, (DE)
    CP   0            ; Check for end of string
    RET  Z           ; If NULL, nothing to copy
    CP   ' '          ; Is it a space?
    JR   NZ, .start_copy
    INC  DE          ; Skip the space
    JR   .skip_leading

    ; --- Phase 2: Copy characters ---
.start_copy:
    LD    A, (DE)
    CP    0            ; End of string?
    JR    Z, .terminate
    CP    ' '          ; End of word?
    JR    Z, .found_space
    
    LD    (HL), A      ; Copy byte
    INC   HL
    INC   DE
    JR    .start_copy

.found_space:
    ; --- Phase 3: Finalize and position DE ---
    ; We found a space. We need to skip any trailing spaces 
    ; so DE points exactly to the start of the NEXT word.
    INC   DE          ; Move past the space we just found
.skip_trailing:
    LD    A, (DE)
    CP    ' '
    JR    NZ, .terminate
    INC   DE
    JR    .skip_trailing

.terminate:
    LD    (HL), 0      ; NULL-terminate the destination string
    RET

; CLEAR_ARG
; HL = Pointer to arg
; Clobber: B, H, L
CLEAR_ARG:
		LD   B, 16
.loop:
		LD   (HL), 0
		INC  HL
		DEC  B
		DJNZ .loop
		RET

; Check whether a null-terminated string contains ".COM"
; Input:
; HL = Pointer to string
; Output:
; A = 0  (.COM found)
; A = FF (.COM not found)
; Clobbers A, HL
IS_DOT_COM:
.search_loop:
        LD   A, (HL)
        OR   A                  ; Check for null terminator ($00)
        JR   Z, .not_found      ; If zero, we reached the end of the string

        CP   $2E                ; Check for '.'
        JR   NZ, .next_char

        ; Period found, bookmark our current position in HL
        PUSH HL

        INC  HL
        LD   A, (HL)
        CP   $43                ; Exact match for 'C'?
        JR   NZ, .mismatch

        INC  HL
        LD   A, (HL)
        CP   $4F                ; Exact match for 'O'?
        JR   NZ, .mismatch

        INC  HL
        LD   A, (HL)
        CP   $4D                ; Exact match for 'M'?
        JR   NZ, .mismatch

        ; ".COM" exact match found!
        POP  HL                 ; Clean up the stack
        XOR  A                  ; Set A = 0 (and sets Zero flag)
        RET

.mismatch:
        POP  HL                 ; Restore HL back to the period we just checked
.next_char:
        INC  HL                 ; Move to the next character in the string
        JR   .search_loop

.not_found:
        LD   A, $FF             ; Return FF
        RET

; STR_SEEK_END
; Input = HL
; Output = HL will points to the end of string + 1 (the NULL byte)
STR_SEEK_END:
		LD   A, (HL)
		OR   A
		JR   NZ, .not_null
		JR   .done
.not_null:
		INC  HL
		JR   STR_SEEK_END
.done:
		RET