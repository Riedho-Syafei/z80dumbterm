#include <stdio.h>
#include <stdint.h>

FILE *printer_file;

void printer_write(uint8_t value) {
	fputc(value, printer_file);
}