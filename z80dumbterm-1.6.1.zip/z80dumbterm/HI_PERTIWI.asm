		ORG $0100

START:
		; -----------------------------
        ; OPEN the PERTIWI.LIB library
        ; -----------------------------
        LD   C, 33
        LD   DE, LIB_FILENAME
        CALL $0005
        OR   A
        JR   NZ, error           ; Open failed

        ; -----------------------------
        ; Get exact file size in bytes
        ; -----------------------------
		LD   DE, FILE_SIZE
		LD   C, 42
		CALL $0005

		LD   HL, (FILE_SIZE)

		LD   A, H
		OR   L
		JR   Z, read_done			; If size is 0 bytes, nothing to load

        ; -----------------------------
        ; READ entire file in one call
        ; -----------------------------
        LD   DE, $C000           ; DE = Destination buffer
        LD   C, 34               ; C  = SYS_FS_READ syscall
        CALL $0005
        
        ; A = 0 (Success) or 1 (EOF). Both are completely fine here.
        CP   $FF
        JR   Z, error            ; Real read error

read_done:
        ; -----------------------------
        ; CLOSE file
        ; -----------------------------
        LD   C, 35
        CALL $0005

		; --------------------------------------------------------
		; Print a simple "Hello World" at the center of the screen
		; --------------------------------------------------------
		CALL $C015					; Clear screen first
		
		LD   B, 28
		LD   C, 12
		LD   HL, HELLO
		CALL $C01A


error:
        ; handle error
        JP   $003B				; exit early

LIB_FILENAME:
        DB "PERTIWI.LIB",0

FILE_SIZE:
		DS 4,0

HELLO:
		DB "Hello from Pertiwi-8bit!",13,10,0