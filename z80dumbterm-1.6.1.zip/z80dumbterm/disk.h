/* disk.h */
#ifndef DISK_H
#define DISK_H

#include <stdint.h>

#define TRACKS 77
#define SECTORS_PER_TRACK 26
#define BYTES_PER_SECTOR 128

// Add these variables to your emulator state
extern FILE **active_disk_file;   // The "selected" disk image file
extern FILE *disk_file_A;           // The disk image file
extern FILE *disk_file_B;           // The disk image file
extern FILE *disk_file_C;           // The disk image file
extern FILE *disk_file_D;           // The disk image file
extern int disk_track;        // Current track requested by Z80
extern int disk_sector;       // Current sector requested by Z80
extern int disk_dma;       // Where in Z80 RAM to put the data (default 0x0080)
extern int disk_command;   // Last command received
extern int disk;			// 0=A: 1=B: ...

void disk_read_sector(FILE **active_disk_file);
void disk_write_sector(FILE **active_disk_file);


#endif