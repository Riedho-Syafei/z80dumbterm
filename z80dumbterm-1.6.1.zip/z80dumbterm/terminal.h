#ifndef TERMINAL_H
#define TERMINAL_H

#include <SDL3/SDL.h>

#define TERM_COLS 80
#define TERM_ROWS 25
#define CHAR_W 8
#define CHAR_H 10

typedef enum {
    ESC_NONE,
    ESC_SEEN,
    ESC_CSI
} esc_state_t;

typedef struct {
    uint8_t cells[TERM_ROWS][TERM_COLS];
	uint8_t line_len[TERM_ROWS];
	int cx, cy;

	esc_state_t esc_state;
    int esc_params[4];
    int esc_count;

	bool cursor_visible;
    uint32_t last_blink;
} Terminal;

extern Terminal term;
extern const uint8_t font8x8[96][8];

void terminal_reset(void);
static void terminal_scroll(void);
void terminal_put_char(uint8_t ch);
void terminal_init();
void draw_char(SDL_Renderer *r, int x, int y, uint8_t ch);
void terminal_render(SDL_Renderer *r);
void terminal_update_cursor(void);
void terminal_draw_cursor(SDL_Renderer *r);
static void esc_reset(void);
void terminal_handle_csi(uint8_t cmd);
void terminal_clear(void);
void terminal_clear_home(void);

#endif