; ------------------------------------------------------------------
; PERTIWI.LIB
; This is a hardware library intended for the PERTIWI microcomputers
; 
; It includes routines to draw to the terminal, etc
; ------------------------------------------------------------------

CR EQU $0D
LF EQU $0A
TERM_WIDTH EQU 80
TERM_HEIGHT EQU 25
		
		ORG $C000

JMPTABL:
		JP   term_putc				; $C000
		JP   term_puts				; $C003
		JP   term_cursorUp			; $C006
		JP   term_cursorLeft		; $C009
		JP   term_cursorDown		; $C00C
		JP   term_cursorRight		; $C00F
		JP   term_setCursorPos      ; $C012
		JP   term_clear				; $C015
		JP   term_getCursorPos		; $C018
		JP   term_puts_at			; $C01A


; HL = pointer to zero-terminated string
term_puts:
.loop
    LD A,(HL)
    OR A
    RET Z

    CALL term_putc
    INC HL
    JR .loop

;
; Input  = B : X pos
;          C : Y pos
; Output = A : Status (0 = OK)
;
term_setCursorPos:

		CALL term_esc

		LD   A, C
		PUSH BC
    	CALL term_print_byte_decimal
		POP  BC

    	LD   A, ';'
    	CALL term_putc

    	LD   A, B
		PUSH BC
    	CALL term_print_byte_decimal
		POP  BC

    	LD   A, 'H'
    	CALL term_putc

		LD   A, B
		LD   (CURSOR_X), A
		LD   A, C
		LD   (CURSOR_Y), A

		XOR  A

		RET

term_clear:
    	CALL term_esc
    	LD   A,'J'
    	CALL term_putc
    	RET

term_cursorUp:
		CALL term_esc
		LD   A, 'A'
		CALL term_putc
		RET

term_cursorLeft:
		CALL term_esc
		LD   A, 'D'
		CALL term_putc
		RET

term_cursorDown:
		CALL term_esc
		LD   A, 'B'
		CALL term_putc
		RET

term_cursorRight:
		CALL term_esc
		LD   A, 'C'
		CALL term_putc
		RET

; Output: B = X pos
;         C = Y pos
term_getCursorPos:
		LD   A, (CURSOR_X)
		LD   B, A
		LD   A, (CURSOR_Y)
		LD   C, A
		RET

; B = x
; C = y
; HL = string
term_puts_at:
    PUSH HL
    CALL term_setCursorPos
    POP HL
    JP term_puts

; ------------------------------------------------------------------
; Primitive functions
; ------------------------------------------------------------------

; A = char
term_putc:
        PUSH AF                 ; Preserve the original character
        
        OUT  ($01), A           ; Send the character to the terminal immediately

        ; --- Intercept Control Characters ---
        CP   CR
        JR   Z, .handle_cr      ; If A == Carriage Return, update X
        CP   LF
        JR   Z, .handle_lf      ; If A == Line Feed, update Y
        
        ; --- Standard Visible Character Handling ---
        LD   A, (CURSOR_X)
        INC  A
        LD   (CURSOR_X), A      ; CURSOR_X++

        CP   TERM_WIDTH + 1     ; IF CURSOR_X <= TERM_WIDTH
        JR   C, .done           ;    Skip wrap logic and exit

.wrap_around:
        LD   A, 1
        LD   (CURSOR_X), A      ; Reset CURSOR_X = 1
        
        ; Fall through directly into Line Feed handling!
        ; A physical wrap is essentially a Carriage Return + Line Feed.

.handle_lf:
        LD   A, (CURSOR_Y)
        INC  A
        LD   (CURSOR_Y), A      ; CURSOR_Y++

        CP   TERM_HEIGHT + 1    ; IF CURSOR_Y <= TERM_HEIGHT
        JR   C, .done           ;    Skip max_y clamping and exit

.max_y_reached:
        LD   A, TERM_HEIGHT
        LD   (CURSOR_Y), A      ; Clamp CURSOR_Y to TERM_HEIGHT
        JR   .done

.handle_cr:
        LD   A, 1
        LD   (CURSOR_X), A      ; Reset CURSOR_X = 1

.done:
        POP  AF                 ; Restore original character and flags
        RET

term_esc:
		LD   A, 27				; ESC char
		CALL term_putc

		LD   A, 91				; Open bracket '['
		CALL term_putc

		RET

; A = Decimal value between 0 - 255
; Clobbers: A, B
term_print_byte_decimal:
		ld b, '0'         ; Start ASCII hundreds at '0'
.HundredsLoop:
    	cp 100            ; Is A >= 100?
    	jr c, .DoneHundreds
    	sub 100           ; Subtract 100
    	inc b             ; Increment hundreds digit
    	jr .HundredsLoop
.DoneHundreds:
		push af
		ld a, b				; Print hundreds
		CALL term_putc		;
		pop af

    	ld b, '0'         ; Start ASCII tens at '0'
.TensLoop:
    	cp 10             ; Is A >= 10?
    	jr c, .DoneTens
    	sub 10            ; Subtract 10
    	inc b             ; Increment tens digit
    	jr .TensLoop
.DoneTens:
    	push af
		ld a, b				; Print tens
		CALL term_putc		;
		pop af
    

    	add a, '0'        ; The remainder is the ones digit
    	CALL term_putc		; Print ones
		RET


; ------------------------------------------------------------------
; Data section
; ------------------------------------------------------------------
SCRATCH1: DW 0
SCRATCH2: DW 0

CURSOR_X: DB 0
CURSOR_Y: DB 0
