		; PAGE ZERO
		ORG $0000
		JP WBOOT
		DB 0		; IO BYTE
		DB 0		; Current drive/user
		JP BDOS

		BLOCK $005C - $, 0
		ORG $005C
FCB01:	DB 0		; Drive code
		DS 8		; File name
		DS 3		; File extension
		DB 0		; Extent counter
		DB 0		; Reserved
		DB 0		; Reserved
		DB 0		; Record count
		DS 16		; Disk map
		DB 0		; Current record
		DS 3		; Random record


		BLOCK $0080 - $, 0
		ORG $0080
DMAADR: DW 0
		
		; ====================================================
		; CCP - Minimal CCP that prints 'A>' and echoes INPUT?
		; ====================================================
			BLOCK $1000 - $, 0
			ORG $1000
CCP:
CCP_IMAGE:	LD SP, CCP_STACK

			; Print prompt 'A>'
CCP_LOOP:	LD DE, PROMPT
			LD C, $09
			CALL $0005

			; Read console buffer
			LD DE, INPUT_BUF
			LD C, $0A
			CALL $0005

			CALL NEWLINE

			CALL PARSE_AND_DISPATCH

			JP CCP_LOOP

; ============ DATA SECTION OF CCP =============================

PROMPT: DB 'A'
		DB '>'
		DB '$'

INPUT_BUF:	DB 80
			DB 0
			DS 80

			DS 80
CCP_STACK	EQU $


CMD_PTR:    DW 0
CMD_EXIT:   DB 'EXIT',0

; ============ MISC FUNCTIONS ===================================

NEWLINE:	; Print newline
			LD E, $0D
			LD C, $02
			CALL $0005

			LD E, $0A
			LD C, $02
			CALL $0005

			RET

; ============ PARSE AND DISPATCH =================================

PARSE_AND_DISPATCH:
			CALL NORMALIZE_LINE
			CALL SKIP_SPACES
			CALL DISPATCH
			RET

NORMALIZE_LINE:
			LD HL, INPUT_BUF+1
            LD B, (HL)
            INC HL              ; HL -> first char
NORM_LOOP:
            LD A, B
            OR A
            RET Z

            LD A, (HL)
            CP 'a'
            JR C, NORM_NEXT
            CP 'z'+1
            JR NC, NORM_NEXT
            AND 5Fh
            LD (HL), A
NORM_NEXT:
            INC HL
            DEC B
            JR NORM_LOOP
SKIP_SPACES:
            LD HL, INPUT_BUF+2

SKIP_LOOP:
            LD A, (HL)
            CP ' '
            JR NZ, SKIP_DONE
            INC HL
            JR SKIP_LOOP

SKIP_DONE:
            LD (CMD_PTR), HL
            RET

DISPATCH:
            LD HL, (CMD_PTR)

            ; EXIT
            LD DE, CMD_EXIT
            CALL CMP_CMD
            JP Z, DO_EXIT

            ; fallback = echo + '?'
            CALL ECHO_WITH_Q
            RET

; ================= UNKNOWN COMMAND ============================

ECHO_WITH_Q:
            LD HL, INPUT_BUF+1
            LD B, (HL)
            INC HL

ECHO_LOOP:
            LD A, B
            OR A
            JR Z, ECHO_DONE

            LD A, (HL)
            LD E, A
            LD C, $02
            CALL $0005

            INC HL
            DEC B
            JR ECHO_LOOP

ECHO_DONE:
            LD E, '?'
            LD C, $02
            CALL $0005
            CALL NEWLINE
            RET

; ======================== STRING COMPARE HELPER =======================

CMP_CMD:
CMP_CMD_LOOP:
            LD A, (DE)
            OR A
            RET Z
            CP (HL)
            RET NZ
            INC HL
            INC DE
            JR CMP_CMD_LOOP

; ======================= EXIT COMMAND ===================================

DO_EXIT:
            JP 0000h     ; warm boot

; ========================================================================

TEST_FCB:
    DB 0              ; drive
    DB 'HELLO   '      ; filename (8)
    DB 'COM'           ; extension (3)
    DS 21              ; rest of FCB


CCP_END:	DB 0

CCP_BASE: EQU $E400
CCP_SIZE: EQU CCP_END - CCP

LOAD_CCP:		LD HL,CCP_IMAGE
				LD DE,CCP_BASE
				LD BC,CCP_SIZE
LOAD_CCP_LOOP:	LD A,(HL)
				LD (DE),A
				INC HL
				INC DE
				DEC BC
				LD A,B
				OR C
				JP NZ,LOAD_CCP_LOOP
				RET

; ==========================================================================
; 		BDOS
; ==========================================================================
		BLOCK $EC00 - $, 0
		ORG $EC00
BDOS:	PUSH BC
		PUSH DE
		PUSH HL

		LD A,C

		CP $00
		JP Z, BDOS_RESET

		CP $01
		JP Z, BDOS_CONIN

		CP $02
		JP Z, BDOS_CONOUT

		CP $09
		JP Z, BDOS_PT_STR

		CP $0A
		JP Z, BDOS_RD_BUF

		CP $0F
		JP Z, BDOS_OPENFILE

		LD A, $FF
		JP BDOS_EXIT

BDOS_EXIT:	POP HL
			POP DE
			POP BC
			RET
		
; ========================================================================
; 		BDOS IMPLEMENTATION
; ========================================================================

BDOS_RESET:	JP WBOOT

; ========================================================================

BDOS_CONIN:	CALL CONIN
			CP $03		; Is it Ctrl+C ?
			JP Z,BDOS_ABORT
			JP BDOS_EXIT

; ========================================================================

BDOS_CONOUT:	LD A,E
				CALL CONOUT
				JP BDOS_EXIT

; ========================================================================

BDOS_PT_STR:	LD H,D
				LD L,E
BDOS_PS_LOOP:	LD A,(HL)
				CP '$'
				JP Z, BDOS_PS_DONE
				CALL CONOUT
				INC HL
				JP BDOS_PS_LOOP
BDOS_PS_DONE:	LD A, $00
				JP BDOS_EXIT

; ========================================================================

BDOS_RD_BUF:	LD H,D
				LD L,E
				LD B,(HL)
				LD C, $00
				INC HL
				INC HL
BDOS_RB_LOOP:	CALL CONIN
				CP $03		; Is it Ctrl+C ?
				JP Z,BDOS_ABORT
				CP $0A		; ENTER on SDL3
				JP Z,BDOS_RB_DONE
				CALL CONOUT
				LD (HL),A
				INC C
				INC HL
				LD A,C
				CP B
				JP NC, BDOS_RB_DONE
				JP BDOS_RB_LOOP
BDOS_RB_DONE:	LD H,D
				LD L,E
				INC HL
				LD (HL),C
				JP BDOS_EXIT

; ========================================================================

BDOS_OPENFILE:	; Save FCB pointer
            	LD      (FCB_PTR), DE

            	; Read directory into DIR_BUF
            	CALL    READ_DIRECTORY

            	; Scan directory entries
            	CALL    FIND_DIR_ENTRY

        		; If not found, A = FFh already
            	JP BDOS_EXIT

READ_DIRECTORY:
            	LD      HL, DIR_BUF        ; destination pointer
            	LD      B, 16              ; 16 sectors

            	LD      C, 1               ; starting sector (1)

READ_DIR_LOOP:
            	PUSH    BC
            	PUSH    HL

            	; SETTRK 1
            	LD      BC, 1
            	CALL    SETTRK

            	; SETSEC C
            	LD      B, 0
            	CALL    SETSEC

            	; SETDMA HL
            	LD      B, H
            	LD      C, L
            	CALL    SETDMA

            	; READ
            	CALL    READ

            	POP     HL
            	POP     BC

            	; advance buffer
            	LD      DE, 128
            	ADD     HL, DE

            	INC     C
            	DJNZ    READ_DIR_LOOP

            	RET

FIND_DIR_ENTRY:	LD      HL, DIR_BUF
            	LD      B, 64              ; 64 entries

DIR_SCAN_LOOP:
            	PUSH    BC
            	PUSH    HL

            	; Check user number
            	LD      A, (HL)
            	CP      0
            	JR      NZ, NEXT_ENTRY

            	; Compare filename
            	CALL    MATCH_FILENAME
            	JR      Z, ENTRY_FOUND

NEXT_ENTRY:
	            POP     HL
    	        POP     BC
        	    LD      DE, 32
            	ADD     HL, DE
            	DJNZ    DIR_SCAN_LOOP

            	; Not found
            	LD      A, 0FFh
            	RET

MATCH_FILENAME:
	            ; HL = directory entry
    	        ; FCB pointer stored in FCB_PTR

        	    LD      DE, (FCB_PTR)

            	INC     HL          ; HL → dir name
            	INC     DE          ; DE → fcb name

            	LD      B, 11

CMP_FILENAME_LOOP:
            	LD      A, (DE)
            	CP      (HL)
            	JR      NZ, CMP_FAIL
            	INC     HL
            	INC     DE
            	DJNZ    CMP_FILENAME_LOOP

            	XOR     A           ; Z = 1
            	RET

CMP_FAIL:
            	OR      1           ; Z = 0
            	RET

ENTRY_FOUND:
    	        POP     HL          ; restore HL = entry
	            POP     BC

        	    ; Copy bytes 12–31 (20 bytes)
    	        LD      DE, (FCB_PTR)

	            LD      BC, 12
        	    ADD     HL, BC
    	        ADD     DE, BC

	            LD      B, 20

COPY_LOOP:
            	LD      A, (HL)
            	LD      (DE), A
            	INC     HL
            	INC     DE
            	DJNZ    COPY_LOOP

        	    ; Success
    	        XOR     A
	            RET


; =========================================================================

BDOS_ABORT:		JP $0000		; Warm boot

;============== BDOS DATA SECTION =========================================

		; sector size = 128
		; sectors / track = 26
		; N of tracks = 77
		; block size = 1024
		; directory size = 64

DIR_BUF:    DS 2048      ; directory buffer (16 * 128)
FCB_PTR:    DW 0         ; saved DE from caller

; =========================================================================
; 		BIOS JUMP TABLE
; =========================================================================
		BLOCK $FA00 - $, 0
		ORG $FA00
		JP BOOT
		JP WBOOT
		JP CONST
		JP CONIN
		JP CONOUT
		JP LIST
		JP PUNCH
		JP READER
		JP HOME
		JP SELDSK
		JP SETTRK
		JP SETSEC
		JP SETDMA
		JP READ
		JP WRITE
		JP LISTST
		JP SECTRAN

; ===========================================================================
; 		BIOS IMPLEMENTATION
; ===========================================================================
BOOT:	LD SP, $FFFF
		XOR A
		LD (CURDSK), A
		JP WBOOT

WBOOT:	; reset default drive/user

		; reset DMA adress to 0080h
		LD HL, $0080
		LD (DMAADR), HL ; CALL SETDMA (nanti diganti)

		CALL LOAD_CCP
		
		JP CCP_BASE

CONST:	LD A, $00
		RET

CONIN:	IN A,$01
		CP $00
		JP Z, CONIN
		RET

CONOUT:	OUT $01,A
		RET

LIST:	RET
PUNCH:	RET
READER:	LD A, $1A
		RET
LISTST:	XOR A
		RET

HOME:	LD A, 0
    	OUT (15h), A    ; Command 0 = Home
    	RET
SELDSK: ; C contains disk number (0=A, 1=B)
    	LD A, C
    	OUT (17h), A    ; Port 17h = Select disk
    	; Return HL=0 (no error/DPH)
    	LD HL, 0
    	RET

DPH:	DW $AB90	; XLT
		DW $0000	
		DW $0000	
		DW $ABA0	; DIRBUF
		DW $AB80	; DPB
		DW $ABB0	; CSV
		DW $ABC0	; ALV

SETTRK:	 ; BC contains track number (16-bit)
    	LD A, C
    	OUT (10h), A    ; Track low byte
    	LD A, B
    	OUT (11h), A    ; Track high byte
    	RET
SETSEC:	; C contains sector (8-bit)
    	LD A, C
    	OUT (12h), A
    	RET
SETDMA:	; BC contains DMA address
    	LD A, C
    	OUT (13h), A    ; DMA low
    	LD A, B
    	OUT (14h), A    ; DMA high
    	RET

READ:	LD A, 1
    	OUT (15h), A    ; Command 1 = Read
    	IN A, (16h)     ; Read status (0=OK) into A
    	RET
WRITE:	LD A, 2
    	OUT (15h), A    ; Command 2 = Write  
    	IN A, (16h)     ; Read status into A
    	RET

SECTRAN: RET

DPB:	DW $6026	; SPT (sectors per track)
		DB $03		; BSH
		DB $07		; BLM
		DB $00		; EXM
		DW $60F2	; DSM
		DW $603F	; DRM
		DB $C0		; AL0
		DB $00		; AL1
		DW $6010	; CKS
		DW $6002	; OFF

		
	; BIOS DATA AREA
CURDSK:	DB 0
CURTRK:	DW 0
CURSEC: DB 0
		