What's new:
Added a hardware library for the microcomputer, PERTIWI.LIB
Added a test program HI_PERTIWI.COM

1.6.1:
Caps lock works properly now!

CCP Version 1.0.0

CCP supported commands:

internal commands:
DIR
TYPE <filename>
EXIT
CREATE <filename>
DEL <filename>
REN <old filename> <new filename>

transient commands:
DISKSPACE [drive letter]
COPYTO [src drive letter, dest drive letter] [src filename] [dest filename]
