#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void load_minimal_cpm(uint8_t *memory) {
    //memset(memory, 0, 65536);
    
    /*	================================================
		PAGE ZERO
		================================================  */
	
	int addr = 0x0000;
	memory[addr++] = 0xC3;  memory[addr++] = 0x00;  memory[addr++] = 0xFA;  // JP BIOS WBOOT
	addr = 0x0005;
	memory[addr++] = 0xC3;  memory[addr++] = 0x00;  memory[addr++] = 0xEC;  // JP BDOS ENTRY
	
	// FCB #1
	addr = 0x005C;    // 005C - 006B
	memory[addr++] = 0x00;

	// FCB #2
	addr = 0x006C;    // 006C - 007B
	memory[addr++] = 0x00;

	// Default DMA buffer (owned by BDOS)
	addr = 0x0080;    // 0080 - 00FF
	memory[addr++] = 0x00;
	
	/*  =================================================
		BIOS Jump table
	    =================================================  */  

	addr = 0xFA00;
	// BOOT
	memory[addr++] = 0xC3;  memory[addr++] = 0x40;  memory[addr++] = 0xFA;
	// WBOOT
	memory[addr++] = 0xC3;  memory[addr++] = 0x50;  memory[addr++] = 0xFA;
	// CONST
	memory[addr++] = 0xC3;  memory[addr++] = 0x58;  memory[addr++] = 0xFA;
	// CONIN
	memory[addr++] = 0xC3;  memory[addr++] = 0x60;  memory[addr++] = 0xFA;
	// CONOUT
	memory[addr++] = 0xC3;  memory[addr++] = 0x68;  memory[addr++] = 0xFA;
	// LIST
	memory[addr++] = 0xC3;  memory[addr++] = 0x70;  memory[addr++] = 0xFA;
	// PUNCH
	memory[addr++] = 0xC3;  memory[addr++] = 0x80;  memory[addr++] = 0xFA;
	// READER
	memory[addr++] = 0xC3;  memory[addr++] = 0x90;  memory[addr++] = 0xFA;
	// HOME
	memory[addr++] = 0xC3;  memory[addr++] = 0xB0;  memory[addr++] = 0xFA;
	// SELDSK
	memory[addr++] = 0xC3;  memory[addr++] = 0xC0;  memory[addr++] = 0xFA;
	// SETTRK
	memory[addr++] = 0xC3;  memory[addr++] = 0x20;  memory[addr++] = 0xFB;
	// SETSEC
	memory[addr++] = 0xC3;  memory[addr++] = 0x30;  memory[addr++] = 0xFB;
	// SETDMA
	memory[addr++] = 0xC3;  memory[addr++] = 0x40;  memory[addr++] = 0xFB;
	// READ
	memory[addr++] = 0xC3;  memory[addr++] = 0x50;  memory[addr++] = 0xFB;
	// WRITE
	memory[addr++] = 0xC3;  memory[addr++] = 0x60;  memory[addr++] = 0xFB;
	// LISTST
	memory[addr++] = 0xC3;  memory[addr++] = 0xA0;  memory[addr++] = 0xFA;
	// SECTRAN
	memory[addr++] = 0xC3;  memory[addr++] = 0x70;  memory[addr++] = 0xFB;

	


	/*  ===============================================
		BIOS data area
	    ===============================================  */
	
	addr = 0xFA34;
	// CURDSK: DEFB 0
	memory[addr++] = 0x00;
	// CURTRK: DEFW 0
	memory[addr++] = 0x00;  memory[addr++] = 0x00;
	// CURSEC: DEFB 0
	memory[addr++] = 0x00;
	// DMAADR: DEFW 0
	memory[addr++] = 0x00;  memory[addr++] = 0x08;


	

	/*
		BIOS Implementation
	*/

	// BOOT
	addr = 0xFA40;
	memory[addr++] = 0x31;  memory[addr++] = 0xFF;  memory[addr++] = 0xFF;  // safe stack at 0xFFFF
	memory[addr++] = 0xAF;
	memory[addr++] = 0x32;  memory[addr++] = 0x34;  memory[addr++] = 0xFA;
	//    jump to CCP entry
	memory[addr++] = 0xC3;  memory[addr++] = 0x00;  memory[addr++] = 0xE4;

	// WBOOT
	addr = 0xFA50;
	memory[addr++] = 0xC3;  memory[addr++] = 0x00;  memory[addr++] = 0xE4;  // jump to BDOS

	// CONST
	addr = 0xFA58;
	memory[addr++] = 0x3E;  memory[addr++] = 0x01;
	memory[addr++] = 0xC9;

	// BIOS_CONIN
	addr = 0xFA60;
	memory[addr++] = 0xDB;  memory[addr++] = 0x01;  // IN 01
	memory[addr++] = 0xFE;  memory[addr++] = 0x00;  // Is A = 0?
	memory[addr++] = 0xCA;  memory[addr++] = 0x60;  memory[addr++] = 0xFA;  // If yes, loop
	memory[addr++] = 0xC9;

	// BIOS_CONOUT
	addr = 0xFA68;
	memory[addr++] = 0xD3;  memory[addr++] = 0x01;	// OUT 01
	memory[addr++] = 0xC9;

	// Unused console devices (stub)
	
	// LIST:
	addr = 0xFA70; memory[addr] = 0xC9;
	// PUNCH:
	addr = 0xFA80; memory[addr] = 0xC9;
	// READER:
	addr = 0xFA90; memory[addr] = 0xC9;
	// LISTST:
	addr = 0xFAA0; memory[addr++] = 0xAF;  memory[addr++] = 0xC9;

	// HOME
	addr = 0xFAB0;
	memory[addr++] = 0x3E;  memory[addr++] = 0x07;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xC9;

	// SELDSK
	addr = 0xFAC0;
	memory[addr++] = 0x3E;  memory[addr++] = 0x01;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xC9;

	// DPH table (will be 4 disk)
	addr = 0xFAE0;
	memory[addr++] = 0x90;  memory[addr++] = 0xAB;		// XLT
	memory[addr++] = 0x00;  memory[addr++] = 0x00;
	memory[addr++] = 0x00;  memory[addr++] = 0x00;
	memory[addr++] = 0xA0;  memory[addr++] = 0xAB;		// DIRBUF
	memory[addr++] = 0x80;  memory[addr++] = 0xAB;		// DPB
	memory[addr++] = 0xB0;  memory[addr++] = 0xAB;		// CSV
	memory[addr++] = 0xC0;  memory[addr++] = 0xAB;		// ALV

	// SETTRK
	addr = 0xFB20;
	memory[addr++] = 0x3E;  memory[addr++] = 0x02;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xC9;

	// SETSEC
	addr = 0xFB30;
	memory[addr++] = 0x3E;  memory[addr++] = 0x03;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xC9;

	// SETDMA
	addr = 0xFB40;
	memory[addr++] = 0x3E;  memory[addr++] = 0x04;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xC9;
	
	// READ
	addr = 0xFB50;
	memory[addr++] = 0x3E;  memory[addr++] = 0x05;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xFE;  memory[addr++] = 0x00;
	memory[addr++] = 0xC9;

	// WRITE
	addr = 0xFB60;
	memory[addr++] = 0x3E;  memory[addr++] = 0x06;
	memory[addr++] = 0xD3;  memory[addr++] = 0x10;
	memory[addr++] = 0xFE;  memory[addr++] = 0x00;
	memory[addr++] = 0xC9;

	// SECTRAN
	addr = 0xFB70;
	memory[addr++] = 0x60;  
	memory[addr++] = 0x69;  
	memory[addr++] = 0xC9;  

	// DPB table
	addr = 0xFB80;
	memory[addr++] = 26;  memory[addr++] = 0x60;  // SPT (sectors per track)
	memory[addr++] = 3;  						// BSH
	memory[addr++] = 7;  						// BLM
	memory[addr++] = 0;  						// EXM
	memory[addr++] = 242;  memory[addr++] = 0x60;  // DSM
	memory[addr++] = 63;  memory[addr++] = 0x60;  // DRM
	memory[addr++] = 192;  						// AL0
	memory[addr++] = 0;  						// AL1
	memory[addr++] = 16;  memory[addr++] = 0x60;  // CKS
	memory[addr++] = 2;  memory[addr++] = 0x60;  // OFF

	// Diperlukan oleh DPH table
	addr = 0xFB90;
	memory[addr++] = 0x00;  memory[addr++] = 0x00; // XLT
	addr = 0xABA0;
	memory[addr++] = 0x00;							// DIRBUF
	addr = 0xABB0;
	memory[addr++] = 0x00;							// CSV
	addr = 0xABC0;
	memory[addr++] = 0x00;							// ALV


	/*  ======================================================================
		BDOS
	    ======================================================================  */

	//
	// BDOS dispatcher
	//
	addr = 0xEC00;
	
	// Preserve registers that callers expect untouched
	memory[addr++] = 0xC5;		// PUSH BC
	memory[addr++] = 0xD5;		// PUSH DE
	memory[addr++] = 0xE5;		// PUSH HL

	memory[addr++] = 0x79;		// LD A,C
	memory[addr++] = 0xFE;	memory[addr++] = 0x00;							// CP 0
	memory[addr++] = 0xCA;  memory[addr++] = 0x00;  memory[addr++] = 0x00;  // JP Z, BDOS_RESET

	memory[addr++] = 0x79;													// LD A,C
	memory[addr++] = 0xFE;	memory[addr++] = 0x01;							// CP 1 
	memory[addr++] = 0xCA;  memory[addr++] = 0x08;  memory[addr++] = 0xED;  // JP Z, BDOS_CONIN

	memory[addr++] = 0x79;													// LD A,C
	memory[addr++] = 0xFE;	memory[addr++] = 0x02;							// CP 2
	memory[addr++] = 0xCA;  memory[addr++] = 0x10;  memory[addr++] = 0xED;  // JP Z, BDOS_CONOUT

	memory[addr++] = 0x79;		// LD A,C
	memory[addr++] = 0xFE;		// CP 0
	memory[addr++] = 0x00;
	memory[addr++] = 0xCA;		// JP Z, BDOS_DIRECTIO
	memory[addr++] = 0x00;
	memory[addr++] = 0x00;

	memory[addr++] = 0x79;		// LD A,C
	memory[addr++] = 0xFE;	memory[addr++] = 0x09;							// CP 0
	memory[addr++] = 0xCA;	memory[addr++] = 0x20;	memory[addr++] = 0xED;	// JP Z, BDOS_PRINT_STRING

	memory[addr++] = 0x79;		// LD A,C
	memory[addr++] = 0xFE;	memory[addr++] = 0x0A;							// CP 0	
	memory[addr++] = 0xCA;	memory[addr++] = 0x40;	memory[addr++] = 0xED;	// JP Z, BDOS_READ_BUFFER

	memory[addr++] = 0x79;		// LD A,C
	memory[addr++] = 0xFE;		// CP 0
	memory[addr++] = 0x00;
	memory[addr++] = 0xCA;		// JP Z, BDOS_SET_DMA
	memory[addr++] = 0x00;
	memory[addr++] = 0x00;

	// BDOS function not implemented or invalid
	memory[addr++] = 0x3E;		// LD A, FFh
	memory[addr++] = 0xFF;

	memory[addr++] = 0xC3;  memory[addr++] = 0xF0;  memory[addr++] = 0xEC;	// JP BDOS_EXIT
	
	// BDOS_EXIT:
	addr = 0xECF0;
	memory[addr++] = 0xE1;		// POP HL
	memory[addr++] = 0xD1;		// POP DE
	memory[addr++] = 0xC1;		// POP BC
	memory[addr++] = 0xC9;		// RET

	//
	//  BDOS IMPLEMENTATION
	//
	
	addr = 0xED00;
	// BDOS_RESET:
	memory[addr++] = 0xC3;  memory[addr++] = 0x50;  memory[addr++] = 0xFA;
	
	// BDOS_CONIN:
	addr = 0xED08;
	memory[addr++] = 0xCD;  memory[addr++] = 0x60;  memory[addr++] = 0xFA;		// CALL BIOS_CONIN
	memory[addr++] = 0xC3;  memory[addr++] = 0xF0;  memory[addr++] = 0xEC;		// JP BDOS_EXIT
	
	// BDOS_CONOUT:
	addr = 0xED10;
	memory[addr++] = 0x7B;  // LD A,E
	memory[addr++] = 0xCD;  memory[addr++] = 0x68;  memory[addr++] = 0xFA;		// CALL BIOS_CONOUT
	memory[addr++] = 0xC3;  memory[addr++] = 0xF0;  memory[addr++] = 0xEC;		// JP BDOS_EXIT
	
	// BDOS_PRINT_STRING:
	addr = 0xED20;
	memory[addr++] = 0x62;														//  HL = string pointer
	memory[addr++] = 0x6B;														//  MOV HL, DE
	// BDOS_PS_LOOP
	memory[addr++] = 0x7E;														//  MOV A, (HL)
	memory[addr++] = 0xFE;  memory[addr++] = 0x24;								//  CP '$'
	memory[addr++] = 0xCA;  memory[addr++] = 0x2F;  memory[addr++] = 0xED;		//	JP Z BDOS_PS_DONE
	memory[addr++] = 0xCD;  memory[addr++] = 0x68;  memory[addr++] = 0xFA;		//	CALL BIOS_CONOUT
	memory[addr++] = 0x23;														//	INC HL
	memory[addr++] = 0xC3;  memory[addr++] = 0x22;  memory[addr++] = 0xED;		//	JP BDOS_PS_LOOP
	// BDOS_PS_DONE
	memory[addr++] = 0x3E;  memory[addr++] = 0x00;								//  LD A, 0
	memory[addr++] = 0xC3;  memory[addr++] = 0xF0;  memory[addr++] = 0xEC;		//  JP BDOS_EXIT
	
	// BDOS_READ_BUFFER (0Ah)
	addr = 0xED40;
	memory[addr++] = 0x62;  memory[addr++] = 0x6B;  // LD HL, DE
	memory[addr++] = 0x46;  // LD B, (HL)
	memory[addr++] = 0x0E;  memory[addr++] = 0x00;  // LD C, 0
	memory[addr++] = 0x23;  memory[addr++] = 0x23;  // INC HL x2
	// LOOP:
	addr = 0xED47;
	memory[addr++] = 0xCD;  memory[addr++] = 0x60;  memory[addr++] = 0xFA;  //  CALL BIOS_CONIN
	memory[addr++] = 0xFE;  memory[addr++] = 0x0A;  //  CP '\LF'
	memory[addr++] = 0xCA;  memory[addr++] = 0x5E;  memory[addr++] = 0xED;		//  JP Z, DONE
	memory[addr++] = 0xCD;  memory[addr++] = 0x68;  memory[addr++] = 0xFA;		//  CALL BIOS_CONOUT
	memory[addr++] = 0x77;  // LD (HL), A
	memory[addr++] = 0x0C;  // INC C
	memory[addr++] = 0x23;  // INC HL
	memory[addr++] = 0x79;  // LD A, C
	memory[addr++] = 0xB8;  // CP B
	memory[addr++] = 0xD2;  memory[addr++] = 0x5E;  memory[addr++] = 0xED;  // JP NC, DONE:
	memory[addr++] = 0xC3;  memory[addr++] = 0x47;  memory[addr++] = 0xED;  // JP LOOP:
	// DONE:
	addr = 0xED5E;
	memory[addr++] = 0x62;  memory[addr++] = 0x6B;  // LD HL, DE
	memory[addr++] = 0x23;  // INC HL
	memory[addr++] = 0x71;  // LD (HL), C
	memory[addr++] = 0xC3;  memory[addr++] = 0xF0;  memory[addr++] = 0xEC;		//  JP BDOS_EXIT

	/*
		CCP - Minimal CCP that prints 'A>' and echos INPUT?
		Get it? Because it has no idea how to process commands yet!
	*/

	addr = 0xE400;
	// CCP
	memory[addr++] = 0x31;  memory[addr++] = 0x20;  memory[addr++] = 0xE5;
	
	// CCP_LOOP:
	addr = 0xE403;
	// Print prompt "A>"
	memory[addr++] = 0x11;  memory[addr++] = 0x80;  memory[addr++] = 0xE4;
	memory[addr++] = 0x0E;  memory[addr++] = 0x09;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	
	// Read console buffer
	memory[addr++] = 0x11;  memory[addr++] = 0x90;  memory[addr++] = 0xE4;
	memory[addr++] = 0x0E;  memory[addr++] = 0x0A;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;
	
	// print newline
	memory[addr++] = 0x1E;  memory[addr++] = 0x0D;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	memory[addr++] = 0x1E;  memory[addr++] = 0x0A;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	// echo input
	memory[addr++] = 0x21;  memory[addr++] = 0x91;  memory[addr++] = 0xE4;
	memory[addr++] = 0x46;
	memory[addr++] = 0x23;

	// ECHO_LOOP:
	addr = 0xE440;
	memory[addr++] = 0x78;
	memory[addr++] = 0xB7;
	memory[addr++] = 0xCA;  memory[addr++] = 0x60;  memory[addr++] = 0xE4;

	memory[addr++] = 0x7E;
	memory[addr++] = 0x5F;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;
	
	memory[addr++] = 0x23;
	memory[addr++] = 0x05;
	memory[addr++] = 0xC3;  memory[addr++] = 0x40;  memory[addr++] = 0xE4;

	// ECHO_DONE
	addr = 0xE460;
	memory[addr++] = 0x1E;  memory[addr++] = 0x3F;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	// newline
	memory[addr++] = 0x1E;  memory[addr++] = 0x0D;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	memory[addr++] = 0x1E;  memory[addr++] = 0x0A;
	memory[addr++] = 0x0E;  memory[addr++] = 0x02;
	memory[addr++] = 0xCD;  memory[addr++] = 0x05;  memory[addr++] = 0x00;

	memory[addr++] = 0xC3;  memory[addr++] = 0x03;  memory[addr++] = 0xE4;

	// PROMPT:
	addr = 0xE480;
	memory[addr++] = 0x41;
	memory[addr++] = 0x3E;
	memory[addr++] = 0x24;

	// INPUT_BUF:
	addr = 0xE490;
	memory[addr++] = 0x50;
	memory[addr++] = 0x00;
	    // DS 80

	// CCP stack:
	addr = 0xE520;
	memory[addr++] = 0x00;
}

void load_cpm_binary(char *filename, uint8_t *memory) {
	FILE *fp = fopen(filename, "rb");
	if (fp == NULL) {
		printf("Failed to open the CP/M binary!\n");
		return;
	}

	// size_t file = fread(memory, sizeof(uint8_t), 65536, fp);
	// if (file < 65536) {
	// 	printf("Failed to read the CP/M binary!\n");
	// }

	size_t tasks_read = fread(memory, sizeof(uint8_t), 65536, fp);

	if (tasks_read < 10) {
    	if (feof(fp)) {
        	printf("Notice: Only %zu elements were available before EOF.\n", tasks_read);
    	}
    	if (ferror(fp)) {
        	perror("Error reading file"); // This prints the specific system error
    	}
	}
}