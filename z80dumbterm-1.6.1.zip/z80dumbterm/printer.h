#include <stdint.h>
#include <stdio.h>

extern FILE *printer_file;

void printer_write(uint8_t value);