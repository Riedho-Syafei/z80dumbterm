#include <SDL3/SDL.h>
#include "z80.h"
#include "memory.h"
#include "terminal.h"
#include "keyboard.h"
#include "disk.h"
#include "cpm_hexdump.h"
#include "printer.h"
#include <string.h>
#include <stdio.h>

SDL_Window* window;
SDL_Renderer* renderer;
FILE* logfile;

static uint8_t translate_key(SDL_Keycode key, bool shift, bool caps)
{
    // Letters
    if (key >= SDLK_A && key <= SDLK_Z) {
        // Shift and Caps Lock reverse each other for alphabetical characters
        bool is_upper = shift ^ caps;
        return is_upper ? ('A' + (key - SDLK_A))
                        : ('a' + (key - SDLK_A));
    }

    // Numbers + shifted symbols (Caps Lock does not affect these)
    if (key >= SDLK_0 && key <= SDLK_9) {
        if (!shift)
            return '0' + (key - SDLK_0);

        static const char shifted_nums[] = {
            ')', '!', '@', '#', '$', '%', '^', '&', '*', '('
        };
        return shifted_nums[key - SDLK_0];
    }

    // Punctuation
    switch (key) {
        case SDLK_MINUS:        return shift ? '_' : '-';
        case SDLK_EQUALS:       return shift ? '+' : '=';
        case SDLK_LEFTBRACKET:  return shift ? '{' : '[';
        case SDLK_RIGHTBRACKET: return shift ? '}' : ']';
        case SDLK_BACKSLASH:    return shift ? '|' : '\\';
        case SDLK_SEMICOLON:    return shift ? ':' : ';';
        case SDLK_APOSTROPHE:   return shift ? '"' : '\'';
        case SDLK_COMMA:        return shift ? '<' : ',';
        case SDLK_PERIOD:       return shift ? '>' : '.';
        case SDLK_SLASH:        return shift ? '?' : '/';
        case SDLK_GRAVE:        return shift ? '~' : '`';

        case SDLK_SPACE:        return ' ';
        case SDLK_TAB:          return '\t';
        case SDLK_RETURN:       return '\n';
        case SDLK_BACKSPACE:    return '\b';
        case SDLK_ESCAPE:       return 27;
    }

    return 0;
}



int main(void) {
    Z80 cpu;
	memset(memory, 0, 65536);

    // Reset CPU
    memset(&cpu, 0, sizeof(cpu));
    cpu.pc = 0x0000;

	
	
	
	// Load CP/M system
	// cpu.pc = 0x000E;
	cpu.sp = 0xFFF0;

	/* ================================================
		Load the disk files
	   ================================================ */
	disk_file_A = fopen("disk_a.img", "r+b");
	if (disk_file_A == NULL) {
    	printf("Error: Could not open disk_a.img\n");
    	exit(1);
	} else {
		printf("Disk loaded: disk_a.img\n");
	}

	disk_file_B = fopen("disk_b.img", "r+b");
	if (disk_file_B == NULL) {
    	printf("Warning: Could not open disk_b.img\n");
	} else {
		printf("Disk loaded: disk_b.img\n");
	}

	disk_file_C = fopen("disk_c.img", "r+b");
	if (disk_file_C == NULL) {
    	printf("Warning: Could not open disk_a.img\n");
	} else {
		printf("Disk loaded: disk_c.img\n");
	}

	disk_file_D = fopen("disk_d.img", "r+b");
	if (disk_file_D == NULL) {
    	printf("Warning: Could not open disk_a.img\n");
	} else {
		printf("Disk loaded: disk_d.img\n");
	}

	logfile = fopen("CPULOG.txt", "w");

	printer_file = fopen("TTY_printer.txt", "w");
	
	//load_minimal_cpm(memory);
	
	load_cpm_binary("cpmlike.bin", memory);
	


    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

    window = SDL_CreateWindow(
        "Z80 Terminal",
        TERM_COLS * CHAR_W * 2,
        TERM_ROWS * CHAR_H * 3,
        0
    );

	//SDL_StartTextInput(window);

    renderer = SDL_CreateRenderer(window, NULL);
	SDL_SetRenderLogicalPresentation(
    	renderer,
    	TERM_COLS * CHAR_W,
    	TERM_ROWS * CHAR_H,
    	SDL_LOGICAL_PRESENTATION_STRETCH
	);

	terminal_init();
	

    bool running = true;

    while (running)
    {	
		SDL_Event e;
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_EVENT_QUIT)
                running = false;
			

			if (e.type == SDL_EVENT_KEY_DOWN) {
    			bool shift = (e.key.mod & SDL_KMOD_SHIFT);
				bool caps = (e.key.mod & SDL_KMOD_CAPS) != 0; // Capture Caps Lock
    			uint8_t ch = translate_key(e.key.key, shift, caps);

    			if (ch != 0)
        			keyboard_push(ch);

				// 1. Check if ANY Ctrl key is held
        		if (e.key.mod & SDL_KMOD_CTRL) {
            
            		// 2. Now identify which key was paired with Ctrl
            		switch (e.key.key) {
                		case SDLK_C:
                    		keyboard_push(0x03);
                    		break;
                		default:
                    		// This catches every other Ctrl + [Key] combo
                    		printf("Ctrl + Key (ID: %" PRIu32 ") pressed\n", e.key.key);
                    		break;
            		}
        		}
			}



        }

		uint32_t start = SDL_GetTicks();

		while ((SDL_GetTicks() - start < 16) && running) {
    		z80_step(&cpu);
			if (cpu.halted) running = false;
		}

		

        terminal_render(renderer);
        // SDL_Delay(16); // ~60fps
    }
	
	

	SDL_Delay(2000);	// 2 second delay before closes
	SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
