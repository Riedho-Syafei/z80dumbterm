#include <stdio.h>
#include "disk.h"
#include "memory.h"

FILE *disk_file_A = NULL;
FILE *disk_file_B = NULL;
FILE *disk_file_C = NULL;
FILE *disk_file_D = NULL;
FILE **active_disk_file = &disk_file_A;
int disk_track = 0;
int disk_sector = 0;
int disk_dma = 0x80;
int disk_command = 0;
int disk = 0;

void set_track(uint16_t track) {
	disk_track = track;
}

void set_sector(uint16_t sector) {
	disk_sector = sector;
}

void disk_read_sector(FILE **active_disk_file) {
    // Calculate byte position in file
    // Assuming 26 sectors per track, 128 bytes per sector (standard CP/M 8")
    long offset = (disk_track * SECTORS_PER_TRACK + (disk_sector - 1)) * 128;
    
    // Seek to position in file
    fseek(*active_disk_file, offset, SEEK_SET);
    
    // Read 128 bytes into Z80 memory at DMA address
    // Assuming your Z80 RAM is called 'memory' and is uint8_t memory[65536]
    fread(&memory[disk_dma], 1, 128, *active_disk_file);
    
    printf("Disk: Read track %d, sector %d to memory 0x%04X\n", 
           disk_track, disk_sector, disk_dma);
}

void disk_write_sector(FILE **active_disk_file) {
    
    long offset = (disk_track * SECTORS_PER_TRACK + (disk_sector - 1)) * 128;
    
    // Seek to position in file
    fseek(*active_disk_file, offset, 0);
    
    // Write 128 bytes from Z80 memory to the file
    fwrite(&memory[disk_dma], 1, 128, *active_disk_file);
    
    // Make sure it actually gets written to disk
    fflush(*active_disk_file);
    
    printf("Disk: Wrote track %d, sector %d from memory 0x%04X\n", 
           disk_track, disk_sector, disk_dma);
}