#ifndef CPM_HEXDUMP_H
#define CPM_HEXDUMP_H

#include <stdint.h>
#include <stdio.h>

void load_minimal_cpm(uint8_t *memory);
void load_cpm_binary(char *filename, uint8_t *memory);

#endif