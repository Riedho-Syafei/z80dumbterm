#include "keyboard.h"

#define KBD_BUF_SIZE 32

static uint8_t buf[KBD_BUF_SIZE];
static int head = 0;
static int tail = 0;

void keyboard_init(void)
{
    head = tail = 0;
}

void keyboard_push(uint8_t ch)
{
    int next = (head + 1) % KBD_BUF_SIZE;
    if (next == tail)
        return; // buffer full, drop key

    buf[head] = ch;
    head = next;
}

uint8_t keyboard_pop(void)
{
    if (head == tail)
        return 0; // no key available

    uint8_t ch = buf[tail];
    tail = (tail + 1) % KBD_BUF_SIZE;
    return ch;
}

uint8_t keyboard_peek(void)
{
    if (head == tail)
        return 0;
    return buf[tail];
}

// variation of peek()
int keyboard_has_data(void)  // Returns 1 if keys available, 0 otherwise
{
    return (head != tail);
}