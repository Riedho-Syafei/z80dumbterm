		ORG $0100

SYSCALL		EQU		5

START:
		; -----------------------------
        ; OPEN the PERTIWI.LIB library
        ; -----------------------------
        LD   C, 33
        LD   DE, LIB_FILENAME
        CALL SYSCALL
        OR   A
        JR   NZ, error           ; Open failed

        ; -----------------------------
        ; Get exact file size in bytes
        ; -----------------------------
		LD   DE, FILE_SIZE
		LD   C, 42
		CALL SYSCALL

		LD   HL, (FILE_SIZE)

		LD   A, H
		OR   L
		JR   Z, read_done			; If size is 0 bytes, nothing to load

        ; -----------------------------
        ; READ entire file in one call
        ; -----------------------------
        LD   DE, $C000           ; DE = Destination buffer
        LD   C, 34               ; C  = SYS_FS_READ syscall
        CALL SYSCALL
        
        ; A = 0 (Success) or 1 (EOF). Both are completely fine here.
        CP   $FF
        JR   Z, error            ; Real read error

read_done:
        ; -----------------------------
        ; CLOSE file
        ; -----------------------------
        LD   C, 35
        CALL SYSCALL

		; -----------------------------
		; Start of Text Editor routines
		; -----------------------------
		CALL INIT_ALL

; -------------
; Main routines
; -------------
MAIN_LOOP:
		CALL GET_KEY

		CALL HANDLE_KEY

		CALL RENDER

		JP   MAIN_LOOP
; --------------
; Error handling
; --------------

; FATAL error! We don't even have PERTIWI.LIB
error:
        LD   C, 3
		LD   DE, MSG_ERROR
		CALL SYSCALL
        JP   $003B				; exit early

; -----------------------
; Data section
; -----------------------

MSG_ERROR:
		DB "Couldn't open or read PERTIWI.LIB!",13,10,0

LIB_FILENAME:
        DB "PERTIWI.LIB",0

FILE_SIZE:
		DS 4,0
