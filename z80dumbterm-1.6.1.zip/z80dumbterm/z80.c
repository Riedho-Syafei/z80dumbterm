#include "z80.h"
#include "memory.h"
#include "terminal.h"
#include "keyboard.h"
#include "disk.h"
#include "printer.h"
#include <stdio.h>
#include <stdlib.h>



extern uint8_t memory[65536];

uint8_t fetch(Z80 *cpu) {
    
	uint8_t op = memory[cpu->pc];

	//printf("%04X  %02X\n", cpu->pc, op);
	
	cpu->pc++;
	
    return op;
}

uint8_t *reg_ptr(Z80 *cpu, uint8_t code) {
    switch (code) {
        case 0: return &cpu->b;
        case 1: return &cpu->c;
        case 2: return &cpu->d;
        case 3: return &cpu->e;
        case 4: return &cpu->h;
        case 5: return &cpu->l;
        case 7: return &cpu->a;
        default:
            return NULL; // 6 = (HL), handle later
    }
}

static inline void set_sz(Z80 *cpu, uint8_t value) {
    cpu->f &= ~(FLAG_S | FLAG_Z);

    if (value == 0)
        cpu->f |= FLAG_Z;

    if (value & 0x80)
        cpu->f |= FLAG_S;
	
}

static int parity(uint8_t v) {
    v ^= v >> 4;
    v ^= v >> 2;
    v ^= v >> 1;
    return (~v) & 1;
}

// Used by JR / JP / CALL / RET
static int check_condition(Z80* cpu, int cc) {
    switch (cc) {
        case 0: return !(cpu->f & FLAG_Z);  // NZ
        case 1: return  (cpu->f & FLAG_Z);  // Z
        case 2: return !(cpu->f & FLAG_C);  // NC
        case 3: return  (cpu->f & FLAG_C);  // C
        case 4: return !(cpu->f & FLAG_PV); // PO
        case 5: return  (cpu->f & FLAG_PV); // PE
        case 6: return !(cpu->f & FLAG_S);  // P
        case 7: return  (cpu->f & FLAG_S);  // M
    }
    return 0;
}

static inline void push16(Z80 *cpu, uint16_t value)
{
    cpu->sp--;
    mem_write(cpu->sp, (value >> 8) & 0xFF);
    cpu->sp--;
    mem_write(cpu->sp, value & 0xFF);
}

static inline uint16_t pop16(Z80 *cpu)
{
    uint8_t lo = mem_read(cpu->sp);
    cpu->sp++;
    uint8_t hi = mem_read(cpu->sp);
    cpu->sp++;

    return ((uint16_t)hi << 8) | lo;
}

uint8_t io_read(uint8_t port) {
    printf("IN %02X\n", port);
	
	// Disk drive status (XXXX DCBA)
	if (port == 0x16) {
        uint8_t result = 0xFF;
		
		if (disk_file_A != NULL) {
			// set the 1st bit to 0 (active low)
			result &= ~(1 << 0);
		}

		if (disk_file_B != NULL) {
			// set the 2nd bit to 0 (active low)
			result &= ~(1 << 1);
		}

		if (disk_file_C != NULL) {
			// set the 3rd bit to 0 (active low)
			result &= ~(1 << 2);
		}

		if (disk_file_D != NULL) {
			// set the 4th bit to 0 (active low)
			result &= ~(1 << 3);
		}

		return result;
    }

	switch (port) {
        case 0x00: { // console status
            return keyboard_has_data() ? 0xFF : 0x00;
        }

        case 0x01: { // console data
            return keyboard_pop();
        }

    }
	

    
    return 0x00;
}

void io_write(uint8_t port, uint8_t value, Z80 *cpu) {
	printf("OUT %02X <- %02X\n", port, value);
	

	// Console output
	if (port == 0x01) {
        terminal_put_char(value);
        return;
    }

	// Printer
	if (port == 0x02) {
		printer_write(value);
		return;
	}
	
	
	// Disk output
	if (port == 0x10) {
    	disk_track = (disk_track & 0xFF00) | value;  // Low byte
	}
	else if (port == 0x11) {
    	disk_track = (disk_track & 0x00FF) | (value << 8);  // High byte
	}
	else if (port == 0x12) {
    	disk_sector = value;
	}
	else if (port == 0x13) {
    	disk_dma = (disk_dma & 0xFF00) | value;
	}
	else if (port == 0x14) {
    	disk_dma = (disk_dma & 0x00FF) | (value << 8);
	}
	else if (port == 0x15) {
    	if (value == 0) disk_track = 0;  // Home
    	else if (value == 1) disk_read_sector(active_disk_file);
    	else if (value == 2) disk_write_sector(active_disk_file);
	}
	else if (port == 0x16) {
    	// Disk drive Status port
    	return;  
	}
	else if (port == 0x17) {
    	// Select disk
		disk = value;

		if (disk == 0) {
			active_disk_file = &disk_file_A;
		}

		if (disk == 1) {
			active_disk_file = &disk_file_B;
		}

		if (disk == 2) {
			active_disk_file = &disk_file_C;
		}

		if (disk == 3) {
			active_disk_file = &disk_file_D;
		}

    	printf("Select disk %c\n", 'A' + value);
	} 
	

    
}


void z80_step(Z80 *cpu) {
    uint8_t opcode = fetch(cpu);

	printf("PC=%04X opcode=%02X A=%02X F=%02X B=%02X C=%02X D=%02X E=%02X H=%02X L=%02X SP=%04X value=%02X %02X\n",
			cpu->pc - 1, opcode, cpu->a, cpu->f, cpu->b, cpu->c, cpu->d, cpu->e, cpu->h, cpu->l,
			cpu->sp, memory[cpu->sp + 1], memory[cpu->sp]);

	// fprintf(logfile, "PC=%04X opcode=%02X A=%02X F=%02X B=%02X C=%02X D=%02X E=%02X H=%02X L=%02X SP=%04X value=%02X %02X\n",
	// 		cpu->pc - 1, opcode, cpu->a, cpu->f, cpu->b, cpu->c, cpu->d, cpu->e, cpu->h, cpu->l,
	// 		cpu->sp, memory[cpu->sp + 1], memory[cpu->sp]);

    if (opcode == 0x76) { // HALT
    	cpu->halted = true;
    	return;
	}

	if (opcode == 0xF3) { // DI - No Interrupts yet
    	return;
	}

	if (opcode == 0xFB) { // EI - No Interrupts yet
    	return;
	}

	if (opcode == 0x9E) { // SBC A,(HL)
    	uint8_t value = mem_read(get_hl(cpu));
    	uint8_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t result = cpu->a - value - carry;
    	uint8_t res8 = result & 0xFF;

    	cpu->f = FLAG_N;  // Subtraction sets N

    	// Sign
    	if (res8 & 0x80)
        	cpu->f |= FLAG_S;

    	// Zero
    	if (res8 == 0)
        	cpu->f |= FLAG_Z;

    	// Half carry (borrow from bit 4)
    	if ((cpu->a & 0x0F) < ((value & 0x0F) + carry))
        	cpu->f |= FLAG_H;

    	// Overflow
    	if ((cpu->a ^ value) & (cpu->a ^ res8) & 0x80)
        	cpu->f |= FLAG_PV;

    	// Carry (borrow)
    	if (result & 0x100)
	        cpu->f |= FLAG_C;

    	cpu->a = res8;
    	return;
	}

	if (opcode == 0x2F) { // CPL
    	cpu->a ^= 0xFF;

    	cpu->f |= (FLAG_H | FLAG_N);  // Set H and N
    	// Do NOT modify S, Z, P/V, C

    	return;
	}

	if (opcode == 0xD9) { // EXX
    	uint8_t tmp;

    	tmp = cpu->b; cpu->b = cpu->b2; cpu->b2 = tmp;
    	tmp = cpu->c; cpu->c = cpu->c2; cpu->c2 = tmp;

	    tmp = cpu->d; cpu->d = cpu->d2; cpu->d2 = tmp;
	    tmp = cpu->e; cpu->e = cpu->e2; cpu->e2 = tmp;

    	tmp = cpu->h; cpu->h = cpu->h2; cpu->h2 = tmp;
    	tmp = cpu->l; cpu->l = cpu->l2; cpu->l2 = tmp;

	    return;
	}

	if (opcode == 0xAE) { // XOR (HL)
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint8_t value = mem_read(hl);

    	cpu->a ^= value;
    	uint8_t result = cpu->a;

    	cpu->f = 0;

    	if (result & 0x80) cpu->f |= FLAG_S;
    	if (result == 0)   cpu->f |= FLAG_Z;
    	if (parity(result)) cpu->f |= FLAG_PV;

    	// H = 0
    	// N = 0
    	// C = 0

    	return;
	}

	if (opcode == 0xA6) { // AND (HL)
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint8_t value = mem_read(hl);

    	cpu->a &= value;
    	uint8_t result = cpu->a;

    	cpu->f = 0;

    	if (result & 0x80) cpu->f |= FLAG_S;
    	if (result == 0)   cpu->f |= FLAG_Z;
    	if (parity(result)) cpu->f |= FLAG_PV;

    	cpu->f |= FLAG_H;   // <-- ALWAYS SET
    	// N = 0
    	// C = 0

	    return;
	}

	if (opcode == 0x8E) { // ADC A,(HL)
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint8_t value = mem_read(hl);

    	uint8_t a = cpu->a;
    	uint8_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t sum = a + value + carry;
    	uint8_t result = sum & 0xFF;

    	cpu->a = result;

    	// Flags
    	cpu->f = 0;

    	if (result & 0x80) cpu->f |= FLAG_S;
    	if (result == 0)   cpu->f |= FLAG_Z;
    	if (((a & 0x0F) + (value & 0x0F) + carry) > 0x0F)
        	cpu->f |= FLAG_H;
    	if ((~(a ^ value) & (a ^ result)) & 0x80)
        	cpu->f |= FLAG_PV;
    	if (sum & 0x100) cpu->f |= FLAG_C;
    	// N is cleared

    	return;
	}

	if (opcode == 0x86) { // ADD A,(HL)
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint8_t value = mem_read(hl);

    	uint8_t a = cpu->a;
    	uint16_t sum = a + value;
    	uint8_t result = sum & 0xFF;

    	cpu->a = result;

    	// Flags
    	cpu->f = 0;

    	if (result & 0x80) cpu->f |= FLAG_S;
    	if (result == 0)   cpu->f |= FLAG_Z;
    	if (((a & 0x0F) + (value & 0x0F)) > 0x0F) cpu->f |= FLAG_H;
    	if ((~(a ^ value) & (a ^ result)) & 0x80) cpu->f |= FLAG_PV;
    	if (sum & 0x100) cpu->f |= FLAG_C;
    	// N is always 0

    	return;
	}

	if (opcode == 0xE3) { // EX (SP),HL
    	uint16_t sp = cpu->sp;

    	uint8_t mem_lo = mem_read(sp);
    	uint8_t mem_hi = mem_read(sp + 1);

    	// Save old HL
    	uint8_t old_l = cpu->l;
    	uint8_t old_h = cpu->h;

    	// HL <- (SP)
    	cpu->l = mem_lo;
    	cpu->h = mem_hi;

    	// (SP) <- old HL
    	mem_write(sp, old_l);
    	mem_write(sp + 1, old_h);

    	return;
	}

	if (opcode == 0xF6) { // OR n
    	uint8_t n = mem_read(cpu->pc++);
    	cpu->a |= n;

    	uint8_t res = cpu->a;

    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	if (opcode == 0x1B) { // DEC DE
    	uint16_t de = (cpu->d << 8) | cpu->e;
    	de--;
    	cpu->d = (de >> 8) & 0xFF;
    	cpu->e = de & 0xFF;
    	return;
	}


	if (opcode == 0x2B) { // DEC HL
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	hl--;
    	cpu->h = (hl >> 8) & 0xFF;
    	cpu->l = hl & 0xFF;
    	return;
	}

	if (opcode == 0x33) { // INC SP
    	cpu->sp++;
    	return;
	}

	if (opcode == 0x35) { // DEC (HL)
	    uint16_t addr = (cpu->h << 8) | cpu->l;
    	uint8_t old = memory[addr];
	    uint8_t result = old - 1;

    	memory[addr] = result;

    	// Flags
    	cpu->f = (cpu->f & FLAG_C);           // preserve Carry
    	cpu->f |= FLAG_N;                    // subtraction

    	if (result == 0) cpu->f |= FLAG_Z;
    	if (result & 0x80) cpu->f |= FLAG_S;
    	if ((old & 0x0F) == 0x00) cpu->f |= FLAG_H;   // half borrow
    	if (old == 0x80) cpu->f |= FLAG_PV;           // overflow

    	return;
	}

	if (opcode == 0x96) { // SUB (HL)
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint8_t b = mem_read(hl);
    	uint8_t a = cpu->a;
    	uint8_t r = a - b;

    	cpu->a = r;

    	// S flag
    	if (r & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z flag
    	if (r == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H flag (half borrow)
    	if ((a & 0x0F) < (b & 0x0F))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V flag (signed overflow)
    	if (((a ^ b) & (a ^ r)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N flag (subtract)
    	SET_FLAG((*cpu), FLAG_N);

    	// C flag (borrow)
    	if (a < b)
	        SET_FLAG((*cpu), FLAG_C);
    	else
        	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}



	if (opcode == 0xEE) {   // XOR n
    	uint8_t n = mem_read(cpu->pc++);
    	cpu->a ^= n;

    	uint8_t res = cpu->a;

    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}

	if (opcode == 0x3B) {   // DEC SP
    	cpu->sp--;
    	return;
	}

	if (opcode == 0x08) {   // EX AF,AF'
    	uint8_t tmp;

    	tmp = cpu->a;
    	cpu->a = cpu->a2;
    	cpu->a2 = tmp;

    	tmp = cpu->f;
    	cpu->f = cpu->f2;
    	cpu->f2 = tmp;

    	return;
	}

	if (opcode == 0xD6) { // SUB n
    	uint8_t n = mem_read(cpu->pc++);
	    uint8_t a = cpu->a;

    	uint16_t diff = (uint16_t)a - (uint16_t)n;
    	uint8_t result = diff & 0xFF;

    	cpu->a = result;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (half-borrow)
    	if ((a & 0x0F) < (n & 0x0F))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
	    if (((a ^ n) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N
    	SET_FLAG((*cpu), FLAG_N);

    	// C (borrow)
	    if (a < n)
	        SET_FLAG((*cpu), FLAG_C);
    	else
        	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	if (opcode == 0xBE) { // CP (HL)
    	uint16_t addr = (cpu->h << 8) | cpu->l;
	    uint8_t b = mem_read(addr);
    	uint8_t a = cpu->a;

    	uint16_t diff = (uint16_t)a - (uint16_t)b;
    	uint8_t result = diff & 0xFF;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (half-borrow)
    	if ((a & 0x0F) < (b & 0x0F))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if (((a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N
    	SET_FLAG((*cpu), FLAG_N);

    	// C (borrow)
    	if (a < b)
        	SET_FLAG((*cpu), FLAG_C);
    	else
	        CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	if (opcode == 0xB6) { // OR (HL)
    	uint16_t addr = (cpu->h << 8) | cpu->l;
    	uint8_t val = mem_read(addr);

    	cpu->a |= val;
    	uint8_t res = cpu->a;

    	// Flags
    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	if (opcode == 0x0B) { // DCX B
    	if (cpu->c == 0)
        	cpu->b--;
    	cpu->c--;
    	return;
	}

	if (opcode == 0x13) { // INX D
    	cpu->e++;
    	if (cpu->e == 0)
        	cpu->d++;
    	return;
	}

	if (opcode == 0xF9) {   // LD SP, HL
    	cpu->sp = GET_HL(cpu);
    	//cpu->pc++;
    	return;
	}

	if (opcode == 0x03) {   // INC BC
    	uint16_t bc = (cpu->b << 8) | cpu->c;
    	bc++;
    	cpu->b = (bc >> 8) & 0xFF;
    	cpu->c = bc & 0xFF;
    	//cpu->pc++;
    	return;
	}


	if (opcode == 0x2A) { // LD HL,(nn)
    	uint8_t lo = mem_read(cpu->pc++);
	    uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	cpu->l = mem_read(addr);
    	cpu->h = mem_read(addr + 1);
    	return;
	}


	if (opcode == 0xE6) { // AND n
    	uint8_t value = mem_read(cpu->pc++);
    	cpu->a &= value;
    	uint8_t res = cpu->a;

    	// S
    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (res == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H is always set
    	SET_FLAG((*cpu), FLAG_H);

    	// P/V (parity)
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV);
    	else CLR_FLAG((*cpu), FLAG_PV);

    	// N and C cleared
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}

	if (opcode == 0x36) { // LD (HL), n
    	uint8_t value = mem_read(cpu->pc++);
    	uint16_t addr = (cpu->h << 8) | cpu->l;
    	mem_write(addr, value);
    	return;
	}

	if (opcode == 0xE9) { // JP (HL)
    	cpu->pc = (cpu->h << 8) | cpu->l;
    	return;
	}


	if (opcode == 0x34) { // INC (HL)
    	uint16_t addr = (cpu->h << 8) | cpu->l;
    	uint8_t val = mem_read(addr);
    	uint8_t res = val + 1;

    	mem_write(addr, res);

    	// Flags
    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else            CLR_FLAG((*cpu), FLAG_S);

    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z);
    	else            CLR_FLAG((*cpu), FLAG_Z);

    	// Half carry: bit 3 -> bit 4
    	if ((val & 0x0F) == 0x0F)
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// Overflow: 7F -> 80
    	if (val == 0x7F)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_N); // INC clears N
    	// C unaffected

    	return;
	}

	
	if (opcode == 0x11) { // LD DE, nn
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);

    	cpu->e = lo;
    	cpu->d = hi;

    	return;
	}

	/* LD (nn), HL */
	if (opcode == 0x22) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	mem_write(addr, cpu->l);
    	mem_write(addr + 1, cpu->h);

    	return;
	}


	if (opcode == 0x12) { // LD (DE),A
    	uint16_t addr = (cpu->d << 8) | cpu->e;
    	mem_write(addr, cpu->a);
    	return;
	}

	if (opcode == 0x02) { // LD (BC),A
    	uint16_t addr = (cpu->b << 8) | cpu->c;
    	mem_write(addr, cpu->a);
    	return;
	}

	if (opcode == 0x1A) { // LD A,(DE)
    	uint16_t addr = (cpu->d << 8) | cpu->e;
    	cpu->a = mem_read(addr);
    	return;
	}

	if (opcode == 0x0A) { // LD A,(BC)
    	uint16_t addr = (cpu->b << 8) | cpu->c;
    	cpu->a = mem_read(addr);
    	return;
	}


	if (opcode == 0x23) { // INC HL
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	hl++;
    	cpu->h = (hl >> 8) & 0xFF;
    	cpu->l = hl & 0xFF;
    	return;
	}

	if (opcode == 0x01) { /* LD BC,nn */
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	cpu->c = lo;
    	cpu->b = hi;
    	return;
	}

	/* CB-prefixed instructions */
	if (opcode == 0xCB) {
    uint8_t cb = mem_read(cpu->pc++);

    uint8_t op   = cb >> 6;        // 0=rot,1=bit,2=res,3=set
    uint8_t y    = (cb >> 3) & 7;  // operation / bit
    uint8_t z    = cb & 7;         // register

    uint8_t *r = reg_ptr(cpu, z);
    uint16_t addr = (cpu->h << 8) | cpu->l;

    uint8_t val = r ? *r : mem_read(addr);
    uint8_t carry;

    /* ================= ROTATE / SHIFT ================= */
    if (op == 0) {
        switch (y) {
            case 0: /* RLC */
                carry = (val >> 7) & 1;
                val = (val << 1) | carry;
                break;
            case 1: /* RRC */
                carry = val & 1;
                val = (val >> 1) | (carry << 7);
                break;
            case 2: /* RL */
                carry = (val >> 7) & 1;
                val = (val << 1) | ((cpu->f & FLAG_C) ? 1 : 0);
                break;
            case 3: /* RR */
                carry = val & 1;
                val = (val >> 1) | ((cpu->f & FLAG_C) ? 0x80 : 0);
                break;
            case 4: /* SLA */
                carry = (val >> 7) & 1;
                val <<= 1;
                break;
            case 5: /* SRA */
                carry = val & 1;
                val = (val >> 1) | (val & 0x80);
                break;
            case 6: /* SLL (undocumented) */
                carry = (val >> 7) & 1;
                val = (val << 1) | 1;
                break;
            case 7: /* SRL */
                carry = val & 1;
                val >>= 1;
                break;
        }

        if (r) *r = val;
        else mem_write(addr, val);

        cpu->f = 0;
        if (val == 0) cpu->f |= FLAG_Z;
        if (val & 0x80) cpu->f |= FLAG_S;
        if (parity(val)) cpu->f |= FLAG_PV;
        if (carry) cpu->f |= FLAG_C;

        return;
    }

    /* ================= BIT ================= */
if (op == 1) {
    uint8_t mask = 1 << y;
    uint8_t result = val & mask;
    
    cpu->f = (cpu->f & FLAG_C) | FLAG_H;  // Preserve C, set H, clear N
    
    if (!result) {
        cpu->f |= FLAG_Z | FLAG_PV;
    }
    if (y == 7 && result) {
        cpu->f |= FLAG_S;
    }
    
    return;
}

    /* ================= RES ================= */
    if (op == 2) {
        val &= ~(1 << y);

        if (r) *r = val;
        else mem_write(addr, val);

        return;
    }

    /* ================= SET ================= */
    if (op == 3) {
        val |= (1 << y);

        if (r) *r = val;
        else mem_write(addr, val);

        return;
    }
}


	if (opcode == 0x1F) {   // RRA
    	uint8_t old_f = cpu->f;
    	uint8_t old_c = old_f & FLAG_C;
    	uint8_t new_c = cpu->a & 0x01;

    	cpu->a = (cpu->a >> 1) | (old_c ? 0x80 : 0x00);

    	cpu->f =
        	(old_f & (FLAG_S | FLAG_Z | FLAG_PV)) |  // preserved
        	(cpu->a & (FLAG_3 | FLAG_5));            // copied from A

    	if (new_c)
        	cpu->f |= FLAG_C;

    	return;
	}




	if (opcode == 0x17) {   // RLA
    	uint8_t old_f = cpu->f;
    	uint8_t old_c = old_f & FLAG_C;
    	uint8_t new_c = (cpu->a >> 7) & 1;

    	cpu->a = (cpu->a << 1) | (old_c ? 1 : 0);

    	cpu->f =
        	(old_f & (FLAG_S | FLAG_Z | FLAG_PV)) |
        	(cpu->a & (FLAG_3 | FLAG_5));

    	if (new_c)
        	cpu->f |= FLAG_C;

    	return;
	}

	
	if (opcode == 0x0F) {   // RRCA
    	uint8_t old_f = cpu->f;
    	uint8_t carry = cpu->a & 1;

    	cpu->a = (cpu->a >> 1) | (carry << 7);

    	cpu->f =
        	(old_f & (FLAG_S | FLAG_Z | FLAG_PV)) |
        	(cpu->a & (FLAG_3 | FLAG_5));

    	if (carry)
	        cpu->f |= FLAG_C;

    	return;
	}

	
	if (opcode == 0x07) {   // RLCA
    	uint8_t old_f = cpu->f;
    	uint8_t carry = (cpu->a >> 7) & 1;

    	cpu->a = (cpu->a << 1) | carry;

	    cpu->f =
	        (old_f & (FLAG_S | FLAG_Z | FLAG_PV)) |
        	(cpu->a & (FLAG_3 | FLAG_5));

    	if (carry)
        	cpu->f |= FLAG_C;

    	return;
	}


	/*
		EX DE,HL
	*/
	if (opcode == 0xEB) {
    	uint8_t tmp;

    	tmp = cpu->h;
    	cpu->h = cpu->d;
    	cpu->d = tmp;

    	tmp = cpu->l;
    	cpu->l = cpu->e;
    	cpu->e = tmp;

    	return;
	}


	/*
		LD SP,nn
	*/
	if (opcode == 0x31) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	cpu->sp = (hi << 8) | lo;
    	return;
	}

	/*
		DAA
	*/
	if (opcode == 0x27) {
    	uint8_t a = cpu->a;
    	uint8_t adj = 0;
    	uint8_t carry = cpu->f & FLAG_C;

    	if (!(cpu->f & FLAG_N)) {
        	// After ADD / ADC
        	if ((cpu->f & FLAG_H) || ((a & 0x0F) > 9))
	            adj |= 0x06;
        	if (carry || (a > 0x99)) {
            	adj |= 0x60;
            	carry = FLAG_C;
        	}
        	cpu->a += adj;
    	} else {
        	// After SUB / SBC
        	if (cpu->f & FLAG_H)
            	adj |= 0x06;
        	if (carry)
	            adj |= 0x60;
    	    cpu->a -= adj;
    	}

    	// Flags
    	cpu->f &= FLAG_N;   // preserve N
    	if (carry) cpu->f |= FLAG_C;

    	if (cpu->a & 0x80) cpu->f |= FLAG_S;
    	if (cpu->a == 0)   cpu->f |= FLAG_Z;
    	if (parity(cpu->a) == 0) cpu->f |= FLAG_PV;
    	if (adj & 0x06) cpu->f |= FLAG_H;

    	return;
	}


	if (opcode == 0xFE) {    // CP n
    	uint8_t n = mem_read(cpu->pc++);

    	uint16_t diff = cpu->a - n;
    	uint8_t res = (uint8_t)diff;

    	cpu->f = FLAG_N;

    	if (res & 0x80) cpu->f |= FLAG_S;
    	if (res == 0)   cpu->f |= FLAG_Z;
    	if (((cpu->a ^ n ^ res) & 0x10)) cpu->f |= FLAG_H;
    	if (((cpu->a ^ n) & (cpu->a ^ res) & 0x80)) cpu->f |= FLAG_PV;
    	if (diff & 0x100) cpu->f |= FLAG_C;

    	return;
	}

	
	if (opcode == 0x3F) {    // CCF
    	uint8_t old_c = cpu->f & FLAG_C;

    	cpu->f &= ~(FLAG_N | FLAG_H);
    	if (old_c)
        	cpu->f |= FLAG_H;
    	cpu->f ^= FLAG_C;

    	return;
	}

	
	/*
		SBC A,n
	*/
	if (opcode == 0xDE) {
    	uint8_t n = mem_read(cpu->pc++);
    	uint8_t c = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t diff = cpu->a - n - c;
    	uint8_t res = (uint8_t)diff;

    	cpu->f = FLAG_N;

    	if (res & 0x80) cpu->f |= FLAG_S;
    	if (res == 0)   cpu->f |= FLAG_Z;
    	if (((cpu->a ^ n ^ res) & 0x10)) cpu->f |= FLAG_H;
    	if (((cpu->a ^ n) & (cpu->a ^ res) & 0x80)) cpu->f |= FLAG_PV;
    	if (diff & 0x100) cpu->f |= FLAG_C;

    	cpu->a = res;
    	return;
	}

	
	/*
		ADC A,n
	*/
	if (opcode == 0xCE) {
    	uint8_t n = mem_read(cpu->pc++);
    	uint8_t c = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t sum = cpu->a + n + c;
    	uint8_t res = (uint8_t)sum;

    	cpu->f = 0;

    	if (res & 0x80) cpu->f |= FLAG_S;
    	if (res == 0)   cpu->f |= FLAG_Z;
    	if (((cpu->a ^ n ^ res) & 0x10)) cpu->f |= FLAG_H;
    	if (((~(cpu->a ^ n)) & (cpu->a ^ res) & 0x80)) cpu->f |= FLAG_PV;
    	if (sum & 0x100) cpu->f |= FLAG_C;

    	cpu->a = res;
    	return;
	}


	/*
		ADD A,n
	*/
	if (opcode == 0xC6) {
    	uint8_t n = mem_read(cpu->pc++);
    	uint16_t res = cpu->a + n;

    	cpu->f &= ~(FLAG_C | FLAG_N);
    	if (res & 0x100) cpu->f |= FLAG_C;

    	cpu->a = (uint8_t)res;
    	set_sz(cpu, cpu->a);
    	return;
	}


	/*
		JR e
	*/
	if (opcode == 0x18) {
    	int8_t offset = (int8_t)mem_read(cpu->pc++);
    	cpu->pc += offset;

		printf("JR UNCOND PC=%04X disp=%d\n", cpu->pc, offset);

    	return;
	}


	if (opcode == 0xD3) {   // OUT (n),A
    	uint8_t port = mem_read(cpu->pc++);
		printf("OUT: port=%02X A=%02X ('%c')\n", port, cpu->a, (cpu->a >= 32 && cpu->a < 127) ? cpu->a : '.');
    	io_write(port, cpu->a, cpu);
    	return;
	}

	if (opcode == 0xDB) {   // IN A,(n)
    	uint8_t port = mem_read(cpu->pc++);
    	uint8_t value = io_read(port);

    	uint8_t old_c = cpu->f & FLAG_C;

    	cpu->a = value;

    	cpu->f =
        	old_c |                                 // preserve carry
        	(value & (FLAG_S | FLAG_3 | FLAG_5)) | // S, undocumented
        	(value == 0 ? FLAG_Z : 0) |
        	(parity(value) ? FLAG_PV : 0);         // PARITY, not overflow

    	// H and N cleared implicitly
    	return;
	}



	/*
		LD (nn),A
	*/
	if (opcode == 0x32) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = ((uint16_t)hi << 8) | lo;

    	mem_write(addr, cpu->a);
    	return;
	}

	/*
		LD A,(nn)
	*/
	if (opcode == 0x3A) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = ((uint16_t)hi << 8) | lo;

    	cpu->a = mem_read(addr);
    	return;
	}


	/*
		RST instructions
	*/
	if ((opcode & 0xC7) == 0xC7) {
    	uint16_t vector = (opcode & 0x38);
    	push16(cpu, cpu->pc);
    	cpu->pc = vector;
    	return;
	}


	/*
		JP cc,nn
	*/
	if ((opcode & 0xC7) == 0xC2) {
    	int cc = (opcode >> 3) & 0x07;

    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	if (check_condition(cpu, cc)) {
        	cpu->pc = addr;
    	}
    	return;
	}


	/*
		JP nn
	*/
	if (opcode == 0xC3) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	cpu->pc = (hi << 8) | lo;
    	return;
	}


	/*
		CALL cc,nn
	*/
	if ((opcode & 0xC7) == 0xC4) {
    	int cc = (opcode >> 3) & 0x07;

    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	if (check_condition(cpu, cc)) {
        	cpu->sp--;
        	mem_write(cpu->sp, (cpu->pc >> 8) & 0xFF);
        	cpu->sp--;
        	mem_write(cpu->sp, cpu->pc & 0xFF);
        	cpu->pc = addr;
    	}
    	return;
	}

	/*
		RET cc
	*/
	if ((opcode & 0xC7) == 0xC0) {
    	int cc = (opcode >> 3) & 0x07;

    	if (check_condition(cpu, cc)) {
        	uint8_t lo = mem_read(cpu->sp++);
        	uint8_t hi = mem_read(cpu->sp++);
        	cpu->pc = (hi << 8) | lo;
    	}
    	return;
	}


	/*
		CALL nn
	*/
	if (opcode == 0xCD) {
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	// Push current PC
    	cpu->sp--;
    	mem_write(cpu->sp, (cpu->pc >> 8) & 0xFF);
    	cpu->sp--;
    	mem_write(cpu->sp, cpu->pc & 0xFF);

    	cpu->pc = addr;
    	return;
	}

	/*
		RET
	*/
	if (opcode == 0xC9) {
    	uint8_t lo = mem_read(cpu->sp++);
    	uint8_t hi = mem_read(cpu->sp++);
    	cpu->pc = (hi << 8) | lo;
    	return;
	}



	/*
		PUSH rr
	*/
	if ((opcode & 0xCF) == 0xC5) {
    	uint16_t val;
    	int rr = (opcode >> 4) & 0x03;

    	switch (rr) {
        	case 0: val = (cpu->b << 8) | cpu->c; break; // BC
        	case 1: val = (cpu->d << 8) | cpu->e; break; // DE
        	case 2: val = (cpu->h << 8) | cpu->l; break; // HL
        	case 3: val = (cpu->a << 8) | cpu->f; break; // AF
    	}

    	cpu->sp--;
    	mem_write(cpu->sp, val >> 8);
    	cpu->sp--;
    	mem_write(cpu->sp, val & 0xFF);

    	return;
	}

	/*
		POP rr
	*/
	if ((opcode & 0xCF) == 0xC1) {
    	uint16_t val;
    	int rr = (opcode >> 4) & 0x03;

    	uint8_t lo = mem_read(cpu->sp++);
    	uint8_t hi = mem_read(cpu->sp++);
    	val = (hi << 8) | lo;

    	switch (rr) {
        	case 0: cpu->b = hi; cpu->c = lo; break; // BC
        	case 1: cpu->d = hi; cpu->e = lo; break; // DE
        	case 2: cpu->h = hi; cpu->l = lo; break; // HL
        	case 3: cpu->a = hi; cpu->f = lo & 0xF7; break; // AF (bit 3 always 0)
    	}

	    return;
	}


	/*
		ADD HL,rr
	*/
	if ((opcode & 0xCF) == 0x09) {
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint16_t rr;
    	int rr_code = (opcode >> 4) & 0x03;

    	switch (rr_code) {
        	case 0: rr = (cpu->b << 8) | cpu->c; break; // BC
        	case 1: rr = (cpu->d << 8) | cpu->e; break; // DE
        	case 2: rr = hl; break;                     // HL
        	case 3: rr = cpu->sp; break;                // SP
    	}

    	uint32_t sum = (uint32_t)hl + (uint32_t)rr;
    	uint16_t result = sum & 0xFFFF;

    	// H: carry from bit 11
    	if (((hl & 0x0FFF) + (rr & 0x0FFF)) > 0x0FFF)
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// C: carry from bit 15
    	if (sum > 0xFFFF)
        	SET_FLAG((*cpu), FLAG_C);
    	else
        	CLR_FLAG((*cpu), FLAG_C);

    	// N reset
    	CLR_FLAG((*cpu), FLAG_N);

    	// Write back HL
    	cpu->h = (result >> 8) & 0xFF;
    	cpu->l = result & 0xFF;

    	return;
	}


	/*
		AND r
	*/
	if ((opcode & 0xF8) == 0xA0) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("AND (HL) not implemented\n");
    	    exit(1);
	    }

    	cpu->a &= *src;
    	uint8_t res = cpu->a;

	    // Flags
    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	SET_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

	    return;
	}

	/*
		XOR r
	*/
	if ((opcode & 0xF8) == 0xA8) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("XOR (HL) not implemented\n");
        	exit(1);
    	}

    	cpu->a ^= *src;
    	uint8_t res = cpu->a;

    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

		printf("XOR: A=%02X Z=%d\n", res, !!(cpu->f & FLAG_Z));

    	return;
	}

	/*
		OR r
	*/
	if ((opcode & 0xF8) == 0xB0) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("OR (HL) not implemented\n");
        	exit(1);
    	}

    	cpu->a |= *src;
    	uint8_t res = cpu->a;

    	if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    	if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    	if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	/*
		CP r
	*/
	if ((opcode & 0xF8) == 0xB8) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("CP (HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t a = cpu->a;
    	uint8_t b = *src;

    	uint16_t diff = (uint16_t)a - (uint16_t)b;
    	uint8_t result = diff & 0xFF;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (half-borrow)
    	if ((a & 0x0F) < (b & 0x0F))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if (((a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N set
    	SET_FLAG((*cpu), FLAG_N);

    	// C (borrow)
    	if (a < b)
        	SET_FLAG((*cpu), FLAG_C);
    	else
        	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	/*
		SUB r
	*/
	if ((opcode & 0xF8) == 0x90) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("SUB (HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t a = cpu->a;
    	uint8_t b = *src;
    	uint16_t diff = (uint16_t)a - (uint16_t)b;
    	uint8_t result = diff & 0xFF;

    	cpu->a = result;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (borrow from bit 4)
    	if ((a & 0x0F) < (b & 0x0F))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if (((a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N set
    	SET_FLAG((*cpu), FLAG_N);

    	// C (borrow)
    	if (a < b) SET_FLAG((*cpu), FLAG_C);
    	else CLR_FLAG((*cpu), FLAG_C);

    	return;
	}

	/*
		SBC A,r
	*/
	if ((opcode & 0xF8) == 0x98) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("SBC A,(HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t a = cpu->a;
    	uint8_t b = *src;
    	uint8_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t diff = (uint16_t)a - (uint16_t)b - carry;
    	uint8_t result = diff & 0xFF;

    	cpu->a = result;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (half-borrow)
    	if ((a & 0x0F) < ((b & 0x0F) + carry))
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if (((a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N set
    	SET_FLAG((*cpu), FLAG_N);

    	// C (borrow)
    	if (a < (uint16_t)b + carry)
        	SET_FLAG((*cpu), FLAG_C);
    	else
        	CLR_FLAG((*cpu), FLAG_C);

    	return;
	}



	/*
		SCF (set carry)
	*/
	if (opcode == 0x37) {
		SET_FLAG((*cpu), FLAG_C);
		CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_H);
		return;
	}


	/*
		ADC A,r
	*/
	if ((opcode & 0xF8) == 0x88) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("ADC A,(HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t a = cpu->a;
    	uint8_t b = *src;
    	uint8_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint16_t sum = a + b + carry;
    	uint8_t result = sum & 0xFF;

    	cpu->a = result;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (carry from bit 3)
    	if (((a & 0x0F) + (b & 0x0F) + carry) & 0x10)
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if ((~(a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N reset
    	CLR_FLAG((*cpu), FLAG_N);

    	// C
    	if (sum & 0x100) SET_FLAG((*cpu), FLAG_C);
    	else CLR_FLAG((*cpu), FLAG_C);

    	return;
	}

	
	/*
		ADD A,r
	*/
	if ((opcode & 0xF8) == 0x80) {
    	int r = opcode & 0x07;
    	uint8_t* src = reg_ptr(cpu, r);
    	if (!src) {
        	printf("ADD A,(HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t a = cpu->a;
    	uint8_t b = *src;
    	uint16_t sum = a + b;
    	uint8_t result = sum & 0xFF;

    	cpu->a = result;

    	// S
    	if (result & 0x80) SET_FLAG((*cpu), FLAG_S);
    	else CLR_FLAG((*cpu), FLAG_S);

    	// Z
    	if (result == 0) SET_FLAG((*cpu), FLAG_Z);
    	else CLR_FLAG((*cpu), FLAG_Z);

    	// H (carry from bit 3)
    	if (((a & 0x0F) + (b & 0x0F)) & 0x10)
        	SET_FLAG((*cpu), FLAG_H);
    	else
        	CLR_FLAG((*cpu), FLAG_H);

    	// P/V (signed overflow)
    	if ((~(a ^ b) & (a ^ result)) & 0x80)
        	SET_FLAG((*cpu), FLAG_PV);
    	else
        	CLR_FLAG((*cpu), FLAG_PV);

    	// N reset
    	CLR_FLAG((*cpu), FLAG_N);

    	// C
    	if (sum & 0x100) SET_FLAG((*cpu), FLAG_C);
    	else CLR_FLAG((*cpu), FLAG_C);

    	return;
	}


	/*
		DJNZ e
	*/
	if (opcode == 0x10) {
    	int8_t offset = (int8_t)mem_read(cpu->pc++);

    	cpu->b--;               // decrement B

    	if (cpu->b != 0) {
        	cpu->pc += offset;
    	}
    	return;
	}


	/*
		JR NZ,e
	*/
	if (opcode == 0x20) { /* JR NZ */
    int8_t disp = (int8_t)mem_read(cpu->pc++);
    int taken = !(cpu->f & FLAG_Z);

    if (taken)
        cpu->pc += disp;

    printf(
        "JR NZ %s PC=%04X disp=%d Z=%d C=%d\n",
        taken ? "TAKEN" : "NOT",
        cpu->pc,
        disp,
        !!(cpu->f & FLAG_Z),
        !!(cpu->f & FLAG_C)
    );

    return;
}

	/*
		JR Z,e
	*/
	if (opcode == 0x28) {
    	int8_t offset = (int8_t)mem_read(cpu->pc++);
    	if (cpu->f & FLAG_Z) {
        	cpu->pc += offset;
    	}

		printf("JR taken=Z PC=%04X disp=%d Z=%d C=%d\n",
       
       cpu->pc,
       offset,
       !!(cpu->f & FLAG_Z),
       !!(cpu->f & FLAG_C));

    	return;
	}

	/*
		JR NC,e
	*/
	if (opcode == 0x30) {
    	int8_t offset = (int8_t)mem_read(cpu->pc++);
    	if (!(cpu->f & FLAG_C)) {
        	cpu->pc += offset;
    	}

		printf("JR taken=NC PC=%04X disp=%d Z=%d C=%d\n",
       cpu->pc,
       offset,
       !!(cpu->f & FLAG_Z),
       !!(cpu->f & FLAG_C));

    	return;
	}

	/*
		JR C,e
	*/
	if (opcode == 0x38) {
    	int8_t offset = (int8_t)mem_read(cpu->pc++);
    	if (cpu->f & FLAG_C) {
        	cpu->pc += offset;
    	}

		printf("JR taken=C PC=%04X disp=%d Z=%d C=%d\n",
       cpu->pc,
       offset,
       !!(cpu->f & FLAG_Z),
       !!(cpu->f & FLAG_C));

    	return;
	}


	/*
		LD (HL), r : 01 110 rrr
	*/
	if ((opcode & 0xF8) == 0x70) {

    	uint8_t src = opcode & 0x07;
    	uint8_t *src_reg = reg_ptr(cpu, src);

    	if (!src_reg) {
        	printf("Invalid LD (HL),r\n");
        	exit(1);
    	}

    	mem_write(get_hl(cpu), *src_reg);
    	return;
	}

	/*
		LD r, (HL) : 01 rrr 110
	*/
	if ((opcode & 0xC7) == 0x46) {

    	uint8_t dst = (opcode >> 3) & 0x07;
    	uint8_t *dst_reg = reg_ptr(cpu, dst);

    	if (!dst_reg) {
        	printf("Invalid LD r,(HL)\n");
        	exit(1);
    	}

    	*dst_reg = mem_read(get_hl(cpu));
    	return;
	}

	/*
		INC r : 00 rrr 100
	*/
	if ((opcode & 0xC7) == 0x04) {
    	uint8_t reg = (opcode >> 3) & 0x07;
    	uint8_t *r = reg_ptr(cpu, reg);

    	if (!r) {
        	printf("INC (HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t value = *r;
    	uint8_t result = value + 1;

    	*r = result;

    	uint8_t old_c = cpu->f & FLAG_C;

    	// Rebuild flags from scratch (except C)
    	cpu->f = old_c;

    	// S
    	if (result & 0x80) cpu->f |= FLAG_S;

    	// Z
    	if (result == 0) cpu->f |= FLAG_Z;

    	// H (bit 3 carry)
    	if ((value & 0x0F) == 0x0F)
        	cpu->f |= FLAG_H;

    	// P/V (overflow 7F -> 80)
    	if (value == 0x7F)
        	cpu->f |= FLAG_PV;

    	// N is always cleared for INC

    	// Undocumented flags (recommended)
    	cpu->f |= result & (FLAG_3 | FLAG_5);

    	return;
	}


	/*
		DEC r : 00 rrr 101
	*/
	if ((opcode & 0xC7) == 0x05) {
    	uint8_t reg = (opcode >> 3) & 0x07;
    	uint8_t *r = reg_ptr(cpu, reg);

    	if (!r) {
        	printf("DEC (HL) not implemented\n");
        	exit(1);
    	}

    	uint8_t value = *r;
    	(*r)--;
    	uint8_t result = *r;

    	// Preserve carry flag
    	uint8_t carry = cpu->f & FLAG_C;

    	// Set S and Z
    	set_sz(cpu, result);

    	// Set H if borrow from bit 4 (i.e., lower nibble was 0x00)
    	if ((value & 0x0F) == 0x00)
        	cpu->f |= FLAG_H;

    	// Set PV if we went from 0x80 to 0x7F (signed overflow)
    	if (value == 0x80)
        	cpu->f |= FLAG_PV;

    	// N is always set for DEC
    	cpu->f |= FLAG_N;

    	// Restore carry
    	cpu->f |= carry;

    	return;
	}

	
	/* 
		LD r,r : 01xxxxyyy 
	*/ 
    if ((opcode & 0xC0) == 0x40) {

        uint8_t dst = (opcode >> 3) & 0x07;
        uint8_t src = opcode & 0x07;

        // Skip HALT (special case: 0x76)
        if (opcode == 0x76) {
            cpu->halted = true;
            return;
        }

        uint8_t *dst_reg = reg_ptr(cpu, dst);
        uint8_t *src_reg = reg_ptr(cpu, src);

        // Ignore (HL) for now
        if (!dst_reg || !src_reg) {
            printf("LD involving (HL) not implemented\n");
            exit(1);
        }

        *dst_reg = *src_reg;
        return;
    }

	if (opcode == 0x3E) { // LD A,n
    	cpu->a = fetch(cpu);
    	printf("LD A,n: A=%02X Z=%d\n", cpu->a, !!(cpu->f & FLAG_Z));
    	return;
	}

	/*
		LD r,n : 00rrr110
	*/
	if ((opcode & 0xC7) == 0x06) {

    	uint8_t reg = (opcode >> 3) & 0x07;
    	uint8_t value = fetch(cpu);

    	uint8_t *dst = reg_ptr(cpu, reg);

    	if (!dst) {
        	printf("LD (HL),n not implemented\n");
        	exit(1);
    	}

    	*dst = value;

		printf("LD r,n: %02X\n", value);

    	return;
	}

	/*
		LD (HL), r : 01 110 rrr
	*/
	if ((opcode & 0xF8) == 0x70 && opcode != 0x76) {

    	uint8_t src = opcode & 0x07;
    	uint8_t *src_reg = reg_ptr(cpu, src);

    	if (!src_reg) {
        	printf("Invalid LD (HL),r\n");
        	exit(1);
    	}

    	uint16_t addr = get_hl(cpu);
    	mem_write(addr, *src_reg);
    	return;
	}

	/*
		LD r, (HL) : 01 rrr 110
	*/
	if ((opcode & 0xC7) == 0x46) {

    	uint8_t dst = (opcode >> 3) & 0x07;
    	uint8_t *dst_reg = reg_ptr(cpu, dst);

    	if (!dst_reg) {
        	printf("Invalid LD r,(HL)\n");
        	exit(1);
    	}

    	uint16_t addr = get_hl(cpu);
    	*dst_reg = mem_read(addr);
    	return;
	}

	/*
		LD HL,nn
	*/
	if (opcode == 0x21) {
    	uint8_t lo = fetch(cpu);
    	uint8_t hi = fetch(cpu);
    	cpu->h = hi;
    	cpu->l = lo;
    	return;
	}

	if (opcode == 0xDD) {
    	handle_DD_prefix(cpu);
    	return;
	}

	if (opcode == 0xFD) {
		handle_FD_prefix(cpu);
		return;
	}

    switch (opcode) {
        case 0x00: // NOP
            break;
		case 0xED:
        	handle_ED_prefix(cpu);
			//uint8_t next = mem_read(cpu->pc++);
        	break;
        default:
            printf("Unknown opcode %02X at %04X\n", opcode, cpu->pc - 1);
            exit(1);
    }
}

void handle_ED_prefix(Z80 *cpu) {
    uint8_t op2 = mem_read(cpu->pc++);

	switch (op2) {
    
	case 0x43: { // LD (nn),BC
        uint8_t lo = mem_read(cpu->pc++);
        uint8_t hi = mem_read(cpu->pc++);
        uint16_t addr = (hi << 8) | lo;

        mem_write(addr, cpu->c);
        mem_write(addr + 1, cpu->b);
        return;
    }

	case 0xC3: { // OUT (C),HL
    	uint8_t port = cpu->c;

    	io_write(port, cpu->l, cpu);
    	io_write(port, cpu->h, cpu);

    	return;
	}

	case 0xB0: { // LDIR
    	while ((cpu->b != 0) || (cpu->c != 0)) {
        	uint16_t hl = (cpu->h << 8) | cpu->l;
        	uint16_t de = (cpu->d << 8) | cpu->e;
        	uint16_t bc = (cpu->b << 8) | cpu->c;

        	uint8_t val = mem_read(hl);
        	mem_write(de, val);

        	// HL++
        	hl++;
        	cpu->h = (hl >> 8) & 0xFF;
        	cpu->l = hl & 0xFF;

        	// DE++
        	de++;
        	cpu->d = (de >> 8) & 0xFF;
        	cpu->e = de & 0xFF;

        	// BC--
        	bc--;
        	cpu->b = (bc >> 8) & 0xFF;
        	cpu->c = bc & 0xFF;
    	}

    	// Flags
    	CLR_FLAG((*cpu), FLAG_H);
    	CLR_FLAG((*cpu), FLAG_N);
    	CLR_FLAG((*cpu), FLAG_PV); // BC == 0 when finished

    	return;
	}

	case 0x53: { // LD (nn),DE
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	mem_write(addr, cpu->e);
    	mem_write(addr + 1, cpu->d);

    	return;
	}

	case 0x5B: { // LD DE,(nn)
    	uint8_t lo = mem_read(cpu->pc++);
    	uint8_t hi = mem_read(cpu->pc++);
    	uint16_t addr = (hi << 8) | lo;

    	cpu->e = mem_read(addr);
    	cpu->d = mem_read(addr + 1);

    	return;
	}

	case 0x42: { // SBC HL,BC

    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint16_t bc = (cpu->b << 8) | cpu->c;
    	uint16_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint32_t result32 = (uint32_t)hl - bc - carry;
    	uint16_t result = (uint16_t)result32;

    	// Write back to HL
    	cpu->h = (result >> 8) & 0xFF;
	    cpu->l = result & 0xFF;

    	cpu->f = 0;

    	// S flag (bit 15)
    	if (result & 0x8000) cpu->f |= FLAG_S;

    	// Z flag
    	if (result == 0) cpu->f |= FLAG_Z;

    	// H flag (borrow from bit 11)
    	if (((hl ^ bc ^ result) & 0x1000))
        	cpu->f |= FLAG_H;

    	// P/V flag (signed overflow)
    	if (((hl ^ bc) & (hl ^ result) & 0x8000))
        	cpu->f |= FLAG_PV;

    	// N flag (subtraction)
    	cpu->f |= FLAG_N;

    	// C flag (borrow)
    	if (result32 & 0x10000)
        	cpu->f |= FLAG_C;

    	return;
	}

	case 0x52: { // SBC HL,DE
    	uint16_t hl = (cpu->h << 8) | cpu->l;
    	uint16_t de = (cpu->d << 8) | cpu->e;
    	uint16_t carry = (cpu->f & FLAG_C) ? 1 : 0;

    	uint32_t result32 = (uint32_t)hl - (uint32_t)de - carry;
    	uint16_t result = (uint16_t)result32;

    	// Write back
    	cpu->h = result >> 8;
    	cpu->l = result & 0xFF;

    	// Reset flags first
    	cpu->f = 0;

    	// S flag (bit 15)
    	if (result & 0x8000) cpu->f |= FLAG_S;

    	// Z flag
    	if (result == 0) cpu->f |= FLAG_Z;

    	// H flag (borrow from bit 11)
    	if (((hl ^ de ^ result) & 0x1000))
        	cpu->f |= FLAG_H;

    	// Overflow flag
    	if (((hl ^ de) & (hl ^ result) & 0x8000))
        	cpu->f |= FLAG_PV;

    	// N flag (subtract)
    	cpu->f |= FLAG_N;

    	// Carry flag
    	if (result32 & 0x10000)
        	cpu->f |= FLAG_C;

    	return;
	}

	case 0x4B: {  // ED 4B nn nn  -> LD BC,(nn)

    	uint8_t low = mem_read(cpu->pc++);
    	uint8_t high = mem_read(cpu->pc++);
    	uint16_t addr = (high << 8) | low;

    	cpu->c = mem_read(addr);
    	cpu->b = mem_read(addr + 1);

    	return;
	}

	

    default:
        printf("Unknown ED opcode %02X at %04X\n", op2, cpu->pc - 2);
        exit(1);
    }
}

void handle_DD_prefix(Z80 *cpu)
{
    uint8_t op2 = mem_read(cpu->pc++);

    switch (op2)
    {
        /* ----- 16-bit loads ----- */

        case 0x21: { // LD IX,nn
            uint8_t lo = mem_read(cpu->pc++);
            uint8_t hi = mem_read(cpu->pc++);
            cpu->ix = (hi << 8) | lo;
            return;
        }

        case 0x22: { // LD (nn),IX
            uint8_t lo = mem_read(cpu->pc++);
            uint8_t hi = mem_read(cpu->pc++);
            uint16_t addr = (hi << 8) | lo;

            mem_write(addr, cpu->ix & 0xFF);
            mem_write(addr + 1, cpu->ix >> 8);
            return;
        }

        case 0x2A: { // LD IX,(nn)
            uint8_t lo = mem_read(cpu->pc++);
            uint8_t hi = mem_read(cpu->pc++);
            uint16_t addr = (hi << 8) | lo;

            uint8_t l = mem_read(addr);
            uint8_t h = mem_read(addr + 1);
            cpu->ix = (h << 8) | l;
            return;
        }

        case 0xE5: { // PUSH IX
            cpu->sp--;
            mem_write(cpu->sp, cpu->ix >> 8);
            cpu->sp--;
            mem_write(cpu->sp, cpu->ix & 0xFF);
            return;
        }

        case 0xE1: { // POP IX
            uint8_t lo = mem_read(cpu->sp++);
            uint8_t hi = mem_read(cpu->sp++);
            cpu->ix = (hi << 8) | lo;
            return;
        }

        /* ----- Arithmetic ----- */

        case 0x09: { // ADD IX,BC
            uint32_t result = cpu->ix + ((cpu->b << 8) | cpu->c);

            cpu->f &= FLAG_S | FLAG_Z | FLAG_PV;  // preserve SZPV
            if (((cpu->ix ^ result ^ ((cpu->b << 8) | cpu->c)) & 0x1000))
                cpu->f |= FLAG_H;

            if (result & 0x10000)
                cpu->f |= FLAG_C;

            cpu->f &= ~FLAG_N;

            cpu->ix = result & 0xFFFF;
            return;
        }

        /* ----- IX+d memory form ----- */

        case 0x36: { // LD (IX+d),n
            int8_t disp = (int8_t)mem_read(cpu->pc++);
            uint8_t value = mem_read(cpu->pc++);

            uint16_t addr = cpu->ix + disp;
            mem_write(addr, value);
            return;
        }

		case 0x74: { // LD (IX+d),H
    		int8_t disp = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + disp;

    		mem_write(addr, cpu->h);
    		return;
		}

		case 0x75: { // LD (IX+d),L
    		int8_t disp = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + disp;

    		mem_write(addr, cpu->l);
    		return;
		}

		case 0x7E: { // LD A,(IX+d)
    		int8_t disp = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + disp;

    		cpu->a = mem_read(addr);

    		return;
		}

		case 0xB6: { // OR (IX+d)
    		int8_t disp = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + disp;

    		uint8_t val = mem_read(addr);

    		cpu->a |= val;

    		uint8_t res = cpu->a;

    		// Flags (same as normal OR)
    		if (res & 0x80) SET_FLAG((*cpu), FLAG_S); else CLR_FLAG((*cpu), FLAG_S);
    		if (res == 0)   SET_FLAG((*cpu), FLAG_Z); else CLR_FLAG((*cpu), FLAG_Z);
    		if (parity(res)) SET_FLAG((*cpu), FLAG_PV); else CLR_FLAG((*cpu), FLAG_PV);

    		CLR_FLAG((*cpu), FLAG_H);
    		CLR_FLAG((*cpu), FLAG_N);
    		CLR_FLAG((*cpu), FLAG_C);

    		return;
		}
		
		case 0x23: { // INC IX
    		cpu->ix++;
    		return;
		}

		case 0x5E: {
			int8_t disp = (int8_t)mem_read(cpu->pc++);
			uint16_t addr = cpu->ix + disp;

			cpu->e = mem_read(addr);
			return;
		}

		case 0x56: {
			int8_t disp = (int8_t)mem_read(cpu->pc++);
			uint16_t addr = cpu->ix + disp;

			cpu->d = mem_read(addr);
			return;
		}

		case 0x6E: { // LD L,(IX+d)
    		int8_t d = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + d;

    		cpu->l = mem_read(addr);
    		return;
		}

		case 0x66: { // LD H,(IX+d)
    		int8_t d = (int8_t)mem_read(cpu->pc++);
    		uint16_t addr = cpu->ix + d;

    		cpu->h = mem_read(addr);
    		return;
		}

        default:
            printf("Unknown DD opcode %02X at %04X\n", op2, cpu->pc - 2);
            exit(1);
    }
}

void handle_FD_prefix(Z80 *cpu) {
	uint8_t op2 = mem_read(cpu->pc++);

	switch (op2) {

	// LD IY, nn
	case 0x21: {
		uint8_t lo = mem_read(cpu->pc++);
		uint8_t hi = mem_read(cpu->pc++);

		cpu->iy = (hi << 8) | lo;
		return;
	}
	
	// LD A, (IY+d)
	case 0x7E: {
		int8_t disp = (int8_t)mem_read(cpu->pc++);
		uint16_t addr = cpu->iy + disp;

		cpu->a = mem_read(addr);
		return;
	}

	// OR (IY+d)
	case 0xB6: {
    	int8_t disp = (int8_t)mem_read(cpu->pc++);
    	uint16_t addr = cpu->iy + disp;

    	uint8_t value = mem_read(addr);
    	uint8_t result = cpu->a | value;

    	cpu->a = result;

    	// Update flags
    	cpu->f = 0;

    	if (result & 0x80) cpu->f |= FLAG_S;
    	if (result == 0)   cpu->f |= FLAG_Z;
    	if (parity(result)) cpu->f |= FLAG_PV;
    
    	// H, N, C already 0

    	return;
	}

	// INC IY
	case 0x23: {
		cpu->iy++;
		return;
	}

	case 0x6E: {  // FD 6E d  -> LD L,(IY+d)

    	int8_t disp = (int8_t)mem_read(cpu->pc++);
    	uint16_t addr = cpu->iy + disp;

    	cpu->l = mem_read(addr);

    	return;
	}

	case 0x66: {  // FD 66 d  -> LD H,(IY+d)

    	int8_t disp = (int8_t)mem_read(cpu->pc++);
    	uint16_t addr = cpu->iy + disp;

    	cpu->h = mem_read(addr);

    	return;
	}

	default:
		printf("Unknown FD opcode %02X at %04X\n", op2, cpu->pc - 2);
		exit(1);
	}
}