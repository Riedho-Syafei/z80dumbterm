		ORG $0100

START:
        ; 0. Select the disk the user wants to be displayed
		LD   A, ($0090)			; ARG1 = Drive letter
		OR   A
		JR   Z, .err_no_drive_letter
		SUB  $41
		LD   B, A
		LD   C, 18
		CALL $0005

		OR   A
		JR   NZ, .err_drive_empty
		
		; 1. Print intro message
        LD   C, 3               ; Syscall 3: SYS_PUTS
        LD   DE, MSG_INTRO
        CALL $0005
        
        ; 2. Call the new syscall
        LD   C, 43              ; Syscall 43: SYS_FS_DISK_REMAINING
        LD   DE, FREE_BYTES     ; Destination for the 32-bit result
        CALL $0005
        
        ; 3. Setup String Buffer pointer (start from the end)
        LD   DE, STR_BUFFER + 11
        XOR  A
        LD   (DE), A            ; Put null terminator at the very end
        
.convert_loop:
        DEC  DE                 ; Move pointer backwards for the next digit
        PUSH DE                 ; Save string pointer
        
        ; Divide FREE_BYTES by 10. (FREE_BYTES = Quotient, A = Remainder)
        CALL div10              
        
        ADD  A, '0'             ; Convert Remainder (0-9) to ASCII ('0'-'9')
        POP  DE                 ; Restore string pointer
        LD   (DE), A            ; Store ASCII character
        
        ; Check if the 32-bit FREE_BYTES is now 0 (Quotient empty)
        LD   HL, FREE_BYTES
        LD   A, (HL)            ; Byte 0
        INC  HL
        OR   (HL)               ; Byte 1
        INC  HL
        OR   (HL)               ; Byte 2
        INC  HL
        OR   (HL)               ; Byte 3
        JR   NZ, .convert_loop  ; If not zero, keep dividing
        
        ; 4. Print the computed number string
        ; DE naturally points to the first character of our string now!
        LD   C, 3               ; Syscall 3: SYS_PUTS
        CALL $0005
        
        ; 5. Print suffix and newline
        LD   C, 3
        LD   DE, MSG_SUFFIX
        CALL $0005
        
        ; 6. Exit program
        LD   C, 0               ; Syscall 0: SYS_EXIT
        CALL $0005

.err_no_drive_letter:
		LD   DE, MSG_ERR_NO_DRIVE_LETTER
		LD   C, 3
		CALL $0005

		JP   $003B				; Exit

.err_drive_empty:
		LD   DE, MSG_ERR_DRIVE_EMPTY
		LD   C, 3
		CALL $0005

		JP   $003B				; Exit
; ------------------------------------------------------------------
; 32-bit divide by 10
; Input:  FREE_BYTES (32-bit Little Endian)
; Output: FREE_BYTES = Quotient, A = Remainder
; ------------------------------------------------------------------
div10:
        LD   B, 32              ; We need to shift 32 bits
        XOR  A                  ; Clear Remainder (A = 0)
        
.div_loop:
        ; Shift the entire 32-bit value left by 1 bit into the Carry
        LD   HL, FREE_BYTES
        SLA  (HL)               ; LSB: Shift left, bit 7 to Carry, bit 0 becomes 0
        INC  HL
        RL   (HL)               ; Byte 1: Rotate left through Carry
        INC  HL
        RL   (HL)               ; Byte 2: Rotate left through Carry
        INC  HL
        RL   (HL)               ; MSB:  Rotate left through Carry
        
        ; Roll the outgoing Carry bit into our Remainder (A)
        RLA
        
        ; Check if Remainder >= 10
        CP   10
        JR   C, .skip_sub       ; If < 10, skip subtraction
        
        SUB  10                 ; Remainder -= 10
        
        ; Because it fit, we set the lowest bit of the Quotient to 1
        LD   HL, FREE_BYTES
        SET  0, (HL)            ; LSB bit 0 is safe to set (SLA cleared it)
        
.skip_sub:
        DJNZ .div_loop          ; Loop for all 32 bits
        RET

; ------------------------------------------------------------------
; Data Area
; ------------------------------------------------------------------
MSG_INTRO:  DB "Checking free disk space... ", 0
MSG_SUFFIX: DB " bytes remaining.", 13, 10, 0
MSG_ERR_NO_DRIVE_LETTER: DB "ERROR: Syntax: DISKSPACE [drive letter]",13,10,0
MSG_ERR_DRIVE_EMPTY: DB "ERROR: No disk in drive tray",13,10,0

FREE_BYTES: DS 4, 0             ; Buffer for the syscall to write into
STR_BUFFER: DS 12, 0            ; Buffer to hold ASCII string (max 10 digits + null)