		ORG  $0100

		LD   DE, STR_HELLO
		LD   C, 3
		CALL $0005

		LD   C, 0
		CALL $0005

STR_HELLO:
		DB "Hello World!",13,10,0