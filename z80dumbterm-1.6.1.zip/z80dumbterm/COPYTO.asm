; ================================================================
; COPYTO.COM
; A transient command for the CPM-like OS.
;
; Syntax: COPYTO [src_drive,dst_drive] [src_file] [dst_file]
; Example: COPYTO A,B MYFILE.TXT MYFILE.TXT
;
; OS Specifics:
; - Arguments are in fixed 16-byte buffers starting at $0080.
; - ARG0 ($0080): Command Name
; - ARG1 ($0090): Drive Arg (e.g., "A,B")
; - ARG2 ($00A0): Source Filename
; - ARG3 ($00B0): Dest Filename
; - Single global file handle (must open/close on every switch).
; ================================================================

        ORG $0100

; --- OS Interface ---
SYSCALL     EQU $0005

; Syscall Numbers (C register)
F_EXIT      EQU 0
F_PUTS      EQU 3
F_SELDSK    EQU 18
F_OPEN      EQU 33
F_READ      EQU 34
F_CLOSE     EQU 35
F_SEEK      EQU 36
F_CREATE    EQU 37
F_DELETE    EQU 38
F_WRITE     EQU 40
F_TELL      EQU 41
F_SIZE      EQU 42

; --- Argument Buffer Addresses (OS Specific) ---
ARG0        EQU $0080       ; Command Name
ARG1        EQU $0090       ; Drives (e.g., "A,B")
ARG2        EQU $00A0       ; Source Filename
ARG3        EQU $00B0       ; Dest Filename

; --- Constants ---
BUFFER_SIZE EQU 4096       ; 4KB Copy Buffer

; ================================================================
; MAIN ENTRY POINT
; ================================================================
START:
        LD   SP, $FFF0     ; Setup stack

        ; --- 1. Parse Arguments from fixed buffers ---
        CALL PARSE_ARGS
        OR   A
        JP   NZ, ERROR_USAGE

        ; --- 2. Get Source File Size ---
        LD   A, (SRC_DRIVE)
        LD   B, A
        CALL SELECT_DRIVE    ; Select Source Drive

        LD   DE, ARG2        ; Pointer to Source Filename
        CALL OPEN_FILE
        OR   A
        JP   NZ, ERROR_SRC_OPEN

        LD   DE, FILE_SIZE_BUF
        CALL GET_SIZE        ; Get 32-bit size into FILE_SIZE_BUF

        CALL CLOSE_FILE

        ; --- 3. Create Destination File ---
        LD   A, (DST_DRIVE)
        LD   B, A
        CALL SELECT_DRIVE    ; Select Destination Drive

        ; Delete destination if it exists (Ignore error if not found)
        LD   DE, ARG3
        CALL DELETE_FILE

        LD   DE, ARG3
        CALL CREATE_FILE
        OR   A
        JP   NZ, ERROR_CREATE

        ; --- 4. Initialize 32-bit Cursor ---
        XOR  A
        LD   (CURSOR), A
        LD   (CURSOR+1), A
        LD   (CURSOR+2), A
        LD   (CURSOR+3), A

; ================================================================
; COPY LOOP
; ================================================================
COPY_LOOP:
        ; Compare CURSOR vs FILE_SIZE_BUF (32-bit compare)
        LD   HL, (CURSOR)
        LD   DE, (FILE_SIZE_BUF)
        LD   A, L
        CP   E
        JR   NZ, .do_copy
        LD   A, H
        CP   D
        JR   NZ, .do_copy
        
        LD   HL, (CURSOR+2)
        LD   DE, (FILE_SIZE_BUF+2)
        LD   A, L
        CP   E
        JR   NZ, .do_copy
        LD   A, H
        CP   D
        JP   Z, COPY_DONE    ; Equal means copy complete

.do_copy:
        ; --- READ PHASE ---
        LD   A, (SRC_DRIVE)
        LD   B, A
        CALL SELECT_DRIVE

        LD   DE, ARG2        ; Source Filename
        CALL OPEN_FILE
        OR   A
        JP   NZ, ERROR_SRC_REOPEN

        ; Seek to current cursor position
        LD   DE, (CURSOR)
        LD   HL, (CURSOR+2)
        CALL SEEK_FILE

        ; Record start position
        LD   DE, TEMP_POS
        CALL TELL_FILE

        ; Read chunk
        LD   DE, COPY_BUFFER
        LD   HL, BUFFER_SIZE
        CALL READ_FILE
        CP   $FF
        JP   Z, ERROR_READ

        PUSH AF              ; Save EOF status (0 or 1)

        ; Record end position
        LD   DE, TEMP_POS+4
        CALL TELL_FILE

        CALL CLOSE_FILE

        ; Calculate Bytes Read = End - Start
        LD   HL, (TEMP_POS+4)
        LD   DE, (TEMP_POS)
        OR   A
        SBC  HL, DE
        LD   (BYTES_READ), HL

        LD   A, H
        OR   L
        JR   Z, COPY_DONE     ; 0 bytes read?

        ; --- WRITE PHASE ---
        LD   A, (DST_DRIVE)
        LD   B, A
        CALL SELECT_DRIVE

        LD   DE, ARG3        ; Dest Filename
        CALL OPEN_FILE
        OR   A
        JR   NZ, ERROR_DST_OPEN

        ; Seek to current cursor position
        LD   DE, (CURSOR)
        LD   HL, (CURSOR+2)
        CALL SEEK_FILE

        ; Write chunk
        LD   DE, COPY_BUFFER
        LD   HL, (BYTES_READ)
        CALL WRITE_FILE
        OR   A
        JR   NZ, ERROR_WRITE

        CALL CLOSE_FILE

        ; --- UPDATE CURSOR ---
        LD   BC, (BYTES_READ)
        LD   HL, (CURSOR)
        ADD  HL, BC
        LD   (CURSOR), HL
        JR   NC, .no_carry
        LD   HL, (CURSOR+2)
        INC  HL
        LD   (CURSOR+2), HL
.no_carry:

        POP  AF              ; Retrieve EOF status
        CP   1
        JR   Z, COPY_DONE    ; If we hit EOF, finish

        JP   COPY_LOOP

; ================================================================
; EXIT & ERROR HANDLERS
; ================================================================
COPY_DONE:
        LD   DE, MSG_SUCCESS
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_USAGE:
        LD   DE, MSG_USAGE
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_SRC_OPEN:
        LD   DE, MSG_ERR_SRC_OPEN
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_SRC_REOPEN:
        LD   DE, MSG_ERR_SRC_REOPEN
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_CREATE:
        LD   DE, MSG_ERR_CREATE
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_READ:
        LD   DE, MSG_ERR_READ
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_DST_OPEN:
        LD   DE, MSG_ERR_DST_OPEN
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

ERROR_WRITE:
        LD   DE, MSG_ERR_WRITE
        CALL PRINT_STR
        LD   C, F_EXIT
        JP   SYSCALL

; ================================================================
; ARGUMENT PARSING (Fixed Buffer Method)
; ================================================================
PARSE_ARGS:
        ; 1. Parse Drives from ARG1 ($0090)
        ; Expects format: "A,B" or "A,B"
        LD   HL, ARG1
        LD   A, (HL)
        OR   A
        JR   Z, .err_usage       ; Empty drive arg?

        CALL .TO_UPPER
        SUB  'A'
        LD   (SRC_DRIVE), A      ; Store Source Drive Index
        
        INC  HL
        LD   A, (HL)
        CP   ','
        JR   NZ, .err_usage      ; Expecting comma
        
        INC  HL
        LD   A, (HL)
        OR   A
        JR   Z, .err_usage       ; Missing dest drive
        
        CALL .TO_UPPER
        SUB  'A'
        LD   (DST_DRIVE), A      ; Store Dest Drive Index

        ; 2. Check Source Filename (ARG2)
        LD   A, (ARG2)
        OR   A
        JR   Z, .err_usage       ; Missing source filename
        
        ; 3. Check Dest Filename (ARG3)
        LD   A, (ARG3)
        OR   A
        JR   Z, .err_usage       ; Missing dest filename

        XOR  A                   ; Success
        RET

.err_usage:
        LD   A, $FF
        RET

.TO_UPPER:
        CP   'a'
        RET  C
        CP   'z' + 1
        RET  NC
        SUB  32
        RET

; ================================================================
; DRIVER WRAPPERS
; ================================================================
SELECT_DRIVE:
        LD   C, F_SELDSK
        JP   SYSCALL

OPEN_FILE:
        LD   C, F_OPEN
        JP   SYSCALL

CLOSE_FILE:
        LD   C, F_CLOSE
        JP   SYSCALL

GET_SIZE:
        LD   C, F_SIZE
        JP   SYSCALL

DELETE_FILE:
        LD   C, F_DELETE
        JP   SYSCALL

CREATE_FILE:
        LD   C, F_CREATE
        JP   SYSCALL

SEEK_FILE:
        LD   C, F_SEEK
        JP   SYSCALL

TELL_FILE:
        LD   C, F_TELL
        JP   SYSCALL

READ_FILE:
        LD   C, F_READ
        JP   SYSCALL

WRITE_FILE:
        LD   C, F_WRITE
        JP   SYSCALL

PRINT_STR:
        LD   C, F_PUTS
        JP   SYSCALL

; ================================================================
; DATA SECTION
; ================================================================

MSG_SUCCESS:      DB "Copy complete.", 13, 10, 0
MSG_USAGE:        DB "Usage: COPYTO src,dst file1 file2", 13, 10, 0
MSG_ERR_SRC_OPEN: DB "Error: Cannot open source.", 13, 10, 0
MSG_ERR_SRC_REOPEN: DB "Error: Lost source file.", 13, 10, 0
MSG_ERR_CREATE:   DB "Error: Cannot create destination.", 13, 10, 0
MSG_ERR_READ:     DB "Error: Read error.", 13, 10, 0
MSG_ERR_DST_OPEN: DB "Error: Cannot open destination.", 13, 10, 0
MSG_ERR_WRITE:    DB "Error: Write error.", 13, 10, 0

SRC_DRIVE:        DB 0
DST_DRIVE:        DB 0

; File size and cursor tracking (32-bit)
FILE_SIZE_BUF:    DS 4, 0
CURSOR:           DS 4, 0
TEMP_POS:         DS 8, 0
BYTES_READ:       DS 2, 0

; ================================================================
; BUFFER AREA
; ================================================================
; Placed at end of code. 4KB buffer.
COPY_BUFFER: